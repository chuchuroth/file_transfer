# neurasync — Shared IDL Submodule

This directory is a **git submodule** pointing to `qnc-neurasync-idl`,
the single source of truth for all DDS interface definitions shared between
`qnc-firmware` and `neurasync-robot-client`.

## Contents

```
neurasync/
├── idl/
│   ├── GripperCommand.idl
│   ├── GripperState.idl
│   └── GripperCapabilities.idl
└── generated/                 ← fastddsgen output (committed — do not edit manually)
    └── gripper/
```

## Versioning rule

Any IDL change **must bump the package version** and be coordinated across
**both workspaces** before either workspace is rebuilt.

## Initialising the submodule (after clone)

```bash
git submodule update --init --recursive
```

## Regenerating C++ types

```bash
cd neurasync-robot-client
cmake -S . -B build
cmake --build build --target gripper_idl_gen
```

Commit the updated `generated/` files so CI and the other workspace stay in sync.
