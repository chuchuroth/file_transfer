/**
 * modbus_rtu_slave_test.cpp — Unit tests + serial listener for the Modbus RTU slave
 *
 * Modes:
 *   ./modbus_slave_test                                   Run unit tests only
 *   ./modbus_slave_test --listen /dev/ttyUSB0 115200      Plain listen mode
 *   ./modbus_slave_test --discover /dev/ttyUSB0 115200    Discovery mode (wide register bank, verbose)
 *
 * Compile:
 *   g++ -std=c++17 -Iinclude -o modbus_slave_test src/modbus_rtu_slave_test.cpp
 */

#include "modbus_rtu_slave.hpp"
#include "zimmer_gep2013il.hpp"

#include <cassert>
#include <csignal>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>

using modbus_rtu_slave::crc16;
using modbus_rtu_slave::Slave;

// Signal handler for clean shutdown in --listen mode.
static volatile bool g_running = true;
static void sigint_handler(int) { g_running = false; }

// Helper: build a raw Modbus RTU frame (PDU + CRC).
static std::vector<uint8_t> make_frame(std::initializer_list<uint8_t> pdu)
{
    std::vector<uint8_t> f(pdu);
    uint16_t c = crc16(f.data(), f.size());
    f.push_back(c & 0xFF);
    f.push_back((c >> 8) & 0xFF);
    return f;
}

// Helper: dump a frame as hex for debugging.
static void dump(const char* label, const std::vector<uint8_t>& v)
{
    std::cout << label << " (" << v.size() << "B): ";
    for (auto b : v) std::printf("%02X ", b);
    std::cout << "\n";
}

// Validate CRC of a response.
static bool crc_ok(const std::vector<uint8_t>& v)
{
    if (v.size() < 4) return false;
    uint16_t rx = v[v.size()-2] | (v[v.size()-1] << 8);
    return rx == crc16(v.data(), v.size() - 2);
}

int main(int argc, char* argv[])
{
    // Create slave at address 1 with 64 holding registers.
    Slave slave(1, 64);

    // Pre-fill some registers for read-back testing.
    slave.set_reg(0, 0x1234);
    slave.set_reg(1, 0x5678);
    slave.set_reg(2, 0xABCD);

    int pass = 0, fail = 0;

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 1 — FC 0x03: Read 3 holding registers starting at address 0
    // ═══════════════════════════════════════════════════════════════════════
    {
        //  Master request: [slave=1, fc=0x03, startHi=0, startLo=0, countHi=0, countLo=3]
        auto req  = make_frame({0x01, 0x03, 0x00, 0x00, 0x00, 0x03});
        auto resp = slave.process_request(req);

        dump("REQ  FC03 read 3 regs  ", req);
        dump("RESP FC03              ", resp);

        // Expected: [01 03 06 12 34 56 78 AB CD crcLo crcHi]
        assert(!resp.empty());
        assert(crc_ok(resp));
        assert(resp[0] == 0x01);  // slave address
        assert(resp[1] == 0x03);  // function code
        assert(resp[2] == 0x06);  // byte count = 3 regs × 2
        assert(resp[3] == 0x12 && resp[4] == 0x34);  // reg 0
        assert(resp[5] == 0x56 && resp[6] == 0x78);  // reg 1
        assert(resp[7] == 0xAB && resp[8] == 0xCD);  // reg 2
        std::cout << "  ✓ TEST 1 PASSED (FC03 read)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 2 — FC 0x06: Write single register (reg 10 ← 0x00FF)
    // ═══════════════════════════════════════════════════════════════════════
    {
        auto req  = make_frame({0x01, 0x06, 0x00, 0x0A, 0x00, 0xFF});
        auto resp = slave.process_request(req);

        dump("REQ  FC06 write reg 10 ", req);
        dump("RESP FC06              ", resp);

        // Response echoes the request (same PDU, valid CRC).
        assert(!resp.empty());
        assert(crc_ok(resp));
        assert(resp[0] == 0x01);
        assert(resp[1] == 0x06);
        assert(resp[2] == 0x00 && resp[3] == 0x0A);
        assert(resp[4] == 0x00 && resp[5] == 0xFF);
        // Verify the register was actually written.
        assert(slave.reg(10) == 0x00FF);
        std::cout << "  ✓ TEST 2 PASSED (FC06 write + readback)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 3 — Address mismatch (request to slave 2, our slave is 1)
    // ═══════════════════════════════════════════════════════════════════════
    {
        auto req  = make_frame({0x02, 0x03, 0x00, 0x00, 0x00, 0x01});
        auto resp = slave.process_request(req);
        assert(resp.empty());   // slave must not respond
        std::cout << "  ✓ TEST 3 PASSED (address mismatch → no response)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 4 — Bad CRC → ignored
    // ═══════════════════════════════════════════════════════════════════════
    {
        auto req = make_frame({0x01, 0x03, 0x00, 0x00, 0x00, 0x01});
        req.back() ^= 0xFF;  // corrupt CRC
        auto resp = slave.process_request(req);
        assert(resp.empty());
        std::cout << "  ✓ TEST 4 PASSED (bad CRC → no response)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 5 — Unsupported function code → exception response
    // ═══════════════════════════════════════════════════════════════════════
    {
        auto req  = make_frame({0x01, 0x01, 0x00, 0x00, 0x00, 0x08});  // FC01 = Read Coils
        auto resp = slave.process_request(req);

        dump("REQ  FC01 (unsupported)", req);
        dump("RESP exception         ", resp);

        assert(!resp.empty());
        assert(crc_ok(resp));
        assert(resp[0] == 0x01);
        assert(resp[1] == 0x81);  // FC | 0x80
        assert(resp[2] == 0x01);  // ILLEGAL_FUNCTION
        std::cout << "  ✓ TEST 5 PASSED (unsupported FC → exception 0x01)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 6 — Out-of-range register address → exception
    // ═══════════════════════════════════════════════════════════════════════
    {
        // Read reg 100, but slave only has 64 registers (0–63)
        auto req  = make_frame({0x01, 0x03, 0x00, 0x64, 0x00, 0x01});
        auto resp = slave.process_request(req);

        assert(!resp.empty());
        assert(crc_ok(resp));
        assert(resp[1] == 0x83);  // FC03 | 0x80
        assert(resp[2] == 0x02);  // ILLEGAL_DATA_ADDRESS
        std::cout << "  ✓ TEST 6 PASSED (invalid address → exception 0x02)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 7 — FC03 read-back after FC06 write (round-trip)
    // ═══════════════════════════════════════════════════════════════════════
    {
        // Write 0xBEEF to register 20
        auto wreq = make_frame({0x01, 0x06, 0x00, 0x14, 0xBE, 0xEF});
        auto wresp = slave.process_request(wreq);
        assert(!wresp.empty() && crc_ok(wresp));

        // Read it back
        auto rreq = make_frame({0x01, 0x03, 0x00, 0x14, 0x00, 0x01});
        auto rresp = slave.process_request(rreq);

        assert(!rresp.empty() && crc_ok(rresp));
        assert(rresp[3] == 0xBE && rresp[4] == 0xEF);
        std::cout << "  ✓ TEST 7 PASSED (write 0xBEEF → read-back 0xBEEF)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 8 — FC 0x10: Write Multiple Registers (regs 5–7 ← 3 values)
    // ═══════════════════════════════════════════════════════════════════════
    {
        // Write 3 regs starting at address 5: 0x1111, 0x2222, 0x3333
        // [addr=1, fc=0x10, startHi=0, startLo=5, countHi=0, countLo=3,
        //  byteCount=6, 0x11,0x11, 0x22,0x22, 0x33,0x33]
        auto req  = make_frame({0x01, 0x10, 0x00, 0x05, 0x00, 0x03, 0x06,
                                0x11, 0x11, 0x22, 0x22, 0x33, 0x33});
        auto resp = slave.process_request(req);

        dump("REQ  FC10 write 3 regs ", req);
        dump("RESP FC10              ", resp);

        assert(!resp.empty());
        assert(crc_ok(resp));
        assert(resp[0] == 0x01);
        assert(resp[1] == 0x10);
        assert(resp[2] == 0x00 && resp[3] == 0x05);  // start address
        assert(resp[4] == 0x00 && resp[5] == 0x03);  // register count
        // Verify registers were actually written.
        assert(slave.reg(5) == 0x1111);
        assert(slave.reg(6) == 0x2222);
        assert(slave.reg(7) == 0x3333);
        std::cout << "  ✓ TEST 8 PASSED (FC10 write multiple + readback)\n\n";
        ++pass;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 9 — Write callback fires on FC06 and FC10
    // ═══════════════════════════════════════════════════════════════════════
    {
        uint16_t cb_start = 0xFFFF, cb_count = 0;
        slave.set_write_callback([&](uint16_t s, uint16_t c) {
            cb_start = s; cb_count = c;
        });

        // FC06 write
        auto req = make_frame({0x01, 0x06, 0x00, 0x03, 0xAA, 0xBB});
        slave.process_request(req);
        assert(cb_start == 3 && cb_count == 1);

        // FC10 write 2 regs at addr 8
        cb_start = 0xFFFF; cb_count = 0;
        auto req2 = make_frame({0x01, 0x10, 0x00, 0x08, 0x00, 0x02, 0x04,
                                0xDD, 0xEE, 0xFF, 0x00});
        slave.process_request(req2);
        assert(cb_start == 8 && cb_count == 2);

        slave.set_write_callback(nullptr);  // clear callback
        std::cout << "  ✓ TEST 9 PASSED (write callback fires)\n\n";
        ++pass;
    }

    std::cout << "═══════════════════════════════════════════════\n"
              << "  Results: " << pass << " passed, " << fail << " failed\n"
              << "═══════════════════════════════════════════════\n\n";

    if (fail > 0) return fail;

    // ═══════════════════════════════════════════════════════════════════════
    // Serial modes: --listen, --discover
    //
    // --discover: Wide register bank (512 regs), accepts any master r/w.
    //             Use this first to reverse-engineer the master's register map.
    //
    // --listen:   Normal slave mode with the register map aligned to the
    //             Zimmer GEP2013IL master expectations.
    // ═══════════════════════════════════════════════════════════════════════
    bool do_listen   = false;
    bool do_discover = false;
    std::string port;
    int baud = 0;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--listen" || arg == "--discover") {
            do_listen = true;
            do_discover = (arg == "--discover");
            if (i + 1 < argc && argv[i+1][0] == '/')
                port = argv[++i];
            if (i + 1 < argc && std::isdigit(argv[i+1][0]))
                baud = std::atoi(argv[++i]);
        }
    }

    if (!do_listen) return 0;

    // Default to /dev/ttyUSB0 at 115200 — the known working configuration
    // for the FTDI USB-RS485 adapter (serial AU05C61S) connected to the
    // Modbus RTU master.
    if (port.empty()) port = "/dev/ttyUSB0";
    if (baud == 0) baud = 115200;

    std::signal(SIGINT, sigint_handler);

    if (do_discover) {
        // ── Discovery mode ───────────────────────────────────────────
        // Wide register bank (512 regs) so we can accept any register address
        // the master reads/writes. All regs start at 0. The decoded frame
        // logger will show exactly which registers the master accesses, what
        // values it writes, and what it reads — this is how we determine the
        // register mapping without any assumptions.
        //
        // Run this, wait for master traffic, then read the log to see:
        //   - Which FCs the master uses (FC03? FC06? FC10?)
        //   - Which register addresses it reads/writes
        //   - What values it sends for open/close commands
        Slave discover_slave(1, 512);

        // Write callback: log every single register write with emphasis.
        discover_slave.set_write_callback([&](uint16_t start, uint16_t count) {
            std::fprintf(stderr, "  ★ WRITE DETECTED: regs 0x%04X–0x%04X (%u regs)\n",
                         start, start + count - 1, count);
            for (uint16_t i = 0; i < count; ++i) {
                std::fprintf(stderr, "    reg[0x%04X] = 0x%04X (%u)\n",
                             start + i, discover_slave.reg(start + i),
                             discover_slave.reg(start + i));
            }
        });

        std::fprintf(stderr, "\n╔═══════════════════════════════════════════════╗\n");
        std::fprintf(stderr, "║  DISCOVERY MODE — Reverse-engineering master  ║\n");
        std::fprintf(stderr, "║  512 regs, all frames decoded, writes logged  ║\n");
        std::fprintf(stderr, "║  Observe which regs the master accesses.      ║\n");
        std::fprintf(stderr, "╚═══════════════════════════════════════════════╝\n\n");

        modbus_rtu_slave::run_serial_slave(discover_slave, port, baud, g_running);

    } else {
        // ── Normal listen mode ───────────────────────────────────────
        // Uses the Zimmer GEP2013IL register map:
        //   Status regs (master writes, we read locally):
        //     0x0000 = Statusword    (IO-Link PDI: gripper status bits)
        //     0x0001 = Diagnose      (IO-Link PDI: diagnostic code)
        //     0x0002 = ActualPosition (IO-Link PDI: jaw position, 0.01mm)
        //   Command regs (we write, master reads and forwards to gripper):
        //     0x000A = Controlword    (IO-Link PDO: control bits)
        //     0x000B = GripMode       (IO-Link PDO: device mode enum)
        //     0x000C = WorkPieceNo    (IO-Link PDO: workpiece number)
        //     0x000D = Reserved
        //     0x000E = PositionTolerance (% of stroke)
        //     0x000F = GripForce      (%)
        //     0x0010 = DriveVelocity  (%)
        //     0x0011 = BasePosition   (0.01mm)
        //     0x0012 = ShiftPosition  (0.01mm)
        //     0x0013 = TeachPosition  (0.01mm)
        //     0x0014 = WorkPosition   (0.01mm)
        //
        // This mapping was determined by:
        //   1. Parsing the Zimmer GEP2013IL-03-B IODD (IO Device Description)
        //   2. Confirming via --discover mode that the master reads FC03
        //      from register 0x000A onward (command regs) and writes FC06/FC10
        //      to registers 0x0000–0x0002 (status regs).
        namespace zg = zimmer_gep2013il;

        Slave serial_slave(1, zg::reg::MIN_REGS);

        // Pre-fill command registers with safe idle defaults.
        zg::PDO idle_cmd{};
        idle_cmd.grip_mode      = zg::GripMode::NORMALLY_OPEN;
        idle_cmd.grip_force     = 50;   // 50%
        idle_cmd.drive_velocity = 30;   // 30%
        zg::write_pdo([&](uint16_t r, uint16_t v){ serial_slave.set_reg(r, v); },
                       idle_cmd);

        // Log when master writes status registers (gripper feedback).
        serial_slave.set_write_callback([&](uint16_t start, uint16_t count) {
            if (start <= zg::reg::ACTUAL_POSITION &&
                start + count > zg::reg::STATUSWORD) {
                auto pdi = zg::read_pdi([&](uint16_t r){ return serial_slave.reg(r); });
                std::fprintf(stderr, "  ── Gripper status update ──\n");
                zg::log_pdi(pdi);
            }
        });

        std::fprintf(stderr, "\n  Register map: Zimmer GEP2013IL-03-B\n");
        std::fprintf(stderr, "  Status: 0x0000–0x0002 (master writes)\n");
        std::fprintf(stderr, "  Command: 0x000A–0x0014 (master reads)\n\n");

        modbus_rtu_slave::run_serial_slave(serial_slave, port, baud, g_running);
    }

    return 0;
}
