#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include "gripper/GripperCommand.hpp"
#include "gripper/GripperCommandPubSubTypes.hpp"
#include "gripper/GripperState.hpp"
#include "gripper/GripperStatePubSubTypes.hpp"

#include <neura_sync/neura_sync_node.hpp>
#include <neura_sync/participant_factory.hpp>
#include <neura_sync/publisher.hpp>
#include <neura_sync/publisher_factory.hpp>
#include <neura_sync/subscriber.hpp>
#include <neura_sync/subscriber_factory.hpp>

using namespace eprosima::fastdds::dds;

static constexpr uint16_t POS_OPEN = 0;
static constexpr uint16_t POS_CLOSE = 1000;
static constexpr uint16_t FORCE_PCT = 50;
static constexpr uint16_t SPEED_PCT = 50;

static constexpr int INIT_WAIT_MS = 3500;
static constexpr int DEFAULT_MOVE_WAIT_MS = 4000;
static constexpr int RESPONSE_TIMEOUT_MS = 1500;
static constexpr int MATCH_TIMEOUT_MS = 5000;

namespace {

uint16_t parse_u16(const std::string& text, const std::string& opt_name)
{
    unsigned long v = 0;
    try {
        v = std::stoul(text, nullptr, 0);
    } catch (const std::exception&) {
        throw std::runtime_error("Invalid value for " + opt_name + ": " + text);
    }
    if (v > 0xFFFFUL) {
        throw std::runtime_error("Out-of-range value for " + opt_name + ": " + text);
    }
    return static_cast<uint16_t>(v);
}

std::string iso_now()
{
    using namespace std::chrono;
    auto now = system_clock::now();
    auto tt = system_clock::to_time_t(now);
    auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
    char buf[32], out[40];
    struct tm tm_info;
    gmtime_r(&tt, &tm_info);
    strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", &tm_info);
    snprintf(out, sizeof(out), "%s.%03ldZ", buf, static_cast<long>(ms.count()));
    return out;
}

void log(const std::string& level, const std::string& msg)
{
    std::cout << "[" << iso_now() << "] [" << std::setw(6) << std::left << level << "] "
              << msg << "\n" << std::flush;
}

std::string hex16(uint16_t v)
{
    char buf[7];
    snprintf(buf, sizeof(buf), "0x%04X", v);
    return buf;
}

struct GripperProfile {
    std::string name;
    std::string device_id;
    uint8_t slave_id;
    uint16_t reg_init;
    uint16_t reg_force;
    uint16_t reg_speed;
    uint16_t reg_position;
    uint16_t status_base;
    uint16_t status_count;
    uint8_t status_read_fc;
    int init_wait_ms;
};

GripperProfile make_profile(const std::string& name)
{
    if (name == "cgc80") {
        return GripperProfile{"cgc80", "cgc80", 2, 0x0100, 0x0101, 0x0104, 0x0103, 0x0200, 3, 4, 3500};
    }
    if (name == "ag160") {
        return GripperProfile{"ag160", "ag160", 1, 0x0100, 0x0101, 0x0102, 0x0103, 0x0200, 3, 4, 3500};
    }
    if (name == "dh56") {
        // DH-5-6 descriptor uses FC03 for status reads and per-DOF control registers.
        return GripperProfile{"dh56", "dh56", 3, 0x0100, 0x0107, 0x010D, 0x0102, 0x0200, 3, 3, 3500};
    }
    throw std::runtime_error("Unsupported gripper profile: " + name);
}

} // namespace

class DdsValidator {
public:
    DdsValidator(int domain_id, std::string device_id)
        : device_id_(std::move(device_id))
    {
        auto* pf = neura::sync::ParticipantFactory::getInstance();
        participant_ = pf->createDefaultParticipant(domain_id);
        if (!participant_) {
            throw std::runtime_error("DdsValidator: failed to create participant");
        }

        node_ = std::make_shared<neura::sync::NeuraSyncNode>(participant_);

        auto pub_fac = neura::sync::PublisherFactory::getInstance(participant_);
        auto sub_fac = neura::sync::SubscriberFactory::getInstance(participant_);

        constexpr int64_t max_blocking_ns = 500000000;

        cmd_pub_ = pub_fac->createCriticalDataPublisher<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", "qnc/gripper/command", max_blocking_ns);
        node_->add_publisher(cmd_pub_);

        node_->add_subscriber(
            sub_fac->createCriticalDataSubscriber<
                qnc::gripper::GripperState, qnc::gripper::GripperStatePubSubType>(
                "gripper_state_sub", "qnc/gripper/state",
                [this](const qnc::gripper::GripperState& msg) {
                    on_state(msg);
                }));
    }

    bool wait_for_bridge(int timeout_ms = MATCH_TIMEOUT_MS)
    {
        log("INFO", "Waiting for qnc_bridge DDS match on qnc/gripper/command ...");
        auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);
        while (std::chrono::steady_clock::now() < deadline) {
            if (cmd_pub_->hasListener()) {
                log("INFO", "DDS endpoint matched - qnc_bridge is ready");
                return true;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        log("WARN", "No DDS match after " + std::to_string(timeout_ms) + " ms - proceeding anyway");
        return false;
    }

    void send_write(uint8_t slave, uint16_t reg, uint16_t value, const std::string& tag)
    {
        qnc::gripper::GripperCommand cmd;
        cmd.device_id(device_id_);
        cmd.command_type(qnc::gripper::GripperCommandType::CMD_RAW_MODBUS);
        cmd.mode(qnc::gripper::GripperMode::MODE_BASIC);
        cmd.slave_id_hint(slave);
        cmd.timeout_ms(500);
        cmd.blocking(false);
        cmd.timeout(0.0f);
        cmd.prefer_multi_write(false);
        cmd.raw_read_start_register(0);
        cmd.raw_read_count(0);
        cmd.raw_read_fc(0);

        qnc::gripper::RegisterWrite rw;
        rw.register_address(reg);
        rw.value(value);
        cmd.raw_writes().push_back(rw);

        cmd.tag(tag);
        cmd.timestamp(iso_now());

        log("CMD", "Write slave=" + std::to_string(slave)
            + " reg=" + hex16(reg)
            + " val=" + std::to_string(value)
            + " tag=" + tag);

        node_->set_publisher_buffer<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", cmd);
        node_->publish("gripper_cmd_pub");
    }

    void send_read(uint8_t slave, uint16_t start_reg, uint16_t count, uint8_t read_fc,
                   const std::string& tag)
    {
        qnc::gripper::GripperCommand cmd;
        cmd.device_id(device_id_);
        cmd.command_type(qnc::gripper::GripperCommandType::CMD_RAW_MODBUS);
        cmd.mode(qnc::gripper::GripperMode::MODE_BASIC);
        cmd.slave_id_hint(slave);
        cmd.timeout_ms(800);
        cmd.blocking(false);
        cmd.timeout(0.0f);
        cmd.prefer_multi_write(false);
        cmd.raw_read_start_register(start_reg);
        cmd.raw_read_count(count);
        cmd.raw_read_fc(read_fc);
        cmd.tag(tag);
        cmd.timestamp(iso_now());

        log("CMD", "Read  slave=" + std::to_string(slave)
            + " reg=" + hex16(start_reg)
            + " count=" + std::to_string(count)
            + " fc=" + std::to_string(static_cast<int>(read_fc))
            + " tag=" + tag);

        node_->set_publisher_buffer<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", cmd);
        node_->publish("gripper_cmd_pub");
    }

    bool wait_for_tag(const std::string& tag, int timeout_ms = RESPONSE_TIMEOUT_MS)
    {
        std::unique_lock<std::mutex> lk(state_mutex_);
        bool arrived = state_cv_.wait_for(
            lk, std::chrono::milliseconds(timeout_ms),
            [&] { return state_by_tag_.count(tag) > 0; });

        if (!arrived) {
            log("FAIL", "Timeout (" + std::to_string(timeout_ms)
                + " ms) waiting for tag=" + tag);
            return false;
        }

        const auto& st = state_by_tag_.at(tag);
        bool ok = (st.error_code() == 0 && st.bridge_error_code() == 0);
        if (ok) {
            log("OK", "State tag=" + tag + " -> success");
        } else {
            log("FAIL", "State tag=" + tag
                + " -> error_code=" + std::to_string(st.error_code())
                + " bridge_error_code=" + std::to_string(st.bridge_error_code()));
        }
        return ok;
    }

    bool wait_for_status(const std::string& tag, int timeout_ms = RESPONSE_TIMEOUT_MS)
    {
        std::unique_lock<std::mutex> lk(state_mutex_);
        bool arrived = state_cv_.wait_for(
            lk, std::chrono::milliseconds(timeout_ms),
            [&] { return state_by_tag_.count(tag) > 0; });

        if (!arrived) {
            log("FAIL", "Timeout (" + std::to_string(timeout_ms)
                + " ms) waiting for status tag=" + tag);
            return false;
        }

        const auto& st = state_by_tag_.at(tag);
        bool ok = (st.error_code() == 0 && st.bridge_error_code() == 0);

        std::ostringstream regs;
        regs << "[";
        if (st.has_transport_snapshot()) {
            const auto& data = st.transport_snapshot().data();
            for (size_t i = 0; i < data.size(); ++i) {
                if (i > 0) regs << ", ";
                regs << hex16(data[i]);
            }
        }
        regs << "]";

        if (ok) {
            log("OK", "Status tag=" + tag + " registers=" + regs.str());
        } else {
            log("FAIL", "Status tag=" + tag
                + " error_code=" + std::to_string(st.error_code())
                + " bridge_error_code=" + std::to_string(st.bridge_error_code())
                + " registers=" + regs.str());
        }
        return ok;
    }

private:
    void on_state(const qnc::gripper::GripperState& state)
    {
        const std::string tag(state.last_command_tag().c_str());
        if (tag.empty()) {
            return;
        }

        log("RECV", "State tag=" + tag
            + " ec=" + std::to_string(state.error_code())
            + " bec=" + std::to_string(state.bridge_error_code())
            + " has_snapshot=" + std::to_string(static_cast<int>(state.has_transport_snapshot())));

        {
            std::lock_guard<std::mutex> lk(state_mutex_);
            state_by_tag_[tag] = state;
        }
        state_cv_.notify_all();
    }

    DomainParticipant* participant_ = nullptr;
    std::shared_ptr<neura::sync::NeuraSyncNode> node_;
    std::shared_ptr<neura::sync::Publisher<
        qnc::gripper::GripperCommand,
        qnc::gripper::GripperCommandPubSubType>> cmd_pub_;

    std::mutex state_mutex_;
    std::condition_variable state_cv_;
    std::map<std::string, qnc::gripper::GripperState> state_by_tag_;
    std::string device_id_;
};

bool step_init(DdsValidator& dds, const GripperProfile& profile)
{
    log("STEP", "-- INIT -----------------------------------------------");
    dds.send_write(profile.slave_id, profile.reg_init, 1, profile.name + "_init");
    if (!dds.wait_for_tag(profile.name + "_init")) {
        return false;
    }
    log("INFO", "Waiting " + std::to_string(profile.init_wait_ms)
        + " ms for " + profile.name + " initialization to complete ...");
    std::this_thread::sleep_for(std::chrono::milliseconds(profile.init_wait_ms));
    log("INFO", "Calibration wait complete");
    return true;
}

bool step_status(
    DdsValidator& dds,
    const GripperProfile& profile,
    const std::string& label,
    int status_retries,
    int status_settle_ms)
{
    log("STEP", "-- STATUS [" + label + "] ----------------------------------");
    const int attempts = 1 + (status_retries > 0 ? status_retries : 0);

    for (int attempt = 1; attempt <= attempts; ++attempt) {
        const std::string tag = profile.name + "_status_" + label + "_a" + std::to_string(attempt);
        if (attempt > 1) {
            log("INFO", "Retrying status read (attempt " + std::to_string(attempt)
                + "/" + std::to_string(attempts) + ")");
            if (status_settle_ms > 0) {
                std::this_thread::sleep_for(std::chrono::milliseconds(status_settle_ms));
            }
        }

        dds.send_read(
            profile.slave_id,
            profile.status_base,
            profile.status_count,
            profile.status_read_fc,
            tag);

        if (dds.wait_for_status(tag)) {
            return true;
        }
    }

    return false;
}

bool step_close(DdsValidator& dds, const GripperProfile& profile, int move_wait_ms)
{
    log("STEP", "-- CLOSE (position=1000) -------------------------------");
    dds.send_write(profile.slave_id, profile.reg_force, FORCE_PCT, profile.name + "_force_close");
    dds.send_write(profile.slave_id, profile.reg_speed, SPEED_PCT, profile.name + "_speed_close");
    dds.send_write(profile.slave_id, profile.reg_position, POS_CLOSE, profile.name + "_pos_close");

    bool ok_force = dds.wait_for_tag(profile.name + "_force_close");
    bool ok_speed = dds.wait_for_tag(profile.name + "_speed_close");
    bool ok_pos = dds.wait_for_tag(profile.name + "_pos_close");

    log("INFO", "Waiting " + std::to_string(move_wait_ms)
        + " ms for jaw to reach closed position ...");
    std::this_thread::sleep_for(std::chrono::milliseconds(move_wait_ms));
    return ok_force && ok_speed && ok_pos;
}

bool step_open(DdsValidator& dds, const GripperProfile& profile, int move_wait_ms)
{
    log("STEP", "-- OPEN (position=0) ----------------------------------");
    dds.send_write(profile.slave_id, profile.reg_force, FORCE_PCT, profile.name + "_force_open");
    dds.send_write(profile.slave_id, profile.reg_speed, SPEED_PCT, profile.name + "_speed_open");
    dds.send_write(profile.slave_id, profile.reg_position, POS_OPEN, profile.name + "_pos_open");

    bool ok_force = dds.wait_for_tag(profile.name + "_force_open");
    bool ok_speed = dds.wait_for_tag(profile.name + "_speed_open");
    bool ok_pos = dds.wait_for_tag(profile.name + "_pos_open");

    log("INFO", "Waiting " + std::to_string(move_wait_ms)
        + " ms for jaw to reach open position ...");
    std::this_thread::sleep_for(std::chrono::milliseconds(move_wait_ms));
    return ok_force && ok_speed && ok_pos;
}

static void usage(const char* prog)
{
    std::cout
        << "Usage: " << prog << " [--gripper <cgc80|ag160|dh56>] [--slave-id <id>] [--domain <id>] [--move-wait-ms <ms>]\n"
        << "                 [--status-retries <n>] [--status-settle-ms <ms>] [--dh56-speed-reg <reg>]\n"
        << "\n"
        << "Options:\n"
        << "  --gripper <name>     Gripper profile: cgc80 | ag160 | dh56 (default: cgc80)\n"
        << "  --slave-id <id>      Override DDS slave_id hint for selected profile\n"
        << "  --domain <id>        DDS domain ID (default: 0)\n"
        << "  --move-wait-ms <ms>  Time to wait for jaw movement (default: "
        << DEFAULT_MOVE_WAIT_MS << " ms)\n"
        << "  --status-retries <n> Extra retries for each status read (default: ag160=2, others=0)\n"
        << "  --status-settle-ms <ms>  Delay before each status retry (default: ag160=120, others=0)\n"
        << "  --dh56-speed-reg <reg>   Override DH56 speed register (decimal or 0x-prefixed hex)\n";
}

int main(int argc, char** argv)
{
    int domain_id = 0;
    int move_wait_ms = DEFAULT_MOVE_WAIT_MS;
    std::string gripper_name = "cgc80";
    int slave_id_override = -1;
    int status_retries = -1;
    int status_settle_ms = -1;
    bool has_dh56_speed_reg_override = false;
    uint16_t dh56_speed_reg_override = 0;

    for (int i = 1; i < argc; ++i) {
        std::string a(argv[i]);
        if ((a == "--domain" || a == "-d") && i + 1 < argc) {
            domain_id = std::stoi(argv[++i]);
        } else if (a == "--gripper" && i + 1 < argc) {
            gripper_name = argv[++i];
        } else if (a == "--slave-id" && i + 1 < argc) {
            slave_id_override = std::stoi(argv[++i]);
        } else if (a == "--move-wait-ms" && i + 1 < argc) {
            move_wait_ms = std::stoi(argv[++i]);
        } else if (a == "--status-retries" && i + 1 < argc) {
            status_retries = std::stoi(argv[++i]);
        } else if (a == "--status-settle-ms" && i + 1 < argc) {
            status_settle_ms = std::stoi(argv[++i]);
        } else if (a == "--dh56-speed-reg" && i + 1 < argc) {
            dh56_speed_reg_override = parse_u16(argv[++i], "--dh56-speed-reg");
            has_dh56_speed_reg_override = true;
        } else if (a == "--help" || a == "-h") {
            usage(argv[0]);
            return 0;
        } else {
            std::cerr << "Unknown argument: " << a << "\n";
            usage(argv[0]);
            return 2;
        }
    }

    GripperProfile profile = make_profile(gripper_name);

    if (status_retries < 0) {
        status_retries = (profile.name == "ag160") ? 2 : 0;
    }
    if (status_settle_ms < 0) {
        status_settle_ms = (profile.name == "ag160") ? 120 : 0;
    }

    if (slave_id_override >= 0) {
        profile.slave_id = static_cast<uint8_t>(slave_id_override);
    }
    if (has_dh56_speed_reg_override && profile.name == "dh56") {
        profile.reg_speed = dh56_speed_reg_override;
    }

    log("INFO", "=== Gripper Runtime Validator ===");
    log("INFO", "profile       = " + profile.name);
    log("INFO", "DDS domain_id   = " + std::to_string(domain_id));
    log("INFO", "slave_id hint   = " + std::to_string(profile.slave_id));
    log("INFO", "registers       = init=" + hex16(profile.reg_init)
        + " force=" + hex16(profile.reg_force)
        + " speed=" + hex16(profile.reg_speed)
        + " pos=" + hex16(profile.reg_position)
        + " status=" + hex16(profile.status_base)
        + " fc=" + std::to_string(profile.status_read_fc));
    log("INFO", "move_wait_ms    = " + std::to_string(move_wait_ms));
    log("INFO", "status_retries  = " + std::to_string(status_retries));
    log("INFO", "status_settle_ms= " + std::to_string(status_settle_ms));

    DdsValidator dds(domain_id, profile.device_id);
    dds.wait_for_bridge();

    struct StepResult { std::string name; bool ok; };
    std::vector<StepResult> results;

    results.push_back({"init",              step_init(dds, profile)});
    results.push_back({"status_post_init",  step_status(dds, profile, "post_init", status_retries, status_settle_ms)});
    results.push_back({"close",             step_close(dds, profile, move_wait_ms)});
    results.push_back({"status_post_close", step_status(dds, profile, "post_close", status_retries, status_settle_ms)});
    results.push_back({"open",              step_open(dds, profile, move_wait_ms)});
    results.push_back({"status_post_open",  step_status(dds, profile, "post_open", status_retries, status_settle_ms)});

    log("INFO", "=== SUMMARY =============================================");
    int passed = 0;
    int failed = 0;
    for (const auto& r : results) {
        if (r.ok) {
            log("PASS", "step=" + r.name);
            ++passed;
        } else {
            log("FAIL", "step=" + r.name);
            ++failed;
        }
    }
    const int total = passed + failed;
    log("INFO", std::to_string(passed) + "/" + std::to_string(total) + " steps passed");

    if (failed > 0) {
        log("RESULT", "VALIDATION FAILED - " + std::to_string(failed)
            + " of " + std::to_string(total) + " step(s) did not pass");
        return 1;
    }

    log("RESULT", "VALIDATION PASSED - " + profile.name + " communication verified");
    return 0;
}
