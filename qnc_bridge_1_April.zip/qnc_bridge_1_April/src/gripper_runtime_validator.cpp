#include "gripper_runtime_validator.hpp"
#include <atomic>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <thread>

namespace qnc {
namespace gripper {

GripperRuntimeValidator::GripperRuntimeValidator(
    const std::string& device_id,
    uint32_t domain_id)
    : device_id_(device_id)
    , domain_id_(domain_id)
{}

GripperRuntimeValidator::~GripperRuntimeValidator()
{
    node_.reset();
    participant_ = nullptr;
}

bool GripperRuntimeValidator::initialize_dds_()
{
    try {
        auto* part_factory = neura::sync::ParticipantFactory::getInstance();
        participant_ = part_factory->createDefaultParticipant(static_cast<int>(domain_id_));
        if (!participant_) {
            return false;
        }

        node_ = std::make_shared<neura::sync::NeuraSyncNode>(participant_);

        auto pub_factory = neura::sync::PublisherFactory::getInstance(participant_);
        auto sub_factory = neura::sync::SubscriberFactory::getInstance(participant_);

        constexpr int64_t max_blocking_ns = 500000000; // 500 ms

        cmd_publisher_ = pub_factory->createCriticalDataPublisher<
            qnc::gripper::GripperCommand,
            qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub",
            "qnc/gripper/command",
            max_blocking_ns);
        node_->add_publisher(cmd_publisher_);

        state_subscriber_ = sub_factory->createCriticalDataSubscriber<
            qnc::gripper::GripperState,
            qnc::gripper::GripperStatePubSubType>(
            "gripper_state_sub",
            "qnc/gripper/state",
            [this](const qnc::gripper::GripperState& msg) {
                this->on_state_received_(msg);
            });
        node_->add_subscriber(state_subscriber_);

        return true;
    } catch (...) {
        return false;
    }
}

void GripperRuntimeValidator::on_state_received_(
    const qnc::gripper::GripperState& state)
{
    if (std::string(state.device_id().c_str()) != device_id_) {
        return;
    }
    // Match by tag when a pending tag is set, so stale or interleaved
    // state messages from other commands do not trigger the waiting validator.
    {
        std::unique_lock<std::mutex> lock(state_mutex_);
        if (!pending_tag_.empty()
            && std::string(state.last_command_tag().c_str()) != pending_tag_) {
            return;
        }
        last_state_ = state;
        state_received_.store(true);
    }
    state_cv_.notify_all();
}

bool GripperRuntimeValidator::position_matches_(
    float cmd,
    float state) const
{
    return std::fabs(cmd - state) <= position_tolerance_;
}

bool GripperRuntimeValidator::force_matches_(
    float cmd,
    float state) const
{
    if (state < 0.001f) return true;
    return std::fabs(cmd - state) <= force_tolerance_;
}

bool GripperRuntimeValidator::speed_matches_(
    float cmd,
    float state) const
{
    if (cmd < 0.001f) return true;
    if (state < 0.001f) return true;
    return std::fabs(cmd - state) <= speed_tolerance_;
}

std::string GripperRuntimeValidator::format_timestamp_()
{
    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&time), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

std::string GripperRuntimeValidator::format_mode_(GripperMode mode)
{
    switch (mode) {
        case GripperMode::MODE_POSITION:
            return "POSITION";
        case GripperMode::MODE_FORCE:
            return "FORCE";
        case GripperMode::MODE_BASIC:
            return "BASIC";
        default:
            return "UNKNOWN";
    }
}

std::string GripperRuntimeValidator::format_status_(GripperStatus status)
{
    switch (status) {
        case GripperStatus::STATUS_UNKNOWN:
            return "UNKNOWN";
        case GripperStatus::STATUS_IDLE:
            return "IDLE";
        case GripperStatus::STATUS_MOVING:
            return "MOVING";
        case GripperStatus::STATUS_HOLDING:
            return "HOLDING";
        case GripperStatus::STATUS_ERROR:
            return "ERROR";
        default:
            return "?";
    }
}

ValidationResult GripperRuntimeValidator::validate_responsiveness(
    uint32_t timeout_ms,
    std::ostream* log_stream)
{
    GripperCommand cmd;
    cmd.device_id(device_id_);
    cmd.command_type(GripperCommandType::CMD_SETPOINT);
    cmd.position(0.5f);
    cmd.max_force(0.5f);
    cmd.max_speed(0.3f);
    cmd.mode(GripperMode::MODE_POSITION);
    cmd.blocking(false);
    cmd.timeout(0.0f);
    cmd.timeout_ms(timeout_ms);

    static std::atomic<uint32_t> cmd_counter{0};
    cmd.tag("validation_" + std::to_string(cmd_counter++));

    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    char ts_buf[32] = {};
    std::strftime(ts_buf, sizeof(ts_buf), "%Y-%m-%dT%H:%M:%SZ", std::gmtime(&time));
    cmd.timestamp(ts_buf);

    return validate_internal_(cmd, timeout_ms, log_stream);
}

ValidationResult GripperRuntimeValidator::validate_with_command(
    float position_cmd,
    float force_cmd,
    float speed_cmd,
    GripperMode mode,
    uint32_t timeout_ms,
    std::ostream* log_stream)
{
    GripperCommand cmd;
    cmd.device_id(device_id_);
    cmd.command_type(GripperCommandType::CMD_SETPOINT);
    cmd.position(position_cmd);
    cmd.max_force(force_cmd);
    cmd.max_speed(speed_cmd);
    cmd.mode(mode);
    cmd.blocking(false);
    cmd.timeout(0.0f);
    cmd.timeout_ms(timeout_ms);

    static std::atomic<uint32_t> cmd_counter{0};
    cmd.tag("validation_" + std::to_string(cmd_counter++));

    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    char ts_buf[32] = {};
    std::strftime(ts_buf, sizeof(ts_buf), "%Y-%m-%dT%H:%M:%SZ", std::gmtime(&time));
    cmd.timestamp(ts_buf);

    return validate_internal_(cmd, timeout_ms, log_stream);
}

std::vector<ValidationResult> GripperRuntimeValidator::validate_sequence(
    const std::vector<std::tuple<float, float, float, GripperMode>>& commands,
    uint32_t timeout_ms,
    std::ostream* log_stream)
{
    std::vector<ValidationResult> results;
    results.reserve(commands.size());

    for (size_t i = 0; i < commands.size(); ++i) {
        auto [pos, force, speed, mode] = commands[i];

        if (log_stream) {
            *log_stream << "\n--- Command " << (i + 1) << "/" << commands.size()
                       << " ---\n";
        }

        results.emplace_back(validate_with_command(
            pos, force, speed, mode, timeout_ms, log_stream));

        if (i < commands.size() - 1) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }

    return results;
}

ValidationResult GripperRuntimeValidator::validate_internal_(
    const GripperCommand& cmd,
    uint32_t timeout_ms,
    std::ostream* log_stream)
{
    ValidationResult result;
    result.device_id = device_id_;
    result.commanded_position = cmd.position();
    result.commanded_force = cmd.max_force();
    result.commanded_speed = cmd.max_speed();
    result.commanded_mode = cmd.mode();

    auto validation_start = std::chrono::high_resolution_clock::now();

    if (log_stream) {
        *log_stream << "\n[validator] start " << format_timestamp_() << "\n";
        *log_stream << "Device ID:      " << device_id_ << "\n";
        *log_stream << "Timeout:        " << timeout_ms << " ms\n";
        *log_stream << "\n--- Command Being Issued ---\n";
        *log_stream << "  Position:     " << std::fixed << std::setprecision(3)
                   << cmd.position() << "\n";
        *log_stream << "  Force:        " << cmd.max_force() << "\n";
        *log_stream << "  Speed:        " << cmd.max_speed() << "\n";
        *log_stream << "  Mode:         " << format_mode_(cmd.mode()) << "\n";
        *log_stream << "  Tag:          " << std::string(cmd.tag().c_str()) << "\n";
        *log_stream << "  Timestamp:    " << std::string(cmd.timestamp().c_str()) << "\n";
    }

    if (!cmd_publisher_) {
        if (!initialize_dds_()) {
            result.status = ValidationStatus::COMMUNICATION_ERROR;
            result.message = "Failed to initialize DDS infrastructure";
            result.diagnostics = "NeuraSync participant/publisher/subscriber creation failed";
            if (log_stream) {
                *log_stream << "\n[error] " << result.message << "\n";
                *log_stream << "   " << result.diagnostics << "\n";
            }
            return result;
        }
    }

    {
        std::unique_lock<std::mutex> lock(state_mutex_);
        pending_tag_ = std::string(cmd.tag().c_str());
        state_received_.store(false);
        last_state_.reset();
    }

    node_->set_publisher_buffer<
        qnc::gripper::GripperCommand,
        qnc::gripper::GripperCommandPubSubType>(
        "gripper_cmd_pub", cmd);
    node_->publish("gripper_cmd_pub");

    if (log_stream) {
        *log_stream << "\n[ok] command published to qnc/gripper/command\n";
    }

    if (log_stream) {
        *log_stream << "\n--- Waiting for State Feedback ---\n";
    }

    std::unique_lock<std::mutex> lock(state_mutex_);
    bool state_arrived = state_cv_.wait_for(
        lock,
        std::chrono::milliseconds(timeout_ms),
        [this]() { return state_received_.load(); });

    auto validation_end = std::chrono::high_resolution_clock::now();
    result.latency_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        validation_end - validation_start);

    // Clear pending tag so future callbacks are not accidentally filtered.
    {
        std::lock_guard<std::mutex> tl(state_mutex_);
        pending_tag_.clear();
    }

    if (!state_arrived || !last_state_.has_value()) {
        result.status = ValidationStatus::TIMEOUT;
        result.message = "No state feedback received within timeout period";
        result.diagnostics = "Waited " + std::to_string(timeout_ms) + "ms for state on topic qnc/gripper/state";

        if (log_stream) {
            *log_stream << "\n[timeout] " << result.message << "\n";
            *log_stream << "   Latency: " << result.latency_ms.count() << " ms\n";
        }

        return result;
    }

    const auto& state = last_state_.value();
    result.received_position = state.position();
    result.received_force = state.force();
    result.received_speed = state.speed();
    result.received_status = state.status();

    if (log_stream) {
        *log_stream << "\n[ok] state feedback received\n";
        *log_stream << "   Latency: " << result.latency_ms.count() << " ms\n";
        *log_stream << "\n--- State Received ---\n";
        *log_stream << "  Position:     " << std::fixed << std::setprecision(3)
                   << state.position() << "\n";
        *log_stream << "  Force:        " << state.force() << "\n";
        *log_stream << "  Speed:        " << state.speed() << "\n";
        *log_stream << "  Status:       " << format_status_(state.status()) << "\n";
        *log_stream << "  Grasp Result: " << static_cast<int>(state.grasp_result()) << "\n";
        *log_stream << "  Error Code:   " << state.error_code() << "\n";
        *log_stream << "  Message:      " << std::string(state.message().c_str()) << "\n";
    }

    bool pos_ok = position_matches_(cmd.position(), state.position());
    bool force_ok = force_matches_(cmd.max_force(), state.force());
    bool speed_ok = speed_matches_(cmd.max_speed(), state.speed());

    if (log_stream) {
        *log_stream << "\n--- Validation Results ---\n";
        *log_stream << "  Position Match: " << (pos_ok ? "OK" : "FAIL")
                   << " (cmd=" << cmd.position() << ", rcv=" << state.position()
                   << ", tol=" << position_tolerance_ << ")\n";
        *log_stream << "  Force Match:    " << (force_ok ? "OK" : "FAIL")
                   << " (cmd=" << cmd.max_force() << ", rcv=" << state.force()
                   << ", tol=" << force_tolerance_ << ")\n";
        *log_stream << "  Speed Match:    " << (speed_ok ? "OK" : "FAIL")
                   << " (cmd=" << cmd.max_speed() << ", rcv=" << state.speed()
                   << ", tol=" << speed_tolerance_ << ")\n";
    }

    if (!pos_ok || !force_ok || !speed_ok) {
        result.status = ValidationStatus::STATE_MISMATCH;
        result.message = "State feedback does not match commanded parameters";
        std::ostringstream diag;
        diag << "pos(" << cmd.position() << " vs " << state.position() << "), "
             << "force(" << cmd.max_force() << " vs " << state.force() << "), "
             << "speed(" << cmd.max_speed() << " vs " << state.speed() << ")";
        result.diagnostics = diag.str();

        if (log_stream) {
            *log_stream << "\n[fail] " << result.message << "\n";
        }

        return result;
    }

    result.status = ValidationStatus::SUCCESS;
    result.message = "Command/state validation passed";
    result.diagnostics = "state=" + format_status_(state.status());

    if (log_stream) {
        *log_stream << "\n[pass] validation passed\n";
    }

    return result;
}

} // namespace gripper
} // namespace qnc
