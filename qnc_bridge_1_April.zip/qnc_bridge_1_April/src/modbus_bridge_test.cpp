/**
 * modbus_bridge_test.cpp — Integration tests for Modbus bridge and data synchronization
 *
 * Tests:
 *   - Bridge initialization and serial port management
 *   - Register read/write through bridge with thread safety
 *   - Data synchronization between DDS state and Modbus registers
 *   - Command extraction from Modbus writes
 *   - Error handling and recovery
 *
 * Compile:
 *   g++ -std=c++17 -Iinclude -o modbus_bridge_test src/modbus_bridge_test.cpp -pthread
 *
 * Run:
 *   ./modbus_bridge_test             # Run all tests
 *   ./modbus_bridge_test --verbose   # Run with detailed output
 */

#include "modbus_bridge.hpp"
#include "modbus_data_sync.hpp"
#include "serial_utils.hpp"

#include <cassert>
#include <cstdio>
#include <iostream>
#include <memory>
#include <thread>

// ═══════════════════════════════════════════════════════════════════════════
// Test Utilities
// ═══════════════════════════════════════════════════════════════════════════

static int test_pass = 0;
static int test_fail = 0;
static bool verbose = false;

void test_result(const char* name, bool condition) {
    if (condition) {
        std::printf("  ✓ %s\n", name);
        test_pass++;
    } else {
        std::printf("  ✗ %s\n", name);
        test_fail++;
    }
}

#define TEST(name, condition) test_result(name, condition)

// ═══════════════════════════════════════════════════════════════════════════
// TEST 1: Bridge Initialization
// ═══════════════════════════════════════════════════════════════════════════

void test_bridge_initialization() {
    std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    std::printf("║  TEST 1: Bridge Initialization & Register Access        ║\n");
    std::printf("╚═══════════════════════════════════════════════════════════╝\n");

    modbus_bridge::Config config;
    config.slave_address = 1;
    config.num_registers = 128;
    config.verbose = verbose;

    modbus_bridge::Bridge bridge(config);

    // Test 1a: Register read/write
    bridge.set_register(0, 0x1234);
    TEST("Set register 0 = 0x1234", bridge.get_register(0) == 0x1234);

    bridge.set_register(10, 0xABCD);
    TEST("Set register 10 = 0xABCD", bridge.get_register(10) == 0xABCD);

    // Test 1b: Bulk register operations
    std::vector<uint16_t> values = {0x1111, 0x2222, 0x3333};
    bridge.set_registers(5, values);
    auto read_back = bridge.get_registers(5, 3);
    TEST("Bulk write/read 3 regs", read_back == values);

    // Test 1c: Write callback
    uint16_t cb_start = 0xFFFF;
    uint16_t cb_count = 0;
    bridge.on_register_write([&](uint16_t start, uint16_t count) {
        cb_start = start;
        cb_count = count;
    });

    // Direct host writes should not trigger the Modbus master-write callback.
    bridge.set_register(15, 0x5678);
    TEST("Host write does not trigger callback", cb_start == 0xFFFF && cb_count == 0);

    std::printf("\n  Result: %d passed, %d failed\n\n", test_pass, test_fail);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 2: Data Synchronization
// ═══════════════════════════════════════════════════════════════════════════

void test_data_synchronization() {
    std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    std::printf("║  TEST 2: Data Synchronization (DDS ↔ Modbus)            ║\n");
    std::printf("╚═══════════════════════════════════════════════════════════╝\n");

    modbus_data_sync::Synchronizer sync;

    // Test 2a: DDS state → Modbus registers
    modbus_data_sync::GripperState state;
    state.ready = true;
    state.moving = false;
    state.error = false;
    state.error_code = 0;
    state.actual_position_units = 1500;  // 15.00mm
    state.target_position_units = 2000;  // 20.00mm

    auto updates = sync.update_from_dds(state);

    // Should have 4 register updates
    TEST("Status update generates 4 registers", updates.size() == 4);

    // Check status word bits
    uint16_t status_word = updates[0].second;
    TEST("Status word: READY bit set", (status_word & modbus_data_sync::STATUS_READY) != 0);
    TEST("Status word: MOVING bit clear", (status_word & modbus_data_sync::STATUS_MOVING) == 0);
    TEST("Status word: ERROR bit clear", (status_word & modbus_data_sync::STATUS_ERROR) == 0);

    // Check register values
    bool pos_correct = (updates[2].first == modbus_data_sync::status_regs::ACTUAL_POSITION &&
                        updates[2].second == 1500);
    TEST("Actual position register set", pos_correct);

    // Test 2b: Modbus registers → Command extraction
    modbus_bridge::Config bridge_config;
    bridge_config.slave_address = 1;
    bridge_config.num_registers = 128;
    modbus_bridge::Bridge bridge(bridge_config);

    // Simulate master writing command registers
    bridge.set_register(modbus_data_sync::command_regs::CONTROL_WORD,
                        modbus_data_sync::CONTROL_GRIP);
    bridge.set_register(modbus_data_sync::command_regs::GRIP_MODE,
                        static_cast<uint16_t>(modbus_data_sync::GripMode::GRIP));
    bridge.set_register(modbus_data_sync::command_regs::GRIP_FORCE_PCT, 75);
    bridge.set_register(modbus_data_sync::command_regs::GRIP_VELOCITY_PCT, 50);

    // Extract command
    sync.on_modbus_write(modbus_data_sync::command_regs::CONTROL_WORD, 6,
                         [&](uint16_t addr) { return bridge.get_register(addr); });

    auto cmd = sync.get_last_command();
    TEST("Command: grip bit set", cmd.grip);
    TEST("Command: force = 75%", cmd.force_percent == 75);
    TEST("Command: velocity = 50%", cmd.velocity_percent == 50);

    std::printf("\n  Result: %d passed, %d failed\n\n", test_pass, test_fail);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 3: Command Extraction
// ═══════════════════════════════════════════════════════════════════════════

void test_command_extraction() {
    std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    std::printf("║  TEST 3: Command Extraction                              ║\n");
    std::printf("╚═══════════════════════════════════════════════════════════╝\n");

    modbus_data_sync::Synchronizer sync;
    modbus_data_sync::GripperCommand last_cmd;
    bool callback_fired = false;

    sync.set_on_command([&](const modbus_data_sync::GripperCommand& cmd) {
        last_cmd = cmd;
        callback_fired = true;
    });

    // Test 3a: Grip command
    modbus_bridge::Bridge bridge1(modbus_bridge::Config{.num_registers = 128});
    bridge1.set_register(modbus_data_sync::command_regs::CONTROL_WORD,
                         modbus_data_sync::CONTROL_GRIP);
    bridge1.set_register(modbus_data_sync::command_regs::GRIP_MODE, 0);  // GRIP mode
    bridge1.set_register(modbus_data_sync::command_regs::GRIP_FORCE_PCT, 90);

    callback_fired = false;
    sync.on_modbus_write(modbus_data_sync::command_regs::CONTROL_WORD, 1,
                         [&](uint16_t addr) { return bridge1.get_register(addr); });

    TEST("Callback fired for grip command", callback_fired);
    TEST("Grip command received", last_cmd.grip);
    TEST("Force = 90%", last_cmd.force_percent == 90);

    // Test 3b: Release command
    modbus_bridge::Bridge bridge2(modbus_bridge::Config{.num_registers = 128});
    bridge2.set_register(modbus_data_sync::command_regs::CONTROL_WORD,
                         modbus_data_sync::CONTROL_RELEASE);

    callback_fired = false;
    sync.on_modbus_write(modbus_data_sync::command_regs::CONTROL_WORD, 1,
                         [&](uint16_t addr) { return bridge2.get_register(addr); });

    TEST("Release command received", last_cmd.release);

    // Test 3c: Stop command
    modbus_bridge::Bridge bridge3(modbus_bridge::Config{.num_registers = 128});
    bridge3.set_register(modbus_data_sync::command_regs::CONTROL_WORD,
                         modbus_data_sync::CONTROL_STOP);

    callback_fired = false;
    sync.on_modbus_write(modbus_data_sync::command_regs::CONTROL_WORD, 1,
                         [&](uint16_t addr) { return bridge3.get_register(addr); });

    TEST("Stop command received", last_cmd.stop);

    std::printf("\n  Result: %d passed, %d failed\n\n", test_pass, test_fail);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 4: Thread Safety
// ═══════════════════════════════════════════════════════════════════════════

void test_thread_safety() {
    std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    std::printf("║  TEST 4: Thread Safety                                   ║\n");
    std::printf("╚═══════════════════════════════════════════════════════════╝\n");

    modbus_bridge::Config config;
    config.num_registers = 256;
    modbus_bridge::Bridge bridge(config);

    // Set initial value
    bridge.set_register(0, 0);

    // Spawn multiple reader and writer threads
    std::vector<std::thread> threads;
    int num_threads = 4;
    int iterations = 100;

    // Writer threads
    for (int i = 0; i < num_threads / 2; ++i) {
        threads.emplace_back([&, i]() {
            for (int j = 0; j < iterations; ++j) {
                bridge.set_register(0, (i * 100) + j);
                std::this_thread::yield();
            }
        });
    }

    // Reader threads
    int read_count = 0;
    for (int i = 0; i < num_threads / 2; ++i) {
        threads.emplace_back([&, i]() {
            for (int j = 0; j < iterations; ++j) {
                volatile uint16_t val = bridge.get_register(0);  // Use value to prevent optimization
                (void)val;
                std::this_thread::yield();
            }
        });
    }

    // Wait for all threads
    for (auto& t : threads) {
        t.join();
    }

    TEST("Thread safety test completed", true);

    std::printf("\n  Result: %d passed, %d failed\n\n", test_pass, test_fail);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 5: Unit Conversions
// ═══════════════════════════════════════════════════════════════════════════

void test_unit_conversions() {
    std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    std::printf("║  TEST 5: Unit Conversions                                ║\n");
    std::printf("╚═══════════════════════════════════════════════════════════╝\n");

    // Test mm ↔ register units (0.01mm per unit)
    uint16_t units_10mm = modbus_data_sync::mm_to_register_units(10.0);
    TEST("10mm → 1000 units", units_10mm == 1000);

    uint16_t units_12_5mm = modbus_data_sync::mm_to_register_units(12.5);
    TEST("12.5mm → 1250 units", units_12_5mm == 1250);

    double mm_from_1000 = modbus_data_sync::register_units_to_mm(1000);
    TEST("1000 units → 10.0mm", mm_from_1000 == 10.0);

    double mm_from_1250 = modbus_data_sync::register_units_to_mm(1250);
    TEST("1250 units → 12.5mm", mm_from_1250 == 12.5);

    std::printf("\n  Result: %d passed, %d failed\n\n", test_pass, test_fail);
}

// ═══════════════════════════════════════════════════════════════════════════
// Serial Utils Tests
// ═══════════════════════════════════════════════════════════════════════════

void test_serial_utils() {
    std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    std::printf("║  TEST 6: Serial Utilities                                ║\n");
    std::printf("╚═══════════════════════════════════════════════════════════╝\n");

    // Test baud rate conversion
    speed_t b115200 = serial_utils::baud_to_speed_t(115200);
    TEST("115200 baud", b115200 == B115200);

    speed_t b9600 = serial_utils::baud_to_speed_t(9600);
    TEST("9600 baud", b9600 == B9600);

    // Test port scanning (safe on all systems)
    auto ports = serial_utils::scan_usb_serial_ports();
    TEST("Port scan completed", true);  // Just verify it doesn't crash

    if (verbose) {
        std::printf("    Found %zu USB serial ports\n", ports.size());
        for (const auto& port : ports) {
            std::printf("      - %s\n", port.c_str());
        }
    }

    std::printf("\n  Result: %d passed, %d failed\n\n", test_pass, test_fail);
}

// ═══════════════════════════════════════════════════════════════════════════
// Main
// ═══════════════════════════════════════════════════════════════════════════

int main(int argc, char* argv[]) {
    // Check for --verbose flag
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "--verbose") {
            verbose = true;
        }
    }

    std::printf("╔════════════════════════════════════════════════════════════╗\n");
    std::printf("║  Modbus Bridge Integration Test Suite                    ║\n");
    std::printf("╚════════════════════════════════════════════════════════════╝\n");

    test_bridge_initialization();
    test_data_synchronization();
    test_command_extraction();
    test_thread_safety();
    test_unit_conversions();
    test_serial_utils();

    // Summary
    std::printf("╔════════════════════════════════════════════════════════════╗\n");
    std::printf("║  Test Summary                                              ║\n");
    std::printf("╚════════════════════════════════════════════════════════════╝\n");
    std::printf("  Passed: %d\n", test_pass);
    std::printf("  Failed: %d\n", test_fail);
    std::printf("\n");

    return test_fail > 0 ? 1 : 0;
}
