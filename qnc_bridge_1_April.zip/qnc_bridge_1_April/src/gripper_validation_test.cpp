/**
 * gripper_validation_test.cpp
 *
 * Executable for testing gripper hardware communication at runtime.
 * 
 * Usage:
 *   ./gripper_validation_test                          # Test default device (DH56)
 *   ./gripper_validation_test --device DH56 --timeout 3000
 *   ./gripper_validation_test --sequence               # Run multi-command test
 *   ./gripper_validation_test --help
 *
 * Output:
 *   - Detailed per-command logging with timestamps
 *   - Parameter matching results with tolerances
 *   - Exit code 0 if validation passed, non-zero on failure
 *   - JSON report available with --report flag
 */

#include "gripper_runtime_validator.hpp"

#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace qnc::gripper;

static void print_usage(const char* prog_name)
{
    std::cerr << "Usage: " << prog_name << " [OPTIONS]\n"
              << "\nOPTIONS:\n"
              << "  --device DEVICE_ID    Device to validate (default: DH56)\n"
              << "  --timeout MS          Timeout in milliseconds (default: 2000)\n"
              << "  --sequence            Run multi-command validation sequence\n"
              << "  --position POS        Custom position to verify (0.0–1.0)\n"
              << "  --force FORCE         Custom force to verify (0.0–1.0)\n"
              << "  --speed SPEED         Custom speed to verify (0.0–1.0)\n"
              << "  --pos-tol TOL         Position tolerance (default: 0.05)\n"
              << "  --force-tol TOL       Force tolerance (default: 0.1)\n"
              << "  --speed-tol TOL       Speed tolerance (default: 0.1)\n"
              << "  --verbose             Enable detailed logging (default: on)\n"
              << "  --quiet               Suppress detailed logging\n"
              << "  --help                Show this message\n";
}

static void print_result_summary(const ValidationResult& result)
{
    std::cout << "\n" << std::string(50, '=') << "\n";
    std::cout << "VALIDATION SUMMARY\n";
    std::cout << std::string(50, '=') << "\n";
    std::cout << "Device ID:       " << result.device_id << "\n";
    std::cout << "Status:          " << result.status_string() << "\n";
    std::cout << "Message:         " << result.message << "\n";
    std::cout << "Latency:         " << result.latency_ms.count() << " ms\n";
    
    if (result.is_valid()) {
        std::cout << "\n✅ VALIDATION PASSED\n";
    } else {
        std::cout << "\n❌ VALIDATION FAILED\n";
        if (!result.diagnostics.empty()) {
            std::cout << "Diagnostics:     " << result.diagnostics << "\n";
        }
    }
    std::cout << std::string(50, '=') << "\n";
}

static void print_sequence_summary(
    const std::string& device_id,
    const std::vector<ValidationResult>& results)
{
    std::cout << "\n" << std::string(60, '=') << "\n";
    std::cout << "SEQUENCE VALIDATION SUMMARY\n";
    std::cout << std::string(60, '=') << "\n";
    std::cout << "Device ID:       " << device_id << "\n";
    std::cout << "Total Commands:  " << results.size() << "\n";
    
    int passed = 0;
    int failed = 0;
    long total_latency = 0;
    
    for (size_t i = 0; i < results.size(); ++i) {
        const auto& r = results[i];
        std::cout << "\n  [" << (i + 1) << "] "
                 << (r.is_valid() ? "✓ PASS" : "✗ FAIL")
                 << " - " << r.message
                 << " (" << r.latency_ms.count() << "ms)\n";
        
        if (r.is_valid()) {
            ++passed;
        } else {
            ++failed;
        }
        total_latency += r.latency_ms.count();
    }
    
    std::cout << "\n" << std::string(60, '-') << "\n";
    std::cout << "Results:         " << passed << " passed, " << failed << " failed\n";
    std::cout << "Average Latency: " << (total_latency / results.size()) << " ms\n";
    
    if (failed == 0) {
        std::cout << "\n✅ ALL VALIDATIONS PASSED\n";
    } else {
        std::cout << "\n❌ SOME VALIDATIONS FAILED\n";
    }
    std::cout << std::string(60, '=') << "\n";
}

int main(int argc, char* argv[])
{
    std::string device_id = "DH56";
    uint32_t timeout_ms = 2000;
    bool run_sequence = false;
    bool verbose = true;
    float custom_position = -1.0f;
    float custom_force = -1.0f;
    float custom_speed = -1.0f;
    float pos_tol = -1.0f;
    float force_tol = -1.0f;
    float speed_tol = -1.0f;
    
    // Parse command-line arguments
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        
        if (arg == "--help") {
            print_usage(argv[0]);
            return 0;
        } else if (arg == "--device" && i + 1 < argc) {
            device_id = argv[++i];
        } else if (arg == "--timeout" && i + 1 < argc) {
            timeout_ms = std::stoul(argv[++i]);
        } else if (arg == "--position" && i + 1 < argc) {
            custom_position = std::stof(argv[++i]);
        } else if (arg == "--force" && i + 1 < argc) {
            custom_force = std::stof(argv[++i]);
        } else if (arg == "--speed" && i + 1 < argc) {
            custom_speed = std::stof(argv[++i]);
        } else if (arg == "--pos-tol" && i + 1 < argc) {
            pos_tol = std::stof(argv[++i]);
        } else if (arg == "--force-tol" && i + 1 < argc) {
            force_tol = std::stof(argv[++i]);
        } else if (arg == "--speed-tol" && i + 1 < argc) {
            speed_tol = std::stof(argv[++i]);
        } else if (arg == "--sequence") {
            run_sequence = true;
        } else if (arg == "--verbose") {
            verbose = true;
        } else if (arg == "--quiet") {
            verbose = false;
        } else {
            std::cerr << "Unknown argument: " << arg << "\n";
            print_usage(argv[0]);
            return 1;
        }
    }
    
    // Create validator
    std::cout << "Initializing gripper validator for device: " << device_id << "\n";
    GripperRuntimeValidator validator(device_id);
    
    // Configure tolerances if specified
    if (pos_tol > 0.0f) validator.set_position_tolerance(pos_tol);
    if (force_tol > 0.0f) validator.set_force_tolerance(force_tol);
    if (speed_tol > 0.0f) validator.set_speed_tolerance(speed_tol);
    
    // Prepare output stream
    std::stringstream log_stream;
    std::ostream* log_out = verbose ? &std::cerr : nullptr;
    
    ValidationResult result;
    std::vector<ValidationResult> results;
    
    if (run_sequence) {
        // ───────────────────────────────────────────────────────────────────
        // Multi-command validation sequence
        // Tests: range of positions, different force/speed settings
        // ───────────────────────────────────────────────────────────────────
        std::cout << "\nRunning multi-command validation sequence...\n";
        
        std::vector<std::tuple<float, float, float, GripperMode>> commands = {
            // (position, force, speed, mode)
            {0.2f, 0.4f, 0.2f, GripperMode::MODE_POSITION},  // Low position
            {0.5f, 0.5f, 0.3f, GripperMode::MODE_POSITION},  // Mid position
            {0.8f, 0.6f, 0.4f, GripperMode::MODE_POSITION},  // High position
            {0.5f, 0.7f, 0.5f, GripperMode::MODE_FORCE},     // Force mode
        };
        
        results = validator.validate_sequence(commands, timeout_ms, log_out);
        print_sequence_summary(device_id, results);
        
        // Return success if all passed
        for (const auto& r : results) {
            if (!r.is_valid()) return 1;
        }
        return 0;
        
    } else if (custom_position >= 0.0f || custom_force >= 0.0f || custom_speed >= 0.0f) {
        // ───────────────────────────────────────────────────────────────────
        // Custom command validation
        // ───────────────────────────────────────────────────────────────────
        float pos = (custom_position >= 0.0f) ? custom_position : 0.5f;
        float force = (custom_force >= 0.0f) ? custom_force : 0.5f;
        float speed = (custom_speed >= 0.0f) ? custom_speed : 0.3f;
        GripperMode mode = GripperMode::MODE_POSITION;
        
        std::cout << "\nRunning custom command validation...\n";
        std::cout << "  Position: " << pos << "\n";
        std::cout << "  Force:    " << force << "\n";
        std::cout << "  Speed:    " << speed << "\n";
        std::cout << "  Mode:     POSITION\n\n";
        
        result = validator.validate_with_command(pos, force, speed, mode, timeout_ms, log_out);
        print_result_summary(result);
        
        return result.is_valid() ? 0 : 1;
        
    } else {
        // ───────────────────────────────────────────────────────────────────
        // Standard responsiveness validation
        // ───────────────────────────────────────────────────────────────────
        std::cout << "\nRunning standard responsiveness validation...\n";
        std::cout << "  Command: position=0.5, force=0.5, speed=0.3 (POSITION mode)\n";
        std::cout << "  Timeout: " << timeout_ms << " ms\n\n";
        
        result = validator.validate_responsiveness(timeout_ms, log_out);
        print_result_summary(result);
        
        return result.is_valid() ? 0 : 1;
    }
}
