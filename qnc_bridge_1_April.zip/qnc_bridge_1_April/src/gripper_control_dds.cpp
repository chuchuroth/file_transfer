#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include "gripper/GripperCommand.hpp"
#include "gripper/GripperCommandPubSubTypes.hpp"
#include "gripper/GripperState.hpp"
#include "gripper/GripperStatePubSubTypes.hpp"

#include <neura_sync/neura_sync_node.hpp>
#include <neura_sync/participant_factory.hpp>
#include <neura_sync/publisher.hpp>
#include <neura_sync/publisher_factory.hpp>
#include <neura_sync/subscriber.hpp>
#include <neura_sync/subscriber_factory.hpp>

using namespace eprosima::fastdds::dds;

namespace {

std::string iso_now()
{
    using namespace std::chrono;
    auto now = system_clock::now();
    auto tt = system_clock::to_time_t(now);
    auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
    char buf[32];
    struct tm tm_info;
    gmtime_r(&tt, &tm_info);
    strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", &tm_info);
    char out[40];
    snprintf(out, sizeof(out), "%s.%03ldZ", buf, static_cast<long>(ms.count()));
    return out;
}

struct DemoOptions {
    std::string command;
    std::string gripper;
    int cycles = 30;
    int delay_ms = 4000;
    int init_wait_ms = 5000;
    int domain_id = 0;
    float position = 0.5f;
    float force = 0.5f;
    float speed = 0.3f;
    std::string tag_json;
};

struct GripperRoute {
    std::string device_id;
    uint8_t slave = 0;
    uint16_t speed_reg = 0;
    bool is_dh56 = false;
    uint8_t read_fc = 4;      // Modbus FC for status reads (3=holding, 4=input)
    uint16_t read_count = 3;  // Number of registers to read for status
};

GripperRoute resolve_route(const std::string& gripper)
{
    if (gripper == "ag160") {
        return {"ag160", 1, 0x0102, false, 4, 3};
    }
    if (gripper == "cgc80") {
        return {"cgc80", 2, 0x0104, false, 4, 3};
    }
    if (gripper == "dh56") {
        return {"gripper_dh56", 3, 0x0100, true, 3, 1};
    }
    throw std::runtime_error("Unknown --gripper value: " + gripper);
}

bool is_number(const std::string& s)
{
    if (s.empty()) {
        return false;
    }
    for (char c : s) {
        if (c < '0' || c > '9') {
            return false;
        }
    }
    return true;
}

void usage()
{
    std::cout
        << "Usage:\n"
        << "  gripper_control_dds demo_all [cycles] [--cycles N] [--delay-ms N] [--init-wait-ms N] [--domain N]\n"
        << "  gripper_control_dds --gripper <ag160|cgc80|dh56> <init|open|close|status|demo|setpoint> [cycles] [--delay-ms N] [--domain N]\n"
        << "  gripper_control_dds --gripper dh56 setpoint [--position P] [--force F] [--speed S] [--tag-json '{...}']\n"
        << "\n"
        << "Examples:\n"
        << "  gripper_control_dds demo_all --cycles 30 --delay-ms 4000\n"
        << "  gripper_control_dds --gripper ag160 init\n"
        << "  gripper_control_dds --gripper cgc80 demo 30\n";
}

class DdsClient {
public:
    explicit DdsClient(int domain_id)
    {
        auto* part_factory = neura::sync::ParticipantFactory::getInstance();
        participant_ = part_factory->createDefaultParticipant(domain_id);
        if (!participant_) {
            throw std::runtime_error("NeuraSync: failed to create participant");
        }

        node_ = std::make_shared<neura::sync::NeuraSyncNode>(participant_);

        auto pub_factory = neura::sync::PublisherFactory::getInstance(participant_);
        auto sub_factory = neura::sync::SubscriberFactory::getInstance(participant_);

        constexpr int64_t max_blocking_ns = 500000000; // 500 ms

        cmd_pub_ = pub_factory->createCriticalDataPublisher<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", "qnc/gripper/command", max_blocking_ns);
        node_->add_publisher(cmd_pub_);

        node_->add_subscriber(
            sub_factory->createCriticalDataSubscriber<
                qnc::gripper::GripperState, qnc::gripper::GripperStatePubSubType>(
                "gripper_state_sub", "qnc/gripper/state",
                [this](const qnc::gripper::GripperState& msg) {
                    ++states_;
                    if (msg.error_code() == 0 && msg.bridge_error_code() == 0) {
                        ++ok_;
                    } else {
                        ++err_;
                    }
                }));

        std::cout << "[NeuraSync] Bridge active on domain " << domain_id << "\n"
                  << "      topics: qnc/gripper/command | qnc/gripper/state\n";
    }

    ~DdsClient()
    {
        node_.reset();
        participant_ = nullptr;
    }

    void wait_for_bridge_match(int timeout_ms = 10000)
    {
        int elapsed = 0;
        const int step_ms = 100;
        std::cout << "[NeuraSync] Waiting for QNC bridge subscriber match..." << std::flush;

        while (elapsed < timeout_ms) {
            if (cmd_pub_->hasListener()) {
                std::cout << " matched (" << elapsed << " ms)\n";
                return;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(step_ms));
            elapsed += step_ms;
        }
        std::cout << " timeout (" << timeout_ms << " ms) - proceeding anyway\n";
    }

    void send_raw_write(uint8_t slave, uint16_t reg, uint16_t value,
                        const std::string& device_id, const std::string& tag)
    {
        qnc::gripper::GripperCommand cmd;
        cmd.device_id(device_id);
        cmd.command_type(qnc::gripper::GripperCommandType::CMD_RAW_MODBUS);
        cmd.mode(qnc::gripper::GripperMode::MODE_BASIC);
        cmd.slave_id_hint(slave);
        cmd.timeout_ms(500);
        cmd.blocking(false);
        cmd.timeout(0.0f);
        cmd.prefer_multi_write(false);
        cmd.raw_read_start_register(0);
        cmd.raw_read_count(0);
        cmd.raw_read_fc(0);

        qnc::gripper::RegisterWrite rw;
        rw.register_address(reg);
        rw.value(value);
        cmd.raw_writes().push_back(rw);

        cmd.tag(tag);
        cmd.timestamp(iso_now());

        node_->set_publisher_buffer<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", cmd);
        node_->publish("gripper_cmd_pub");
        std::cout << "[PUB] WRITE device=" << device_id
                  << " slave=" << (int)slave
                  << " reg=0x" << std::hex << reg << std::dec
                  << " val=" << value
                  << " tag=" << tag << "\n" << std::flush;
    }

    void send_raw_read(uint8_t slave, uint16_t start_reg, uint16_t count, uint8_t read_fc,
                       const std::string& device_id, const std::string& tag)
    {
        qnc::gripper::GripperCommand cmd;
        cmd.device_id(device_id);
        cmd.command_type(qnc::gripper::GripperCommandType::CMD_RAW_MODBUS);
        cmd.mode(qnc::gripper::GripperMode::MODE_BASIC);
        cmd.slave_id_hint(slave);
        cmd.timeout_ms(800);
        cmd.blocking(false);
        cmd.timeout(0.0f);
        cmd.prefer_multi_write(false);
        cmd.raw_read_start_register(start_reg);
        cmd.raw_read_count(count);
        cmd.raw_read_fc(read_fc);
        cmd.tag(tag);
        cmd.timestamp(iso_now());

        node_->set_publisher_buffer<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", cmd);
        node_->publish("gripper_cmd_pub");
        std::cout << "[PUB] READ  device=" << device_id
                  << " slave=" << (int)slave
                  << " reg=0x" << std::hex << start_reg << std::dec
                  << " count=" << count
                  << " fc=" << (int)read_fc
                  << " tag=" << tag << "\n" << std::flush;
    }

    void send_setpoint(uint8_t slave, const std::string& device_id,
                       float position, float force, float speed,
                       const std::string& tag)
    {
        qnc::gripper::GripperCommand cmd;
        cmd.device_id(device_id);
        cmd.command_type(qnc::gripper::GripperCommandType::CMD_SETPOINT);
        cmd.mode(qnc::gripper::GripperMode::MODE_POSITION);
        cmd.position(position);
        cmd.max_force(force);
        cmd.max_speed(speed);
        cmd.slave_id_hint(slave);
        cmd.timeout_ms(800);
        cmd.blocking(false);
        cmd.timeout(0.0f);
        cmd.prefer_multi_write(false);
        cmd.raw_read_start_register(0);
        cmd.raw_read_count(0);
        cmd.raw_read_fc(0);
        cmd.tag(tag);
        cmd.timestamp(iso_now());

        node_->set_publisher_buffer<
            qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>(
            "gripper_cmd_pub", cmd);
        node_->publish("gripper_cmd_pub");
        std::cout << "[PUB] SETPOINT device=" << device_id
                  << " slave=" << static_cast<int>(slave)
                  << " pos=" << position
                  << " force=" << force
                  << " speed=" << speed
                  << " tag=" << tag << "\n" << std::flush;
    }

    uint64_t state_count() const { return states_.load(); }
    uint64_t state_ok() const { return ok_.load(); }
    uint64_t state_err() const { return err_.load(); }

private:
    DomainParticipant* participant_ = nullptr;
    std::shared_ptr<neura::sync::NeuraSyncNode> node_;
    std::shared_ptr<neura::sync::Publisher<
        qnc::gripper::GripperCommand, qnc::gripper::GripperCommandPubSubType>> cmd_pub_;

    std::atomic<uint64_t> states_{0};
    std::atomic<uint64_t> ok_{0};
    std::atomic<uint64_t> err_{0};
};

void send_ag160_move(DdsClient& dds, uint16_t position, const std::string& tag_suffix)
{
    dds.send_raw_write(1, 0x0101, 50, "ag160", "ag160_force_" + tag_suffix);
    dds.send_raw_write(1, 0x0102, 50, "ag160", "ag160_speed_" + tag_suffix);
    dds.send_raw_write(1, 0x0103, position, "ag160", "ag160_pos_" + tag_suffix);
}

void send_cgc80_move(DdsClient& dds, uint16_t position, const std::string& tag_suffix)
{
    dds.send_raw_write(2, 0x0101, 50, "cgc80", "cgc80_force_" + tag_suffix);
    dds.send_raw_write(2, 0x0104, 50, "cgc80", "cgc80_speed_" + tag_suffix);
    dds.send_raw_write(2, 0x0103, position, "cgc80", "cgc80_pos_" + tag_suffix);
}

void send_dh56_cmd(DdsClient& dds, uint16_t command, const std::string& tag_suffix)
{
    dds.send_raw_write(3, 0x0100, command, "dh56", "dh56_cmd_" + tag_suffix);
}

void send_status_reads(DdsClient& dds)
{
    dds.send_raw_read(1, 0x0200, 3, 4, "ag160", "ag160_status");
    dds.send_raw_read(2, 0x0200, 3, 4, "cgc80", "cgc80_status");
    dds.send_raw_read(3, 0x0200, 1, 3, "dh56", "dh56_status");
}

void run_demo_all(DdsClient& dds, const DemoOptions& opt)
{
    std::cout << "[demo_all] Sending init to all 3 grippers (AG-160 slave=1, CGC-80 slave=2, DH-5-6 slave=3)\n";
    dds.send_raw_write(1, 0x0100, 1, "ag160", "ag160_init");
    dds.send_raw_write(2, 0x0100, 1, "cgc80", "cgc80_init");
    dds.send_raw_write(3, 0x0100, 1, "dh56", "dh56_init");

    std::cout << "[demo_all] Waiting " << opt.init_wait_ms << " ms for calibration..." << std::flush;
    std::this_thread::sleep_for(std::chrono::milliseconds(opt.init_wait_ms));
    std::cout << " ready\n";

    for (int i = 1; i <= opt.cycles; ++i) {
        std::cout << "[demo_all " << i << "/" << opt.cycles << "] CLOSE/HOME ..." << std::flush;
        send_ag160_move(dds, 1000, "close");
        send_cgc80_move(dds, 1000, "close");
        send_dh56_cmd(dds, 9, "home");
        std::this_thread::sleep_for(std::chrono::milliseconds(opt.delay_ms));
        send_status_reads(dds);
        std::cout << " done  OPEN ..." << std::flush;

        send_ag160_move(dds, 0, "open");
        send_cgc80_move(dds, 0, "open");
        send_dh56_cmd(dds, 14, "thumb_open");
        std::this_thread::sleep_for(std::chrono::milliseconds(opt.delay_ms));
        send_status_reads(dds);
        std::cout << " done\n";
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(800));
    std::cout << "[demo_all] Complete - " << opt.cycles << " cycles across all 3 grippers\n";
}

void run_single_gripper(DdsClient& dds, const DemoOptions& opt)
{
    GripperRoute route = resolve_route(opt.gripper);

    auto send_open = [&]() {
        if (route.is_dh56) {
            dds.send_raw_write(route.slave, 0x0100, 14, route.device_id, "open");
        } else {
            dds.send_raw_write(route.slave, 0x0101, 50, route.device_id, "force");
            dds.send_raw_write(route.slave, route.speed_reg, 50, route.device_id, "speed");
            dds.send_raw_write(route.slave, 0x0103, 0, route.device_id, "open_position");
        }
    };

    auto send_close = [&]() {
        if (route.is_dh56) {
            dds.send_raw_write(route.slave, 0x0100, 9, route.device_id, "close");
        } else {
            dds.send_raw_write(route.slave, 0x0101, 50, route.device_id, "force");
            dds.send_raw_write(route.slave, route.speed_reg, 50, route.device_id, "speed");
            dds.send_raw_write(route.slave, 0x0103, 1000, route.device_id, "close_position");
        }
    };

    auto send_status = [&]() {
        dds.send_raw_read(route.slave, 0x0200, route.read_count, route.read_fc, route.device_id, "status");
    };

    if (opt.command == "init") {
        dds.send_raw_write(route.slave, 0x0100, 1, route.device_id, "init");
        return;
    }
    if (opt.command == "open") {
        send_open();
        return;
    }
    if (opt.command == "close") {
        send_close();
        return;
    }
    if (opt.command == "status") {
        send_status();
        return;
    }
    if (opt.command == "setpoint") {
        const std::string tag = opt.tag_json.empty() ? "setpoint" : opt.tag_json;
        dds.send_setpoint(route.slave, route.device_id, opt.position, opt.force, opt.speed, tag);
        return;
    }
    if (opt.command == "demo") {
        dds.send_raw_write(route.slave, 0x0100, 1, route.device_id, "init");
        std::this_thread::sleep_for(std::chrono::milliseconds(opt.init_wait_ms));
        for (int i = 1; i <= opt.cycles; ++i) {
            std::cout << "[demo " << opt.gripper << " " << i << "/" << opt.cycles << "] OPEN ..." << std::flush;
            send_open();
            std::this_thread::sleep_for(std::chrono::milliseconds(opt.delay_ms));
            send_status();
            std::cout << " done  CLOSE ..." << std::flush;
            send_close();
            std::this_thread::sleep_for(std::chrono::milliseconds(opt.delay_ms));
            send_status();
            std::cout << " done\n";
        }
        return;
    }

    throw std::runtime_error("Unknown command for --gripper mode: " + opt.command);
}

DemoOptions parse_args(int argc, char* argv[])
{
    DemoOptions opt;
    if (argc < 2) {
        usage();
        throw std::runtime_error("missing command");
    }

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--gripper") {
            if (i + 1 >= argc) throw std::runtime_error("--gripper requires value");
            opt.gripper = argv[++i];
            continue;
        }
        if (a == "--cycles") {
            if (i + 1 >= argc) throw std::runtime_error("--cycles requires value");
            opt.cycles = std::atoi(argv[++i]);
            continue;
        }
        if (a == "--delay-ms") {
            if (i + 1 >= argc) throw std::runtime_error("--delay-ms requires value");
            opt.delay_ms = std::atoi(argv[++i]);
            continue;
        }
        if (a == "--init-wait-ms") {
            if (i + 1 >= argc) throw std::runtime_error("--init-wait-ms requires value");
            opt.init_wait_ms = std::atoi(argv[++i]);
            continue;
        }
        if (a == "--domain") {
            if (i + 1 >= argc) throw std::runtime_error("--domain requires value");
            opt.domain_id = std::atoi(argv[++i]);
            continue;
        }
        if (a == "--position") {
            if (i + 1 >= argc) throw std::runtime_error("--position requires value");
            opt.position = std::stof(argv[++i]);
            continue;
        }
        if (a == "--force") {
            if (i + 1 >= argc) throw std::runtime_error("--force requires value");
            opt.force = std::stof(argv[++i]);
            continue;
        }
        if (a == "--speed") {
            if (i + 1 >= argc) throw std::runtime_error("--speed requires value");
            opt.speed = std::stof(argv[++i]);
            continue;
        }
        if (a == "--tag-json") {
            if (i + 1 >= argc) throw std::runtime_error("--tag-json requires value");
            opt.tag_json = argv[++i];
            continue;
        }

        if (opt.command.empty()) {
            opt.command = a;
            continue;
        }

        if (is_number(a) && (opt.command == "demo" || opt.command == "demo_all")) {
            opt.cycles = std::atoi(a.c_str());
            continue;
        }

        throw std::runtime_error("Unknown argument: " + a);
    }

    if (opt.command.empty()) {
        throw std::runtime_error("missing command");
    }
    if (opt.cycles <= 0) {
        throw std::runtime_error("cycles must be > 0");
    }
    if (opt.delay_ms < 0 || opt.init_wait_ms < 0) {
        throw std::runtime_error("delay values must be >= 0");
    }
    return opt;
}

} // namespace

int main(int argc, char* argv[])
{
    try {
        DemoOptions opt = parse_args(argc, argv);
        DdsClient dds(opt.domain_id);
        dds.wait_for_bridge_match(10000);

        if (opt.command == "demo_all") {
            run_demo_all(dds, opt);
        } else if (opt.command == "identify") {
            // Read signature register (addr 0, FC03) and status registers (0x0200)
            // from all 3 ports to identify which gripper is on which port.
            std::cout << "[identify] Reading signature reg 0x0000 (FC03) from all 3 ports...\n";
            dds.send_raw_read(1, 0x0000, 1, 3, "ag160", "port1_sig_fc03");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            dds.send_raw_read(2, 0x0000, 1, 3, "cgc80", "port2_sig_fc03");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            dds.send_raw_read(3, 0x0000, 1, 3, "dh56", "port3_sig_fc03");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            std::cout << "[identify] Reading status reg 0x0200 (FC04) from all 3 ports...\n";
            dds.send_raw_read(1, 0x0200, 3, 4, "ag160", "port1_status_fc04");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            dds.send_raw_read(2, 0x0200, 3, 4, "cgc80", "port2_status_fc04");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            dds.send_raw_read(3, 0x0200, 3, 4, "dh56", "port3_status_fc04");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            std::cout << "[identify] Reading status reg 0x0200 (FC03) from all 3 ports...\n";
            dds.send_raw_read(1, 0x0200, 3, 3, "ag160", "port1_status_fc03");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            dds.send_raw_read(2, 0x0200, 3, 3, "cgc80", "port2_status_fc03");
            std::this_thread::sleep_for(std::chrono::milliseconds(300));
            dds.send_raw_read(3, 0x0200, 3, 3, "dh56", "port3_status_fc03");
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            std::cout << "[identify] Done. Check bridge trace log for register values.\n"
                      << "  DH56 signature: reg 0x0000 = 43690 (0xAAAA)\n"
                      << "  AG160/CGC80: reg 0x0000 = implementation-specific\n"
                      << "  DH56: FC04 fails, FC03 succeeds\n"
                      << "  AG160: FC04 succeeds (per descriptor)\n"
                      << "  CGC80: FC04 succeeds\n";
        } else {
            run_single_gripper(dds, opt);
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(400));
        std::cout << "[NeuraSync] Summary: states=" << dds.state_count()
                  << " ok=" << dds.state_ok()
                  << " err=" << dds.state_err() << "\n";
        std::cout.flush();
        std::_Exit(0);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        usage();
        return 1;
    }
}
