/**
 * modbus_qnc_node.cpp — QNC Modbus RTU Bridge Node
 *
 * Integrates Modbus RTU slave communication into the robot platform.
 * Acts as a bridge between:
 *   - External board (Modbus RTU master) → robot platform (Modbus RTU slave)
 *   - Modbus registers ↔ DDS gripper state/commands
 *
 * Threading model:
 *   - Main thread: DDS subscribers & command processing
 *   - Modbus I/O thread (owned by bridge): serial reading/writing
 *   - Thread-safe: register access protected by mutexes
 *
 * Configuration:
 *   - Serial port: /dev/ttyUSB0 (configurable)
 *   - Baud rate: 115200 (configurable)
 *   - Slave address: 1 (from the current bridge/device configuration)
 *   - Register count: 256 (to accommodate future expansion)
 */

#include "modbus_bridge.hpp"
#include "modbus_data_sync.hpp"
#include "serial_utils.hpp"
#include "modbus_rtu_slave.hpp"

#include <chrono>
#include <cstdio>
#include <functional>
#include <iostream>
#include <memory>
#include <thread>
#include <vector>

// ═══════════════════════════════════════════════════════════════════════════
// QNC Modbus Node Configuration
// ═══════════════════════════════════════════════════════════════════════════

struct QncModbusConfig {
    // Serial communication
    std::string serial_port = "/dev/ttyUSB0";
    int baud_rate = 115200;
    uint8_t slave_address = 1;  // From ICD

    // Register layout
    uint16_t num_registers = 256;

    // Logging
    bool verbose = false;
    bool print_stats_interval_seconds = 60;

    // Callbacks (user provides these)
    std::function<void(const modbus_data_sync::GripperCommand&)> on_command;
    std::function<modbus_data_sync::GripperState()> get_state;
};

// ═══════════════════════════════════════════════════════════════════════════
// QNC Modbus Node Implementation
// ═══════════════════════════════════════════════════════════════════════════

class QncModbusNode {
public:
    explicit QncModbusNode(const QncModbusConfig& config)
        : config_(config),
          bridge_config_{
              .slave_address = config.slave_address,
              .port = config.serial_port,
              .baud_rate = config.baud_rate,
              .num_registers = config.num_registers,
              .verbose = config.verbose,
          },
          bridge_(bridge_config_),
          synchronizer_(),
          running_(false)
    {
    }

    ~QncModbusNode() {
        shutdown();
    }

    /**
     * Initialize and start the node.
     *
     * @return true if successful
     */
    bool startup() {
        std::printf("╔════════════════════════════════════════╗\n");
        std::printf("║  QNC Modbus RTU Bridge Node            ║\n");
        std::printf("║  Starting up...                        ║\n");
        std::printf("╚════════════════════════════════════════╝\n\n");

        // Open serial port
        if (!bridge_.open_serial()) {
            std::fprintf(stderr, "ERROR: Failed to open serial port\n");
            return false;
        }

        // Register Modbus write callback for command extraction
        bridge_.on_register_write([this](uint16_t start, uint16_t count) {
            on_modbus_registers_written(start, count);
        });

        // Register serial error callback
        bridge_.on_serial_error([this](const std::string& err) {
            std::fprintf(stderr, "Serial error: %s\n", err.c_str());
        });

        // Start listening for Modbus frames
        if (!bridge_.start_listen()) {
            std::fprintf(stderr, "ERROR: Failed to start Modbus listener\n");
            bridge_.close_serial();
            return false;
        }

        running_ = true;

        // Start stats reporter thread if configured
        if (config_.print_stats_interval_seconds > 0) {
            stats_thread_ = std::thread([this] { stats_loop(); });
        }

        std::printf("✓ Node started successfully\n");
        std::printf("  Port: %s @ %d baud\n", config_.serial_port.c_str(), config_.baud_rate);
        std::printf("  Slave Address: 0x%02X\n", config_.slave_address);
        std::printf("  Register Bank: %u registers\n\n", config_.num_registers);

        return true;
    }

    /**
     * Gracefully shutdown the node.
     */
    void shutdown() {
        if (!running_) return;

        running_ = false;

        bridge_.stop_listen();
        bridge_.close_serial();

        if (stats_thread_.joinable()) {
            stats_thread_.join();
        }

        std::printf("\n✓ Node shutdown complete\n");
    }

    /**
     * Update gripper state from DDS (call this when state changes).
     *
     * Synchronizer extracts register updates and writes them to Modbus bridge.
     *
     * @param state Current gripper state
     */
    void update_state(const modbus_data_sync::GripperState& state) {
        auto updates = synchronizer_.update_from_dds(state);

        // Write all register updates to bridge
        for (const auto& [addr, value] : updates) {
            bridge_.set_register(addr, value);
        }
    }

    /**
     * Get synchronizer for direct access.
     */
    modbus_data_sync::Synchronizer& get_synchronizer() {
        return synchronizer_;
    }

    /**
     * Get bridge for diagnostics / direct register access.
     */
    modbus_bridge::Bridge& get_bridge() {
        return bridge_;
    }

    /**
     * Print diagnostics to stdout.
     */
    void print_diagnostics() const {
        bridge_.print_stats();
    }

    /**
     * Get current statistics.
     */
    modbus_bridge::Stats get_stats() const {
        return bridge_.get_stats();
    }

private:
    // ─────────────────────────────────────────────────────────────────────
    // Callbacks
    // ─────────────────────────────────────────────────────────────────────

    void on_modbus_registers_written(uint16_t start, uint16_t count) {
        // Extract commands from Modbus write
        synchronizer_.on_modbus_write(
            start, count,
            [this](uint16_t addr) { return bridge_.get_register(addr); });

        // If a new valid command was extracted, invoke user callback
        if (synchronizer_.has_valid_command() && config_.on_command) {
            auto cmd = synchronizer_.get_last_command();
            config_.on_command(cmd);
            synchronizer_.clear_command();
        }
    }

    void stats_loop() {
        auto interval = std::chrono::seconds(config_.print_stats_interval_seconds);
        while (running_) {
            std::this_thread::sleep_for(interval);
            if (running_) {
                bridge_.print_stats();
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Members
    // ─────────────────────────────────────────────────────────────────────

    QncModbusConfig config_;
    modbus_bridge::Config bridge_config_;
    modbus_bridge::Bridge bridge_;
    modbus_data_sync::Synchronizer synchronizer_;
    std::atomic<bool> running_;
    std::thread stats_thread_;
};

// ═══════════════════════════════════════════════════════════════════════════
// Example Usage (main for testing without full DDS)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Stand-alone test: verify Modbus communication works end-to-end.
 *
 * Compile:
 *   g++ -std=c++17 -Iinclude -o test_qnc_modbus src/modbus_qnc_node.cpp -pthread
 *
 * Run:
 *   ./test_qnc_modbus
 */
int main_test_qnc_modbus() {
    // Create config
    QncModbusConfig config;
    config.serial_port = "/dev/ttyUSB0";
    config.baud_rate = 115200;
    config.slave_address = 1;
    config.verbose = true;
    config.print_stats_interval_seconds = 10;

    // Set up callbacks
    config.on_command = [](const modbus_data_sync::GripperCommand& cmd) {
        std::printf("\n★ New command from Modbus:\n  ");
        modbus_data_sync::print_command(cmd);
    };

    // Create and start node
    QncModbusNode node(config);
    if (!node.startup()) {
        return 1;
    }

    // Simulate state updates from DDS
    std::printf("\nSimulating DDS state updates (every 2 seconds)...\n");
    std::printf("  (In real code, these come from gripper DDS subscribers)\n\n");

    int cycle = 0;
    while (running_test) {
        std::this_thread::sleep_for(std::chrono::seconds(2));

        // Simulate gripper moving
        modbus_data_sync::GripperState state;
        state.ready = true;
        state.moving = (cycle % 2 == 0);
        state.error = false;
        state.actual_position_units = (cycle * 100) % 4000;  // Simulated position
        state.target_position_units = 2000;

        node.update_state(state);

        std::printf("  [Cycle %d] Updated state (pos=%u)\n", cycle, state.actual_position_units);

        cycle++;
        if (cycle > 20) break;  // Run for ~40 seconds
    }

    // Shutdown
    node.shutdown();

    // Print final stats
    node.print_diagnostics();

    return 0;
}

// ═══════════════════════════════════════════════════════════════════════════
// Integration into gripper_control_dds.cpp
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Example integration pattern (for gripper_control_dds.cpp):

    #include "modbus_qnc_node.cpp"

    int main() {
        // ... DDS initialization ...

        // Create QNC Modbus node
        QncModbusConfig modbus_config;
        modbus_config.serial_port = config_json["modbus"]["port"];  // from config
        modbus_config.baud_rate = config_json["modbus"]["baud"];
        modbus_config.verbose = config_json["modbus"]["verbose"];

        // Command callback: route Modbus commands to gripper controller
        modbus_config.on_command = [&](const modbus_data_sync::GripperCommand& cmd) {
            // Translate to internal gripper command
            GripperCommand internal_cmd;
            internal_cmd.grip = cmd.grip;
            internal_cmd.release = cmd.release;
            internal_cmd.force_pct = cmd.force_percent;
            // ... more translation ...

            // Queue for execution
            gripper_command_queue.push(internal_cmd);
        };

        QncModbusNode modbus_node(modbus_config);
        if (!modbus_node.startup()) {
            std::cerr << "Failed to start Modbus node\n";
            return 1;
        }

        // Main loop
        while (running) {
            // 1. Read DDS gripper state
            auto gripper_state = subscribe_gripper_state();

            // 2. Convert to Modbus and update registers
            modbus_data_sync::GripperState modbus_state;
            modbus_state.ready = gripper_state.is_ready();
            modbus_state.moving = gripper_state.is_moving();
            modbus_state.error = gripper_state.has_error();
            modbus_state.error_code = gripper_state.error_code();
            modbus_state.actual_position_units =
                modbus_data_sync::mm_to_register_units(gripper_state.position_mm());

            modbus_node.update_state(modbus_state);

            // 3. Process any Modbus commands (callbacks handle this automatically)
            // ... continue main loop ...
        }

        modbus_node.shutdown();
        return 0;
    }
 */

// Keep running_test global for the test
std::atomic<bool> running_test = true;
