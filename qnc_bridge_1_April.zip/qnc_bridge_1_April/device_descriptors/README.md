⚠️ **THESE DESCRIPTORS DO NOT BELONG IN QNC**

This folder contains **example device descriptors** to show how the **external robot platform** should describe ModbusRTU devices.

## Why This Matters: QNC's Value Proposition

**Without QNC:** You'd write 500+ lines of C++ driver code for each device IN YOUR ROBOT.  
**With QNC:** Copy 200 lines of JSON from device manual. Done in 30 minutes.

See [../../README.md](../../README.md#design-philosophy-why-qnc-exists) for detailed comparison of development effort.

## Important Architecture Principle

1. **QNC is device-agnostic** - it only handles raw register operations
2. **These files are reference examples** for your robot control system
3. **Move these to your robot platform codebase**
4. **Device-specific logic (parsing, commands) belongs outside QNC**

**QNC = Protocol bridge. Your robot = Application logic.**

## Architecture

```
Robot Platform (External)           QNC (This Package)
├── device_descriptors/             ├── modbus_bridge
│   ├── DH_AG95.json               │   (generic bridge)
│   ├── robotiq_2f.json            │
│   └── my_motor.json              └── Receives generic
├── device_parsers/                    ReadCommand/WriteCommand
│   ├── gripper_parser.py              via DDS
│   └── motor_parser.py
└── high_level_control/            ↓ Executes raw register ops
    └── gripper_controller.py      ↓ Returns raw Response
```

## Usage Example (Robot Platform Side)

```python
# This code runs on your robot platform, NOT on QNC

import json
from dds_publisher import Publisher

# Load device descriptor
with open('DH_AG95_descriptor.json') as f:
    descriptor = json.load(f)

# High-level command
def close_gripper(position_mm, force_percent):
    """Translate application command to Modbus registers"""
    
    # Get register addresses from descriptor
    pos_reg = descriptor['registers']['position_target']
    force_reg = descriptor['registers']['force_target']
    
    # Calculate register values using descriptor formulas
    pos_value = int(position_mm / descriptor['scaling']['position'])
    force_value = int(force_percent * 10)
    
    # Send generic Modbus commands to QNC via DDS
    qnc_publisher.publish(WriteCommand(
        slave_id=1,
        register=pos_reg,
        value=pos_value
    ))
    
    qnc_publisher.publish(WriteCommand(
        slave_id=1,
        register=force_reg,
        value=force_value
    ))

# Read and parse response
def get_gripper_status():
    """Read raw data from QNC and interpret using descriptor"""
    
    response = qnc_subscriber.wait_for_message()
    
    # Parse raw register values
    status_reg = response.data[0]
    position_raw = response.data[1]
    
    # Interpret using descriptor
    status_bits = descriptor['status_word']
    is_initialized = bool(status_reg & status_bits['initialized'])
    is_moving = bool(status_reg & status_bits['moving'])
    
    actual_position_mm = position_raw * descriptor['scaling']['position']
    
    return {
        'initialized': is_initialized,
        'moving': is_moving,
        'position': actual_position_mm
    }
```

## Descriptor Format

```json
{
  "vendor": "DH-Robotics",
  "model": "AG-95",
  "modbus": {
    "default_slave_id": 1,
    "baudrate": 115200
  },
  "registers": {
    "control_word": 1000,
    "position_target": 1001,
    "force_target": 1002,
    "status_word": 1003,
    "position_actual": 1004
  },
  "scaling": {
    "position": 0.01,
    "force": 0.1
  },
  "status_word": {
    "initialized": 1,
    "moving": 2,
    "error": 4,
    "position_reached": 8
  },
  "commands": {
    "initialize": 1,
    "activate": 3,
    "emergency_stop": 0
  }
}
```

## Files in This Folder

- `DH_AG95_descriptor.json` - DH-Robotics AG-95 gripper
- `DH-Robotics_CGC-80_RTU.json` - DH-Robotics CGC-80 gripper
- `dh_robotics_gripper.json` - Generic DH-Robotics format
- `robotiq_2f_modbus.json` - Robotiq 2F-85 gripper

**Again: These are EXAMPLES. Move them to your robot platform!**

## Summary

- ✓ QNC handles protocol (RS485, Modbus framing, CRC)
- ✓ Robot platform handles semantics (what register 1000 means)
- ✗ Don't put device knowledge in QNC
- ✗ Don't put protocol handling in robot platform

**Separation of concerns makes both systems better.**
