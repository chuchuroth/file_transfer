// Generic, config-driven gripper adapter pseudocode.
// Intentionally compact and device-agnostic.

#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>

#include "gripper/GripperCommand.hpp"
#include "gripper/GripperState.hpp"

struct RegisterRef {
    uint16_t address;
    uint8_t fc; // 3,4,6,16
};

struct ScaleRule {
    double raw_min;
    double raw_max;
    bool invert;
};

struct GenericGripperConfig {
    std::string device_id;
    uint16_t slave_id;
    bool supports_force_control;
    bool supports_speed_control;
    bool has_multi_joint;

    RegisterRef pos_write;
    RegisterRef pos_read;
    RegisterRef status_motion;
    RegisterRef status_grasp;

    std::vector<RegisterRef> force_write;
    std::vector<RegisterRef> speed_write;
    std::vector<RegisterRef> dof_pos_write;

    ScaleRule pos_scale;
    ScaleRule force_scale;
    ScaleRule speed_scale;
};

class GenericGripperAdapter {
public:
    struct WriteAction {
        uint16_t reg;
        uint16_t value;
        uint32_t timeout_ms;
    };

    explicit GenericGripperAdapter(GenericGripperConfig cfg) : cfg_(std::move(cfg)) {}

    // Bridge-side callback: map a generic DDS command into raw register writes.
    std::vector<WriteAction> on_command(
        const qnc::gripper::GripperCommand& cmd)
    {
        std::vector<WriteAction> out;
        if (std::string(cmd.device_id().c_str()) != cfg_.device_id) {
            return out;
        }

        // Clamp normalized inputs from generic IDL.
        const double pos = clamp01(cmd.position());
        const double frc = clamp01(cmd.max_force());
        const double spd = clamp01(cmd.max_speed());

        // Position: single-axis or multi-DOF aggregate.
        if (!cfg_.has_multi_joint) {
            out.push_back(make_write(cfg_.pos_write, to_raw(pos, cfg_.pos_scale)));
        } else {
            // Multi-joint default behavior: broadcast aggregate position to all DOFs.
            for (const auto& reg : cfg_.dof_pos_write) {
                out.push_back(make_write(reg, to_raw(pos, cfg_.pos_scale)));
            }
        }

        if (cfg_.supports_force_control) {
            const uint16_t raw_force = to_raw(frc, cfg_.force_scale);
            for (const auto& reg : cfg_.force_write) {
                out.push_back(make_write(reg, raw_force));
            }
        }

        if (cfg_.supports_speed_control) {
            const uint16_t raw_speed = to_raw(spd, cfg_.speed_scale);
            for (const auto& reg : cfg_.speed_write) {
                out.push_back(make_write(reg, raw_speed));
            }
        }

        return out;
    }

    // Bridge-side callback: reconstruct generic state from the last transport readback.
    qnc::gripper::GripperState build_state(
        uint16_t start_reg,
        const std::vector<uint16_t>& values,
        int error_code,
        int bridge_error_code,
        uint32_t last_command_latency_us,
        const std::string& last_tag)
    {
        qnc::gripper::GripperState st;
        st.device_id(cfg_.device_id);
        st.last_command_tag(last_tag);
        st.error_code(error_code);
        st.bridge_error_code(bridge_error_code);

        if (error_code < 0 || bridge_error_code < 0) {
            st.status(qnc::gripper::GripperStatus::STATUS_ERROR);
            st.grasp_result(qnc::gripper::GraspResult::GRASP_FAILED_ERROR);
            st.message("QNC bridge/modbus error");
            return st;
        }

        // Expect single-register polling reads in this compact design.
        const uint16_t raw = values.empty() ? 0 : values[0];

        // If polled register equals position feedback register.
        if (start_reg == cfg_.pos_read.address) {
            st.position(static_cast<float>(to_norm(raw, cfg_.pos_scale)));
        }

        if (start_reg == cfg_.status_motion.address) {
            st.status(raw == 0
                ? qnc::gripper::GripperStatus::STATUS_MOVING
                : qnc::gripper::GripperStatus::STATUS_IDLE);
        }

        if (start_reg == cfg_.status_grasp.address) {
            st.grasp_result(raw == 2
                ? qnc::gripper::GraspResult::GRASP_SUCCESS
                : qnc::gripper::GraspResult::GRASP_IN_PROGRESS);
        }

        st.last_command_latency_us(last_command_latency_us);
        st.message("ok");
        return st;
    }

private:
    static double clamp01(double v)
    {
        return std::max(0.0, std::min(1.0, v));
    }

    static uint16_t to_raw(double norm, const ScaleRule& s)
    {
        const double n = s.invert ? (1.0 - norm) : norm;
        const double raw = s.raw_min + n * (s.raw_max - s.raw_min);
        return static_cast<uint16_t>(raw < 0.0 ? 0.0 : raw);
    }

    static double to_norm(uint16_t raw, const ScaleRule& s)
    {
        const double denom = (s.raw_max - s.raw_min);
        if (denom == 0.0) {
            return 0.0;
        }
        const double n = (static_cast<double>(raw) - s.raw_min) / denom;
        const double out = s.invert ? (1.0 - n) : n;
        return clamp01(out);
    }

    WriteAction make_write(const RegisterRef& reg, uint16_t value)
    {
        return WriteAction{reg.address, value, 500};
    }

    GenericGripperConfig cfg_;
};
