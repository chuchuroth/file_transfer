#pragma once
/**
 * zimmer_gep2013il.hpp — Zimmer GEP2013IL-03-B gripper bridge
 *
 * Defines the Modbus holding-register map that mirrors the gripper's
 * IO-Link process data (PDI / PDO) plus constants extracted from the
 * official IODD (Zimmer-GEP2013IL-03-B-20210323-IODD1.1.xml).
 *
 * Architecture
 * ────────────
 *   ┌────────────┐  RS-485 / Modbus RTU  ┌────────────┐  IO-Link  ┌──────────┐
 *   │ This PC    │◄════════════════════►│  Master    │◄════════►│ Gripper  │
 *   │ (slave)    │  FC03 reads cmd regs  │ (QNC)      │   PDO→   │ GEP2013IL│
 *   │            │  FC06/10 writes sts   │            │   ←PDI   │          │
 *   └────────────┘                       └────────────┘          └──────────┘
 *
 * Data flow
 * ---------
 *   • We write command registers (10–20) → master FC03-reads them → master
 *     packs them into IO-Link PDO → gripper executes.
 *   • Master receives IO-Link PDI from gripper → master FC06/FC10-writes
 *     status registers (0–2) into our slave → we read them locally.
 *
 * Register map (see reg:: namespace below for symbolic addresses).
 */

#include <cstdint>
#include <cstdio>

namespace zimmer_gep2013il {

// ═══════════════════════════════════════════════════════════════════════════
// Modbus holding-register addresses
// ═══════════════════════════════════════════════════════════════════════════
namespace reg {

// ── Status registers (PDI — gripper feedback, master writes these) ────────
constexpr uint16_t STATUSWORD      = 0x0000;  // 16-bit
constexpr uint16_t DIAGNOSE        = 0x0001;  // 16-bit  (enum, see Diag::)
constexpr uint16_t ACTUAL_POSITION = 0x0002;  // 16-bit  (0.01 mm units)

// ── Command registers (PDO — we write these, master reads them) ───────────
constexpr uint16_t CONTROLWORD         = 0x000A;  // 16-bit
constexpr uint16_t GRIP_MODE           = 0x000B;  // 8-bit (low byte)
constexpr uint16_t WORKPIECE_NO        = 0x000C;  // 8-bit
constexpr uint16_t RESERVED            = 0x000D;  // 8-bit
constexpr uint16_t POSITION_TOLERANCE  = 0x000E;  // 8-bit  (%)
constexpr uint16_t GRIP_FORCE          = 0x000F;  // 8-bit  (%)
constexpr uint16_t DRIVE_VELOCITY      = 0x0010;  // 8-bit  (%)
constexpr uint16_t BASE_POSITION       = 0x0011;  // 16-bit (0.01 mm)
constexpr uint16_t SHIFT_POSITION      = 0x0012;  // 16-bit (0.01 mm)
constexpr uint16_t TEACH_POSITION      = 0x0013;  // 16-bit (0.01 mm)
constexpr uint16_t WORK_POSITION       = 0x0014;  // 16-bit (0.01 mm)

// Minimum register count the slave needs.
constexpr uint16_t MIN_REGS = WORK_POSITION + 1;  // 21

}  // namespace reg

// ═══════════════════════════════════════════════════════════════════════════
// GripMode enum (IO-Link DeviceMode, 8-bit).
// Values from IODD <Datatype id="V_DeviceMode">.
// ═══════════════════════════════════════════════════════════════════════════
namespace GripMode {
constexpr uint8_t UNDEFINED              = 0;
constexpr uint8_t JOG                    = 11;
constexpr uint8_t POSITIONING            = 50;
constexpr uint8_t NORMALLY_OPEN          = 60;
constexpr uint8_t NORMALLY_OPEN_REPRESS  = 63;
constexpr uint8_t NORMALLY_CLOSE         = 70;
constexpr uint8_t NORMALLY_CLOSE_REPRESS = 73;
constexpr uint8_t UNIVERSAL              = 100;
constexpr uint8_t UNIVERSAL_REPRESS      = 103;
}  // namespace GripMode

// ═══════════════════════════════════════════════════════════════════════════
// IO-Link SystemCommand values (index 2).
// These are written to the IO-Link SystemCommand variable, NOT to the
// Modbus command registers.  They are listed here for documentation.
// ═══════════════════════════════════════════════════════════════════════════
namespace SysCmd {
constexpr uint8_t ACTIVATE       = 160;   // Enable gripper
constexpr uint8_t GRIPPER_CLOSE  = 161;   // Close gripper
constexpr uint8_t GRIPPER_OPEN   = 162;   // Open gripper
constexpr uint8_t BM_UNLOCK_S    = 80;
constexpr uint8_t BM_UNLOCK_F    = 81;
constexpr uint8_t BM_UNLOCK_T    = 82;
constexpr uint8_t FACTORY_RESET  = 130;
}  // namespace SysCmd

// ═══════════════════════════════════════════════════════════════════════════
// Diagnose codes (V_Diagnosis enum, 16-bit).
// ═══════════════════════════════════════════════════════════════════════════
namespace Diag {
constexpr uint16_t NO_ERROR             = 0;
constexpr uint16_t MOTOR_OFF            = 1;
constexpr uint16_t IN_HOMING_MODE       = 2;
constexpr uint16_t START_UP             = 3;
constexpr uint16_t POWER_SUPPLY_ERROR   = 256;
constexpr uint16_t OVER_TEMPERATURE     = 257;
constexpr uint16_t UNDER_TEMPERATURE    = 258;
constexpr uint16_t INVERTER_TEMP        = 259;
constexpr uint16_t LOGIC_VOLTAGE_LOW    = 262;
constexpr uint16_t LOGIC_VOLTAGE_HIGH   = 263;
constexpr uint16_t ACTOR_VOLTAGE_LOW    = 264;
constexpr uint16_t ACTOR_VOLTAGE_HIGH   = 265;
constexpr uint16_t ACTOR_VOLTAGE_DROP   = 266;
constexpr uint16_t PART_LOST            = 267;
constexpr uint16_t OVER_CURRENT         = 280;
constexpr uint16_t MOVEMENT_BLOCKED     = 281;
}  // namespace Diag

// ═══════════════════════════════════════════════════════════════════════════
// Process data structs (mirror the IO-Link PDI / PDO byte layout)
// ═══════════════════════════════════════════════════════════════════════════

/// PDI — Process Data Input (gripper → master), 6 bytes / 48 bits.
struct PDI {
    uint16_t statusword;       // Bits defined by Zimmer hardware manual.
    uint16_t diagnose;         // Diag:: enum values.
    uint16_t actual_position;  // 0.01 mm units.
};

/// PDO — Process Data Output (master → gripper), 16 bytes / 128 bits.
struct PDO {
    uint16_t controlword;
    uint8_t  grip_mode;          // GripMode:: values.
    uint8_t  workpiece_no;
    uint8_t  reserved;
    uint8_t  position_tolerance; // % of full stroke.
    uint8_t  grip_force;         // %.
    uint8_t  drive_velocity;     // %.
    uint16_t base_position;      // 0.01 mm.
    uint16_t shift_position;     // 0.01 mm.
    uint16_t teach_position;     // 0.01 mm.
    uint16_t work_position;      // 0.01 mm.
};

// ═══════════════════════════════════════════════════════════════════════════
// Register ↔ struct helpers
// ═══════════════════════════════════════════════════════════════════════════

/// Read PDI (gripper status) from holding registers 0–2.
template <typename RegGetter>
inline PDI read_pdi(RegGetter get_reg)
{
    return {
        get_reg(reg::STATUSWORD),
        get_reg(reg::DIAGNOSE),
        get_reg(reg::ACTUAL_POSITION),
    };
}

/// Write PDO (gripper command) into holding registers 10–20.
template <typename RegSetter>
inline void write_pdo(RegSetter set_reg, const PDO& pdo)
{
    set_reg(reg::CONTROLWORD,        pdo.controlword);
    set_reg(reg::GRIP_MODE,          pdo.grip_mode);
    set_reg(reg::WORKPIECE_NO,       pdo.workpiece_no);
    set_reg(reg::RESERVED,           pdo.reserved);
    set_reg(reg::POSITION_TOLERANCE, pdo.position_tolerance);
    set_reg(reg::GRIP_FORCE,         pdo.grip_force);
    set_reg(reg::DRIVE_VELOCITY,     pdo.drive_velocity);
    set_reg(reg::BASE_POSITION,      pdo.base_position);
    set_reg(reg::SHIFT_POSITION,     pdo.shift_position);
    set_reg(reg::TEACH_POSITION,     pdo.teach_position);
    set_reg(reg::WORK_POSITION,      pdo.work_position);
}

/// Read PDO back from holding registers 10–20 (for inspection).
template <typename RegGetter>
inline PDO read_pdo(RegGetter get_reg)
{
    PDO pdo{};
    pdo.controlword        = get_reg(reg::CONTROLWORD);
    pdo.grip_mode          = static_cast<uint8_t>(get_reg(reg::GRIP_MODE));
    pdo.workpiece_no       = static_cast<uint8_t>(get_reg(reg::WORKPIECE_NO));
    pdo.reserved           = static_cast<uint8_t>(get_reg(reg::RESERVED));
    pdo.position_tolerance = static_cast<uint8_t>(get_reg(reg::POSITION_TOLERANCE));
    pdo.grip_force         = static_cast<uint8_t>(get_reg(reg::GRIP_FORCE));
    pdo.drive_velocity     = static_cast<uint8_t>(get_reg(reg::DRIVE_VELOCITY));
    pdo.base_position      = get_reg(reg::BASE_POSITION);
    pdo.shift_position     = get_reg(reg::SHIFT_POSITION);
    pdo.teach_position     = get_reg(reg::TEACH_POSITION);
    pdo.work_position      = get_reg(reg::WORK_POSITION);
    return pdo;
}

/// Log PDI to stderr.
inline void log_pdi(const PDI& pdi)
{
    std::fprintf(stderr, "  PDI: status=0x%04X  diag=%u  pos=%u (0.01mm)\n",
                 pdi.statusword, pdi.diagnose, pdi.actual_position);
}

/// Log PDO to stderr.
inline void log_pdo(const PDO& pdo)
{
    std::fprintf(stderr, "  PDO: ctrl=0x%04X  mode=%u  wp=%u  tol=%u%%  "
                 "force=%u%%  vel=%u%%  base=%u  shift=%u  teach=%u  work=%u\n",
                 pdo.controlword, pdo.grip_mode, pdo.workpiece_no,
                 pdo.position_tolerance, pdo.grip_force, pdo.drive_velocity,
                 pdo.base_position, pdo.shift_position,
                 pdo.teach_position, pdo.work_position);
}

}  // namespace zimmer_gep2013il
