#pragma once
/**
 * modbus_bridge.hpp — Modbus RTU Bridge component for QNC integration
 *
 * Wraps the Modbus RTU slave implementation and provides a modular interface for:
 *   - Serial port lifecycle (open, config, close)
 *   - Frame processing and exception handling
 *   - Register state synchronization with DDS
 *   - Safe threading with register callbacks
 *   - Logging and diagnostics
 *
 * Usage:
 *   1. Create a ModbusBridge instance with slave address and register count
 *   2. Set write callbacks to hook into your command handlers
 *   3. Call open_serial() to connect to the serial port
 *   4. Call start_listen() to begin processing Modbus requests
 *   5. Update status registers via set_reg() from other threads
 *   6. Monitor register writes via callbacks to detect incoming commands
 *   7. Call stop_listen() and close_serial() to shutdown
 */

#include "modbus_rtu_slave.hpp"
#include "modbus_rtu_common.hpp"  // for serial utilities

#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <termios.h>
#include <thread>
#include <unistd.h>
#include <vector>

namespace modbus_bridge {

/**
 * Statistics & diagnostics gathered during operation.
 */
struct Stats {
    uint64_t frames_received = 0;
    uint64_t frames_sent = 0;
    uint64_t crc_errors = 0;
    uint64_t address_mismatches = 0;
    uint64_t invalid_frames = 0;
    uint64_t registers_read = 0;
    uint64_t registers_written = 0;
    uint64_t exception_responses = 0;

    std::chrono::steady_clock::time_point started_at = std::chrono::steady_clock::now();

    /// Reset all counters.
    void reset() {
        frames_received = frames_sent = crc_errors = address_mismatches = 0;
        invalid_frames = registers_read = registers_written = exception_responses = 0;
        started_at = std::chrono::steady_clock::now();
    }

    /// Return elapsed time since start.
    std::chrono::seconds elapsed() const {
        return std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::steady_clock::now() - started_at);
    }
};

/**
 * Configuration for the Modbus bridge.
 */
struct Config {
    /// Modbus slave address (1–247)
    uint8_t slave_address = 1;

    /// Serial port path (e.g., "/dev/ttyUSB0")
    std::string port;

    /// Baud rate (115200 typical for industrial)
    int baud_rate = 115200;

    /// Number of holding registers to allocate
    uint16_t num_registers = 128;

    /// Enable debug logging to stderr
    bool verbose = false;

    /// Timeout for reading from serial (milliseconds)
    int read_timeout_ms = 2;

    /// Optional: frame received callback (for diagnostics)
    std::function<void(const std::vector<uint8_t>&)> on_frame_received;

    /// Optional: frame sent callback (for diagnostics)
    std::function<void(const std::vector<uint8_t>&)> on_frame_sent;
};

/**
 * Modbus RTU Bridge — main integration component.
 *
 * Thread-safe register access + serial transport management.
 */
class Bridge {
public:
    using RegisterChangeCallback = std::function<void(uint16_t start, uint16_t count)>;
    using SerialErrorCallback = std::function<void(const std::string& error)>;

    /// Constructor: creates slave and initializes state.
    explicit Bridge(const Config& config)
        : config_(config),
          slave_(config.slave_address, config.num_registers),
          running_(false),
          serial_fd_(-1)
    {
    }

    /// Destructor: ensures cleanup.
    ~Bridge() {
        stop_listen();
        close_serial();
    }

    // ─────────────────────────────────────────────────────────────────────
    // State Management
    // ─────────────────────────────────────────────────────────────────────

    /// Set callback invoked when master writes to registers.
    void on_register_write(RegisterChangeCallback cb) {
        register_write_callback_ = std::move(cb);
        slave_.set_write_callback([this](uint16_t start, uint16_t count) {
            update_register_write_stats(start, count);
            if (register_write_callback_)
                register_write_callback_(start, count);
        });
    }

    /// Set callback for serial errors.
    void on_serial_error(SerialErrorCallback cb) {
        serial_error_callback_ = std::move(cb);
    }

    // ─────────────────────────────────────────────────────────────────────
    // Register Access (thread-safe with mutex)
    // ─────────────────────────────────────────────────────────────────────

    /// Get current value of a register (safe for concurrent access).
    uint16_t get_register(uint16_t idx) {
        std::lock_guard<std::mutex> lock(register_mutex_);
        return slave_.reg(idx);
    }

    /// Set register value (safe for concurrent access).
    void set_register(uint16_t idx, uint16_t value) {
        std::lock_guard<std::mutex> lock(register_mutex_);
        slave_.set_reg(idx, value);
    }

    /// Bulk read: get multiple consecutive registers.
    std::vector<uint16_t> get_registers(uint16_t start, uint16_t count) {
        std::lock_guard<std::mutex> lock(register_mutex_);
        std::vector<uint16_t> result;
        result.reserve(count);
        for (uint16_t i = 0; i < count; ++i) {
            result.push_back(slave_.reg(start + i));
        }
        return result;
    }

    /// Bulk write: set multiple consecutive registers.
    void set_registers(uint16_t start, const std::vector<uint16_t>& values) {
        std::lock_guard<std::mutex> lock(register_mutex_);
        for (size_t i = 0; i < values.size(); ++i) {
            slave_.set_reg(start + i, values[i]);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Serial Port Lifecycle
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Open and configure the serial port.
     *
     * @return true if successful, false otherwise (check stdout/stderr for error)
     */
    bool open_serial() {
        if (serial_fd_ >= 0) {
            log_error("Serial port already open");
            return false;
        }

        // Open serial port
        serial_fd_ = ::open(config_.port.c_str(), O_RDWR | O_NOCTTY);
        if (serial_fd_ < 0) {
            std::string err = "Failed to open " + config_.port + ": " + std::strerror(errno);
            log_error(err);
            if (serial_error_callback_) serial_error_callback_(err);
            return false;
        }

        // Configure terminal attributes
        termios tio = {};
        if (tcgetattr(serial_fd_, &tio) < 0) {
            std::string err = "tcgetattr failed: " + std::string(std::strerror(errno));
            log_error(err);
            if (serial_error_callback_) serial_error_callback_(err);
            close_serial();
            return false;
        }

        // Standard 8N1 configuration
        cfsetispeed(&tio, get_baud_constant(config_.baud_rate));
        cfsetospeed(&tio, get_baud_constant(config_.baud_rate));
        tio.c_cflag = (tio.c_cflag & ~CSIZE) | CS8;  // 8 bits
        tio.c_cflag &= ~PARENB;                       // no parity
        tio.c_cflag &= ~CSTOPB;                       // 1 stop bit
        tio.c_cflag |= CREAD;                         // enable receiver
        tio.c_cflag |= CLOCAL;                        // ignore modem lines
        tio.c_lflag &= ~ICANON;                       // raw mode
        tio.c_lflag &= ~ECHO;                         // no echo
        tio.c_lflag &= ~ISIG;                         // no signals
        tio.c_iflag &= ~(IXON | IXOFF | IXANY);      // no software flow control
        tio.c_oflag &= ~OPOST;                        // no output mapping
        tio.c_cc[VMIN] = 0;                           // non-blocking
        tio.c_cc[VTIME] = 0;                          // no timeout at read()

        if (tcsetattr(serial_fd_, TCSANOW, &tio) < 0) {
            std::string err = "tcsetattr failed: " + std::string(std::strerror(errno));
            log_error(err);
            if (serial_error_callback_) serial_error_callback_(err);
            close_serial();
            return false;
        }

        log_info("Opened serial port: " + config_.port + " at " + std::to_string(config_.baud_rate) + " baud");
        return true;
    }

    /**
     * Close the serial port.
     */
    void close_serial() {
        if (serial_fd_ >= 0) {
            ::close(serial_fd_);
            serial_fd_ = -1;
            log_info("Closed serial port");
        }
    }

    /**
     * Start the Modbus slave listener thread.
     *
     * Spawns a background thread that continuously:
     *   - Reads frames from the serial port
     *   - Processes them with the Modbus slave
     *   - Sends responses
     *   - Collects statistics
     *
     * @return true if thread started, false if already running or error
     */
    bool start_listen() {
        if (serial_fd_ < 0) {
            log_error("Serial port not open; call open_serial() first");
            return false;
        }

        if (running_.exchange(true)) {
            log_error("Listener already running");
            return false;
        }

        listen_thread_ = std::thread([this] { listen_loop(); });
        log_info("Modbus listener thread started (slave_addr=" + std::to_string(config_.slave_address) + ")");
        return true;
    }

    /**
     * Stop the Modbus slave listener thread.
     *
     * Signals the background thread to stop and waits for it to finish.
     */
    void stop_listen() {
        if (!running_.exchange(false)) {
            return;  // not running
        }

        if (listen_thread_.joinable()) {
            listen_thread_.join();
            log_info("Modbus listener thread stopped");
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Diagnostics & Statistics
    // ─────────────────────────────────────────────────────────────────────

    /// Get current statistics snapshot.
    Stats get_stats() const {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        return stats_;
    }

    /// Reset all statistics.
    void reset_stats() {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.reset();
    }

    /// Print a human-readable statistics report to stdout.
    void print_stats() const {
        Stats s = get_stats();
        auto uptime = s.elapsed();

        std::printf("\n╔═══════════════════════════════════════════════════════════╗\n");
        std::printf("║  Modbus Bridge Statistics                                 ║\n");
        std::printf("╚═══════════════════════════════════════════════════════════╝\n");
        std::printf("  Slave Address:        0x%02X\n", config_.slave_address);
        std::printf("  Serial Port:          %s @ %d baud\n", config_.port.c_str(), config_.baud_rate);
        std::printf("  Uptime:               %ld seconds\n", uptime.count());
        std::printf("\n  Frames:\n");
        std::printf("    Received:           %lu\n", s.frames_received);
        std::printf("    Sent:               %lu\n", s.frames_sent);
        std::printf("    CRC errors:         %lu\n", s.crc_errors);
        std::printf("    Address mismatches: %lu\n", s.address_mismatches);
        std::printf("    Invalid:            %lu\n", s.invalid_frames);
        std::printf("\n  Registers:\n");
        std::printf("    Read:               %lu\n", s.registers_read);
        std::printf("    Written:            %lu\n", s.registers_written);
        std::printf("    Exception responses:%lu\n", s.exception_responses);
        std::printf("\n");
    }

    /// Enable/disable verbose logging.
    void set_verbose(bool enable) { config_.verbose = enable; }

private:
    // ─────────────────────────────────────────────────────────────────────
    // Internal Implementation
    // ─────────────────────────────────────────────────────────────────────

    /// Main loop for the listener thread.
    void listen_loop() {
        std::vector<uint8_t> buffer;
        buffer.reserve(256);
        std::chrono::steady_clock::time_point last_activity;
        const auto frame_gap = std::chrono::milliseconds(config_.read_timeout_ms);

        while (running_) {
            fd_set readfds;
            FD_ZERO(&readfds);
            FD_SET(serial_fd_, &readfds);

            struct timeval tv {
                .tv_sec = 0,
                .tv_usec = config_.read_timeout_ms * 1000
            };

            int select_ret = select(serial_fd_ + 1, &readfds, nullptr, nullptr, &tv);

            if (select_ret < 0) {
                std::string err = "select() failed: " + std::string(std::strerror(errno));
                log_error(err);
                if (serial_error_callback_) serial_error_callback_(err);
                break;
            }

            if (select_ret == 0) {
                // Timeout — check if we accumulated a frame
                if (!buffer.empty()) {
                    auto now = std::chrono::steady_clock::now();
                    if (std::chrono::duration_cast<std::chrono::milliseconds>(now - last_activity)
                        > frame_gap) {
                        // Frame complete
                        process_frame(buffer);
                        buffer.clear();
                    }
                }
                continue;
            }

            // Data available
            uint8_t tmp[256];
            ssize_t n = ::read(serial_fd_, tmp, sizeof(tmp));
            if (n < 0) {
                std::string err = "read() failed: " + std::string(std::strerror(errno));
                log_error(err);
                if (serial_error_callback_) serial_error_callback_(err);
                break;
            }
            if (n == 0) {
                continue;
            }

            buffer.insert(buffer.end(), tmp, tmp + n);
            last_activity = std::chrono::steady_clock::now();
        }
    }

    /// Process a complete Modbus RTU frame.
    void process_frame(const std::vector<uint8_t>& frame) {
        {
            std::lock_guard<std::mutex> lock(stats_mutex_);
            stats_.frames_received++;
        }

        if (config_.verbose) {
            std::fprintf(stderr, "[Modbus] RX (%zu bytes): ", frame.size());
            for (auto b : frame) std::fprintf(stderr, "%02X ", b);
            std::fprintf(stderr, "\n");
        }

        if (config_.on_frame_received) {
            config_.on_frame_received(frame);
        }

        // Process request with slave
        std::vector<uint8_t> response;
        {
            std::lock_guard<std::mutex> lock(register_mutex_);
            response = slave_.process_request(frame);
        }

        // If we got a response (not address mismatch), send it
        if (!response.empty()) {
            if (config_.verbose) {
                std::fprintf(stderr, "[Modbus] TX (%zu bytes): ", response.size());
                for (auto b : response) std::fprintf(stderr, "%02X ", b);
                std::fprintf(stderr, "\n");
            }

            if (config_.on_frame_sent) {
                config_.on_frame_sent(response);
            }

            ssize_t n = ::write(serial_fd_, response.data(), response.size());
            if (n < 0) {
                std::string err = "write() failed: " + std::string(std::strerror(errno));
                log_error(err);
                if (serial_error_callback_) serial_error_callback_(err);
                return;
            }

            {
                std::lock_guard<std::mutex> lock(stats_mutex_);
                stats_.frames_sent++;
                if (response[1] & 0x80) {
                    stats_.exception_responses++;
                }
            }
        } else {
            // No response = address mismatch or CRC error
            {
                std::lock_guard<std::mutex> lock(stats_mutex_);
                // We can't easily distinguish, so record generically
                stats_.invalid_frames++;
            }
        }
    }

    /// Update register-related statistics after a write.
    void update_register_write_stats(uint16_t start, uint16_t count) {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.registers_written += count;
    }

    /// Convert integer baud rate to termios constant.
    static speed_t get_baud_constant(int baud) {
        switch (baud) {
            case 9600:   return B9600;
            case 19200:  return B19200;
            case 38400:  return B38400;
            case 57600:  return B57600;
            case 115200: return B115200;
            default:
                std::cerr << "Warning: unsupported baud rate " << baud << ", using 115200\n";
                return B115200;
        }
    }

    /// Log informational message.
    void log_info(const std::string& msg) const {
        if (config_.verbose) {
            std::cerr << "[Modbus] INFO: " << msg << "\n";
        }
    }

    /// Log error message.
    void log_error(const std::string& msg) const {
        std::cerr << "[Modbus] ERROR: " << msg << "\n";
    }

    // ─────────────────────────────────────────────────────────────────────
    // Member Variables
    // ─────────────────────────────────────────────────────────────────────

    Config config_;
    modbus_rtu_slave::Slave slave_;
    int serial_fd_;
    std::atomic<bool> running_;
    std::thread listen_thread_;

    std::mutex register_mutex_;      // Protects slave_.regs_
    mutable std::mutex stats_mutex_; // Protects stats_ (readable from const methods)

    Stats stats_;
    RegisterChangeCallback register_write_callback_;
    SerialErrorCallback serial_error_callback_;
};

}  // namespace modbus_bridge
