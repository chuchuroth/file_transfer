/**
 * gripper_runtime_validator.hpp
 *
 * Runtime validation routine for gripper hardware communication.
 * Publishes test commands and validates state feedback with timeout handling.
 *
 * Features:
 *   - DDS pub/sub for GripperCommand and GripperState
 *   - Timeout-aware state feedback validation
 *   - Detailed logging of all command/state interactions
 *   - Extensible design for single or multiple grippers
 *   - Tolerance-based parameter matching (position, force, speed)
 *
 * Usage:
 *   GripperRuntimeValidator validator("DH56");
 *   auto result = validator.validate_responsiveness(timeout_ms, log_stream);
 *   if (result.is_valid()) { ... }
 */

#pragma once

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <iostream>
#include <memory>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <thread>
#include <tuple>
#include <vector>

#include <fastdds/dds/domain/DomainParticipant.hpp>

#include "gripper/GripperCommand.hpp"
#include "gripper/GripperCommandPubSubTypes.hpp"
#include "gripper/GripperState.hpp"
#include "gripper/GripperStatePubSubTypes.hpp"

#include <neura_sync/neura_sync_node.hpp>
#include <neura_sync/participant_factory.hpp>
#include <neura_sync/publisher.hpp>
#include <neura_sync/publisher_factory.hpp>
#include <neura_sync/subscriber.hpp>
#include <neura_sync/subscriber_factory.hpp>

namespace qnc {
namespace gripper {

/**
 * Validation result status.
 */
enum class ValidationStatus {
    SUCCESS = 0,                ///< Command issued, state received, validation passed
    TIMEOUT = 1,                ///< No state feedback received within timeout
    STATE_MISMATCH = 2,         ///< State received but parameters don't match
    COMMUNICATION_ERROR = 3,    ///< DDS initialization or pub/sub error
    INVALID_DEVICE_ID = 4,      ///< Device not found or invalid
    UNKNOWN_ERROR = 5
};

/**
 * Gripper validation result with diagnostic details.
 */
struct ValidationResult {
    ValidationStatus status;
    std::string device_id;
    std::string message;         ///< Human-readable summary
    std::string diagnostics;     ///< Detailed diagnostic info
    
    // Command sent (for correlation)
    float commanded_position;
    float commanded_force;
    float commanded_speed;
    qnc::gripper::GripperMode commanded_mode;
    
    // State received (if available)
    std::optional<float> received_position;
    std::optional<float> received_force;
    std::optional<float> received_speed;
    std::optional<qnc::gripper::GripperStatus> received_status;
    
    // Timing
    std::chrono::milliseconds latency_ms;
    
    bool is_valid() const {
        return status == ValidationStatus::SUCCESS;
    }
    
    std::string status_string() const {
        switch (status) {
            case ValidationStatus::SUCCESS:
                return "SUCCESS";
            case ValidationStatus::TIMEOUT:
                return "TIMEOUT";
            case ValidationStatus::STATE_MISMATCH:
                return "STATE_MISMATCH";
            case ValidationStatus::COMMUNICATION_ERROR:
                return "COMMUNICATION_ERROR";
            case ValidationStatus::INVALID_DEVICE_ID:
                return "INVALID_DEVICE_ID";
            default:
                return "UNKNOWN_ERROR";
        }
    }
};

/**
 * Runtime validator for gripper devices.
 * 
 * Single-threaded usage recommended. Each instance maintains its own
 * DDS publisher/subscriber pair for a specific device.
 */
class GripperRuntimeValidator {
public:
    /**
     * Construct validator for a specific gripper device.
     * 
     * @param device_id QNC device identifier (e.g., "DH56", "CGC-80")
     * @param domain_id DDS domain (default: 0)
     */
    explicit GripperRuntimeValidator(
        const std::string& device_id,
        uint32_t domain_id = 0);
    
    ~GripperRuntimeValidator();
    
    // Non-copyable
    GripperRuntimeValidator(const GripperRuntimeValidator&) = delete;
    GripperRuntimeValidator& operator=(const GripperRuntimeValidator&) = delete;
    
    /**
     * Validate gripper responsiveness by sending a test command
     * and waiting for state feedback.
     * 
     * Sends a simple position command (0.5 normalized) with default
     * force and speed. Waits for matching state feedback.
     * 
     * @param timeout_ms Wait time for state feedback (default: 2000ms)
     * @param log_stream Output stream for detailed logging (optional)
     * @return Validation result with diagnostics
     */
    ValidationResult validate_responsiveness(
        uint32_t timeout_ms = 2000,
        std::ostream* log_stream = nullptr);
    
    /**
     * Validate gripper with custom command parameters.
     * 
     * @param position_cmd Target position (0.0–1.0)
     * @param force_cmd Target force (0.0–1.0)
     * @param speed_cmd Target speed (0.0–1.0)
     * @param mode Control mode
     * @param timeout_ms Wait time for state feedback
     * @param log_stream Output stream for detailed logging (optional)
     * @return Validation result with diagnostics
     */
    ValidationResult validate_with_command(
        float position_cmd,
        float force_cmd,
        float speed_cmd,
        GripperMode mode,
        uint32_t timeout_ms = 2000,
        std::ostream* log_stream = nullptr);
    
    /**
     * Validate multiple sequential commands.
     * Useful for testing motion range or control modes.
     * 
     * @param commands Vector of (position, force, speed, mode) tuples
     * @param timeout_ms Per-command timeout
     * @param log_stream Output stream for logging
     * @return Vector of results (one per command)
     */
    std::vector<ValidationResult> validate_sequence(
        const std::vector<std::tuple<float, float, float, GripperMode>>& commands,
        uint32_t timeout_ms = 2000,
        std::ostream* log_stream = nullptr);
    
    /**
     * Set position tolerance for validation matching.
     * Default: 0.05 (5% of normalized range).
     */
    void set_position_tolerance(float tolerance) {
        position_tolerance_ = tolerance;
    }
    
    /**
     * Set force tolerance for validation matching.
     * Default: 0.1 (10% of normalized range).
     */
    void set_force_tolerance(float tolerance) {
        force_tolerance_ = tolerance;
    }
    
    /**
     * Set speed tolerance for validation matching.
     * Default: 0.1 (10% of normalized range).
     */
    void set_speed_tolerance(float tolerance) {
        speed_tolerance_ = tolerance;
    }
    
    /**
     * Get the device ID this validator was constructed for.
     */
    const std::string& device_id() const {
        return device_id_;
    }
    
private:
    std::string device_id_;
    uint32_t domain_id_;
    eprosima::fastdds::dds::DomainParticipant* participant_{nullptr};
    std::shared_ptr<neura::sync::NeuraSyncNode> node_;
    std::shared_ptr<neura::sync::Publisher<
        qnc::gripper::GripperCommand,
        qnc::gripper::GripperCommandPubSubType>> cmd_publisher_;
    std::shared_ptr<neura::sync::Subscriber<
        qnc::gripper::GripperState,
        qnc::gripper::GripperStatePubSubType>> state_subscriber_;
    
    // Tolerances for validation (normalized 0.0–1.0)
    float position_tolerance_{0.05f};
    float force_tolerance_{0.1f};
    float speed_tolerance_{0.1f};
    
    // Synchronization for state reception
    mutable std::mutex state_mutex_;
    mutable std::condition_variable state_cv_;
    mutable std::optional<qnc::gripper::GripperState> last_state_;
    mutable std::atomic<bool> state_received_{false};
    // Tag of the in-flight command; only states matching this tag are accepted.
    // Protected by state_mutex_.
    std::string pending_tag_;
    
    // Initialization
    bool initialize_dds_();
    
    // Internal validation logic
    ValidationResult validate_internal_(
        const GripperCommand& cmd,
        uint32_t timeout_ms,
        std::ostream* log_stream);
    
    // State callback (from subscriber)
    void on_state_received_(const qnc::gripper::GripperState& state);
    
    // Validation helpers
    bool position_matches_(float cmd, float state) const;
    bool force_matches_(float cmd, float state) const;
    bool speed_matches_(float cmd, float state) const;
    
    // Logging utilities
    static std::string format_timestamp_();
    static std::string format_mode_(GripperMode mode);
    static std::string format_status_(GripperStatus status);
};

/**
 * Convenience function to run a single validation test
 * for a specific gripper device.
 * 
 * @param device_id Device identifier (e.g., "DH56")
 * @param timeout_ms Timeout in milliseconds
 * @param verbose Enable detailed logging
 * @return Validation result
 */
inline ValidationResult validate_gripper_device(
    const std::string& device_id,
    uint32_t timeout_ms = 2000,
    bool verbose = true)
{
    GripperRuntimeValidator validator(device_id);
    std::stringstream ss;
    auto result = validator.validate_responsiveness(
        timeout_ms,
        verbose ? &ss : nullptr);
    
    if (verbose && !ss.str().empty()) {
        std::cerr << ss.str();
    }
    
    return result;
}

} // namespace gripper
} // namespace qnc
