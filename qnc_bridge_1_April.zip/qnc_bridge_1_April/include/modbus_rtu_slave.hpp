#pragma once
/**
 * modbus_rtu_slave.hpp — Minimal Modbus RTU slave (server) implementation
 *
 * Supports:
 *   - FC 0x03  Read Holding Registers  (single or multiple)
 *   - FC 0x06  Write Single Register
 *   - FC 0x10  Write Multiple Registers
 *   - Exception responses for unsupported function codes / invalid addresses
 *
 * Frame structure (RTU):
 *   [ SlaveAddr (1B) | FunctionCode (1B) | Data (N B) | CRC16-Lo | CRC16-Hi ]
 *
 * The CRC16 uses polynomial 0xA001 (same as modbus_rtu_common.hpp).
 *
 * Serial I/O is abstracted via two callbacks so the code works on any
 * transport (real UART, socketpair, pipe, loopback, etc.).
 */

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <functional>
#include <iostream>
#include <string>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#include <vector>

namespace modbus_rtu_slave {

// ── CRC16 (Modbus, polynomial 0xA001) ─────────────────────────────────────
inline uint16_t crc16(const uint8_t* data, size_t len)
{
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int j = 0; j < 8; ++j)
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}

// ── Modbus exception codes ────────────────────────────────────────────────
enum ExceptionCode : uint8_t {
    ILLEGAL_FUNCTION     = 0x01,
    ILLEGAL_DATA_ADDRESS = 0x02,
    ILLEGAL_DATA_VALUE   = 0x03,
};

// ── Slave ─────────────────────────────────────────────────────────────────
/**
 * Minimal in-memory Modbus RTU slave.
 *
 * Usage:
 *   1. Construct with slave address and register count.
 *   2. Call process_request() each time a complete RTU frame is received.
 *      It returns the response frame (including CRC) ready for transmission,
 *      or an empty vector if the frame is not addressed to this slave.
 */
class Slave {
public:
    /// I/O callbacks: read raw bytes into buf, return count; write buf of len.
    using ReadFn  = std::function<ssize_t(uint8_t* buf, size_t max_len)>;
    using WriteFn = std::function<ssize_t(const uint8_t* buf, size_t len)>;

    /// Called after one or more registers have been written (FC06 / FC10).
    /// Parameters: start register address, number of registers written.
    using WriteCallbackFn = std::function<void(uint16_t start, uint16_t count)>;

    /**
     * @param addr       Modbus slave address (1–247)
     * @param num_regs   Number of 16-bit holding registers (default 128)
     */
    explicit Slave(uint8_t addr, uint16_t num_regs = 128)
        : addr_(addr), regs_(num_regs, 0) {}

    // Direct register access (for host code to pre-fill or inspect values).
    uint8_t   addr() const                     { return addr_; }
    uint16_t  reg(uint16_t idx) const          { return regs_.at(idx); }
    void      set_reg(uint16_t idx, uint16_t v){ regs_.at(idx) = v;    }
    uint16_t  num_regs() const                 { return static_cast<uint16_t>(regs_.size()); }

    /// Set a callback invoked whenever registers are written by the master.
    void set_write_callback(WriteCallbackFn cb) { on_write_ = std::move(cb); }

    /**
     * Process a raw, complete RTU request frame (including 2-byte CRC).
     *
     * @return  Response frame (with CRC) to send back, or empty if the
     *          request is not addressed to this slave (address mismatch).
     */
    std::vector<uint8_t> process_request(const uint8_t* frame, size_t len)
    {
        // Minimum RTU frame: addr(1) + fc(1) + crc(2) = 4 bytes
        if (len < 4) return {};

        // ── CRC check ─────────────────────────────────────────────────
        uint16_t rx_crc = frame[len - 2] | (frame[len - 1] << 8);
        if (rx_crc != crc16(frame, len - 2)) return {};   // bad CRC → ignore

        // ── Address filter ────────────────────────────────────────────
        if (frame[0] != addr_) return {};   // not for us

        uint8_t fc = frame[1];

        switch (fc) {
            case 0x03: return handle_read_holding_registers(frame, len);
            case 0x06: return handle_write_single_register(frame, len);
            case 0x10: return handle_write_multiple_registers(frame, len);
            default:   return make_exception(fc, ILLEGAL_FUNCTION);
        }
    }

    /// Convenience: accept a std::vector.
    std::vector<uint8_t> process_request(const std::vector<uint8_t>& frame)
    {
        return process_request(frame.data(), frame.size());
    }

    /**
     * Blocking run-loop: continuously reads frames from the serial port
     * using the provided callbacks, processes them, and writes responses.
     *
     * @param read_fn   Blocking read: fills buf, returns byte count (<=0 = error/timeout)
     * @param write_fn  Write: sends buf, returns byte count
     * @param running   Set to false to stop the loop
     *
     * Frame detection uses a simple inter-character timeout (3.5 char times
     * at 115200 ≈ ~300µs; we use 2ms for safety).
     */
    void run(ReadFn read_fn, WriteFn write_fn, const volatile bool& running)
    {
        std::vector<uint8_t> buf;
        buf.reserve(256);

        while (running) {
            uint8_t tmp[256];
            ssize_t n = read_fn(tmp, sizeof(tmp));
            if (n <= 0) {
                // Timeout / no data — if we accumulated bytes, treat as
                // end-of-frame (RTU inter-frame gap detected).
                if (!buf.empty()) {
                    auto resp = process_request(buf);
                    if (!resp.empty())
                        write_fn(resp.data(), resp.size());
                    buf.clear();
                }
                continue;
            }
            buf.insert(buf.end(), tmp, tmp + n);
        }
    }

private:
    uint8_t               addr_;
    std::vector<uint16_t> regs_;
    WriteCallbackFn       on_write_;

    // ── FC 0x03: Read Holding Registers ───────────────────────────────────
    //
    // Request:  [addr | 0x03 | startHi | startLo | countHi | countLo | crcLo | crcHi]
    //            (8 bytes total)
    //
    // Response: [addr | 0x03 | byteCount | reg0Hi | reg0Lo | ... | crcLo | crcHi]
    //
    std::vector<uint8_t> handle_read_holding_registers(const uint8_t* f, size_t len)
    {
        if (len < 8) return make_exception(0x03, ILLEGAL_DATA_VALUE);

        uint16_t start = (f[2] << 8) | f[3];
        uint16_t count = (f[4] << 8) | f[5];

        if (count == 0 || count > 125)
            return make_exception(0x03, ILLEGAL_DATA_VALUE);
        if (start + count > regs_.size())
            return make_exception(0x03, ILLEGAL_DATA_ADDRESS);

        // Build response PDU
        std::vector<uint8_t> resp;
        resp.reserve(3 + count * 2 + 2);
        resp.push_back(addr_);
        resp.push_back(0x03);
        resp.push_back(static_cast<uint8_t>(count * 2));  // byte count
        for (uint16_t i = 0; i < count; ++i) {
            uint16_t val = regs_[start + i];
            resp.push_back(val >> 8);     // high byte first (big-endian)
            resp.push_back(val & 0xFF);
        }
        return append_crc(resp);
    }

    // ── FC 0x06: Write Single Register ────────────────────────────────────
    //
    // Request:  [addr | 0x06 | regHi | regLo | valHi | valLo | crcLo | crcHi]
    //            (8 bytes total)
    //
    // Response: echo of the request (same 8 bytes, re-calculated CRC).
    //
    std::vector<uint8_t> handle_write_single_register(const uint8_t* f, size_t len)
    {
        if (len < 8) return make_exception(0x06, ILLEGAL_DATA_VALUE);

        uint16_t reg_addr = (f[2] << 8) | f[3];
        uint16_t value    = (f[4] << 8) | f[5];

        if (reg_addr >= regs_.size())
            return make_exception(0x06, ILLEGAL_DATA_ADDRESS);

        regs_[reg_addr] = value;
        if (on_write_) on_write_(reg_addr, 1);

        // Response = echo of request (addr + fc + reg + val + CRC)
        std::vector<uint8_t> resp = { addr_, 0x06,
                                      f[2], f[3],   // register address
                                      f[4], f[5] }; // written value
        return append_crc(resp);
    }

    // ── FC 0x10: Write Multiple Registers ─────────────────────────────────
    //
    // Request:  [addr | 0x10 | startHi | startLo | countHi | countLo |
    //            byteCount | val0Hi | val0Lo | ... | crcLo | crcHi]
    //
    // Response: [addr | 0x10 | startHi | startLo | countHi | countLo |
    //            crcLo | crcHi]
    //
    std::vector<uint8_t> handle_write_multiple_registers(const uint8_t* f, size_t len)
    {
        if (len < 9) return make_exception(0x10, ILLEGAL_DATA_VALUE);

        uint16_t start     = (f[2] << 8) | f[3];
        uint16_t count     = (f[4] << 8) | f[5];
        uint8_t  byte_cnt  = f[6];

        if (count == 0 || count > 123)
            return make_exception(0x10, ILLEGAL_DATA_VALUE);
        if (byte_cnt != count * 2)
            return make_exception(0x10, ILLEGAL_DATA_VALUE);
        if (len < 7u + byte_cnt + 2u)       // PDU + data + CRC
            return make_exception(0x10, ILLEGAL_DATA_VALUE);
        if (start + count > regs_.size())
            return make_exception(0x10, ILLEGAL_DATA_ADDRESS);

        for (uint16_t i = 0; i < count; ++i)
            regs_[start + i] = (f[7 + i * 2] << 8) | f[8 + i * 2];

        if (on_write_) on_write_(start, count);

        std::vector<uint8_t> resp = { addr_, 0x10,
                                      f[2], f[3],   // start address
                                      f[4], f[5] }; // register count
        return append_crc(resp);
    }

    // ── Exception response ────────────────────────────────────────────────
    //
    // Format: [addr | fc|0x80 | exceptionCode | crcLo | crcHi]
    //
    std::vector<uint8_t> make_exception(uint8_t fc, uint8_t code)
    {
        std::vector<uint8_t> resp = { addr_,
                                      static_cast<uint8_t>(fc | 0x80),
                                      code };
        return append_crc(resp);
    }

    // ── Append CRC16 to a PDU (little-endian, per Modbus spec) ────────────
    static std::vector<uint8_t> append_crc(std::vector<uint8_t>& pdu)
    {
        uint16_t c = crc16(pdu.data(), pdu.size());
        pdu.push_back(c & 0xFF);          // CRC low byte first
        pdu.push_back((c >> 8) & 0xFF);   // CRC high byte
        return pdu;
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// Serial port detection & configuration utilities
// ═══════════════════════════════════════════════════════════════════════════

/// Scan /dev for ttyUSB* and ttyACM* devices (real adapters, not legacy ttyS*).
inline std::vector<std::string> scan_serial_ports()
{
    std::vector<std::string> ports;
    DIR* d = opendir("/dev");
    if (!d) return ports;
    while (auto* e = readdir(d)) {
        std::string name = e->d_name;
        if (name.rfind("ttyUSB", 0) == 0 || name.rfind("ttyACM", 0) == 0)
            ports.push_back("/dev/" + name);
    }
    closedir(d);
    std::sort(ports.begin(), ports.end());
    return ports;
}

/// Map baud-rate integer to termios speed constant.
inline speed_t baud_to_speed(int baud)
{
    switch (baud) {
        case 9600:   return B9600;
        case 19200:  return B19200;
        case 38400:  return B38400;
        case 57600:  return B57600;
        case 115200: return B115200;
        default:     return B9600;
    }
}

/**
 * Open and configure a serial port for Modbus RTU slave operation.
 *
 * @param port   Device path, e.g. "/dev/ttyUSB0"
 * @param baud   Baud rate (9600, 19200, …)
 * @return       File descriptor (>= 0) on success, -1 on failure
 *
 * Configuration: 8N1, raw mode, no flow control.
 * VMIN=0, VTIME=2 → read() returns after 200ms idle (inter-frame gap detector
 * for RTU framing; 3.5 char times at 9600 = ~4ms, 200ms is conservative).
 */
inline int open_serial(const std::string& port, int baud)
{
    int fd = ::open(port.c_str(), O_RDWR | O_NOCTTY);
    if (fd < 0) {
        std::perror(("open(" + port + ")").c_str());
        return -1;
    }

    termios tty{};
    if (tcgetattr(fd, &tty) != 0) {
        std::perror("tcgetattr");
        ::close(fd);
        return -1;
    }

    speed_t sp = baud_to_speed(baud);
    cfsetospeed(&tty, sp);
    cfsetispeed(&tty, sp);

    // 8N1, raw mode, no flow control
    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_cflag &= ~(PARENB | CSTOPB | CRTSCTS);
    tty.c_cflag |= CREAD | CLOCAL;
    tty.c_iflag  = 0;   // no input processing
    tty.c_oflag  = 0;   // no output processing
    tty.c_lflag  = 0;   // raw mode (no echo, no canonical)

    // VMIN=0, VTIME=2: read() returns on data or after 200ms timeout.
    // This timeout acts as the Modbus RTU inter-frame gap detector.
    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 2;  // tenths of a second

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        std::perror("tcsetattr");
        ::close(fd);
        return -1;
    }
    tcflush(fd, TCIOFLUSH);
    return fd;
}

/// Hex-dump a byte buffer (for debug logging — uses stderr for immediacy).
inline void log_hex(const char* label, const uint8_t* data, size_t len)
{
    std::fprintf(stderr, "%s (%zuB):", label, len);
    for (size_t i = 0; i < len; ++i) std::fprintf(stderr, " %02X", data[i]);
    std::fprintf(stderr, "\n");
}

/**
 * Decode and log a Modbus RTU frame in human-readable form.
 *
 * This is the primary tool for reverse-engineering the master's register map:
 * it prints the function code, register addresses, counts, and data values
 * for every request/response frame.
 */
inline void log_frame_decoded(const char* direction, const uint8_t* data, size_t len)
{
    if (len < 4) {
        std::fprintf(stderr, "  %s: frame too short (%zuB)\n", direction, len);
        return;
    }

    // Hex dump first.
    std::fprintf(stderr, "  %s (%zuB):", direction, len);
    for (size_t i = 0; i < len; ++i) std::fprintf(stderr, " %02X", data[i]);
    std::fprintf(stderr, "\n");

    // CRC check.
    uint16_t rx_crc = data[len - 2] | (data[len - 1] << 8);
    bool crc_valid = (rx_crc == crc16(data, len - 2));
    if (!crc_valid) {
        std::fprintf(stderr, "    ⚠ BAD CRC (got 0x%04X, expected 0x%04X)\n",
                     rx_crc, crc16(data, len - 2));
        return;
    }

    uint8_t addr = data[0];
    uint8_t fc   = data[1];

    switch (fc) {
    case 0x03: // Read Holding Registers
        if (len >= 8) {
            uint16_t start = (data[2] << 8) | data[3];
            uint16_t count = (data[4] << 8) | data[5];
            std::fprintf(stderr, "    → FC03 ReadHoldingRegs  addr=%u  start=0x%04X  count=%u\n",
                         addr, start, count);
        } else if (len >= 5 && data[2] > 0) {
            // Response: addr + fc + byteCount + data...
            uint8_t bc = data[2];
            uint16_t nregs = bc / 2;
            std::fprintf(stderr, "    → FC03 Response  %u bytes (%u regs):", bc, nregs);
            for (uint16_t i = 0; i < nregs && (3u + i*2u + 1u) < len - 2u; ++i) {
                uint16_t val = (data[3 + i*2] << 8) | data[4 + i*2];
                std::fprintf(stderr, " [%u]=0x%04X", i, val);
            }
            std::fprintf(stderr, "\n");
        }
        break;

    case 0x06: // Write Single Register
        if (len >= 8) {
            uint16_t reg_addr = (data[2] << 8) | data[3];
            uint16_t value    = (data[4] << 8) | data[5];
            std::fprintf(stderr, "    → FC06 WriteSingleReg  addr=%u  reg=0x%04X  value=0x%04X (%u)\n",
                         addr, reg_addr, value, value);
        }
        break;

    case 0x10: // Write Multiple Registers
        if (len >= 9) {
            uint16_t start    = (data[2] << 8) | data[3];
            uint16_t count    = (data[4] << 8) | data[5];
            uint8_t  byte_cnt = data[6];
            std::fprintf(stderr, "    → FC10 WriteMultipleRegs  addr=%u  start=0x%04X  count=%u  bytes=%u",
                         addr, start, count, byte_cnt);
            // Print each register value in the request.
            for (uint16_t i = 0; i < count && (7u + i*2u + 1u) < len - 2u; ++i) {
                uint16_t val = (data[7 + i*2] << 8) | data[8 + i*2];
                std::fprintf(stderr, "  [0x%04X]=0x%04X", start + i, val);
            }
            std::fprintf(stderr, "\n");
        } else if (len == 8) {
            // Response to FC10 (echo start + count).
            uint16_t start = (data[2] << 8) | data[3];
            uint16_t count = (data[4] << 8) | data[5];
            std::fprintf(stderr, "    → FC10 Response  start=0x%04X  count=%u\n", start, count);
        }
        break;

    default:
        if (fc & 0x80) {
            std::fprintf(stderr, "    → Exception  FC=0x%02X  code=0x%02X\n",
                         fc & 0x7F, (len >= 3) ? data[2] : 0);
        } else {
            std::fprintf(stderr, "    → FC=0x%02X (unrecognized)\n", fc);
        }
        break;
    }
}

/**
 * Probe a serial port by waiting briefly for incoming master traffic.
 *
 * Opens the port, listens for up to `timeout_ms` milliseconds, and returns
 * true if any bytes arrive (indicating an active master is transmitting).
 */
inline bool probe_port(const std::string& port, int baud, int timeout_ms = 3000)
{
    int fd = open_serial(port, baud);
    if (fd < 0) return false;

    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);
    struct timeval tv;
    tv.tv_sec  = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;

    bool got_data = (::select(fd + 1, &rfds, nullptr, nullptr, &tv) > 0);
    if (got_data) {
        uint8_t tmp[256];
        ssize_t n = ::read(fd, tmp, sizeof(tmp));
        if (n > 0) log_hex("  probe rx", tmp, static_cast<size_t>(n));
    }
    ::close(fd);
    return got_data;
}

/**
 * Auto-detect the serial port and baud rate of the connected Modbus master.
 *
 * Scans all ttyUSB/ttyACM ports, tries baud rates 9600 → 19200 → 38400,
 * and returns the first port+baud that receives traffic.
 *
 * @param out_port  Receives detected port path
 * @param out_baud  Receives detected baud rate
 * @return true if a port was found
 */
inline bool detect_master(std::string& out_port, int& out_baud)
{
    auto ports = scan_serial_ports();
    if (ports.empty()) {
        std::cerr << "No ttyUSB/ttyACM ports found.\n";
        return false;
    }

    std::cout << "Detected serial ports:\n";
    for (auto& p : ports) std::cout << "  " << p << "\n";

    static const int bauds[] = {9600, 19200, 38400};

    for (auto& port : ports) {
        for (int baud : bauds) {
            std::fprintf(stderr, "Probing %s @ %d baud … ", port.c_str(), baud);
            if (probe_port(port, baud, 3000)) {
                std::fprintf(stderr, "✓ master traffic detected!\n");
                out_port = port;
                out_baud = baud;
                return true;
            }
            std::fprintf(stderr, "no traffic\n");
        }
    }
    return false;
}

/**
 * Run the slave on a real serial port with full request/response logging.
 *
 * This is the "batteries-included" entry point: opens the port, wires up
 * read/write callbacks with hex logging, and enters Slave::run().
 *
 * @param slave    Configured Slave instance
 * @param port     Serial port path
 * @param baud     Baud rate
 * @param running  Set to false (e.g. from signal handler) to stop
 */
inline void run_serial_slave(Slave& slave, const std::string& port,
                             int baud, volatile bool& running)
{
    int fd = open_serial(port, baud);
    if (fd < 0) {
        std::cerr << "Failed to open " << port << "\n";
        return;
    }
    std::fprintf(stderr, "═══════════════════════════════════════════════\n");
    std::fprintf(stderr, "  Modbus RTU slave running\n");
    std::fprintf(stderr, "  Port : %s\n", port.c_str());
    std::fprintf(stderr, "  Baud : %d  (8N1)\n", baud);
    std::fprintf(stderr, "  Addr : %d\n", slave.addr());
    std::fprintf(stderr, "  Regs : %u holding registers\n", slave.num_regs());
    std::fprintf(stderr, "  Ctrl-C to stop\n");
    std::fprintf(stderr, "═══════════════════════════════════════════════\n\n");

    // Accumulate bytes until inter-frame gap (read returns 0), then process.
    std::vector<uint8_t> rxbuf;
    rxbuf.reserve(256);
    unsigned long frame_count = 0;

    while (running) {
        uint8_t tmp[256];
        ssize_t n = ::read(fd, tmp, sizeof(tmp));

        if (n > 0) {
            rxbuf.insert(rxbuf.end(), tmp, tmp + static_cast<size_t>(n));
            continue;  // keep accumulating until gap
        }

        // n <= 0: VTIME timeout — inter-frame gap detected
        if (!rxbuf.empty()) {
            ++frame_count;
            std::fprintf(stderr, "── frame #%lu ──\n", frame_count);
            log_frame_decoded("RX", rxbuf.data(), rxbuf.size());

            auto resp = slave.process_request(rxbuf);
            if (!resp.empty()) {
                log_frame_decoded("TX", resp.data(), resp.size());
                ::write(fd, resp.data(), resp.size());
                tcdrain(fd);
            } else {
                std::fprintf(stderr, "  (no response: addr mismatch or bad CRC)\n");
            }
            rxbuf.clear();
        }
    }

    ::close(fd);
    std::fprintf(stderr, "\nSlave stopped after %lu frames.\n", frame_count);
}

} // namespace modbus_rtu_slave
