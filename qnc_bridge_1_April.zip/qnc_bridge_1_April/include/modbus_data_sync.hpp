#pragma once
/**
 * modbus_data_sync.hpp — Data synchronization layer between Modbus registers and DDS
 *
 * Provides bidirectional mapping:
 *   - DDS gripper state → Modbus status registers (0x0000–0x0003)
 *   - Modbus command registers (0x0010–0x0015) → DDS gripper commands
 *
 * Usage:
 *   1. Create synchronizer with reference to Modbus bridge
 *   2. Register callbacks for DDS state updates and command extraction
 *   3. Call update_from_dds() when gripper state changes (from DDS subscriber)
 *   4. Call on_modbus_write() from bridge write callback to extract commands
 *   5. Thread-safe: multiple threads can call update_from_dds() and read_command()
 */

#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

namespace modbus_data_sync {

// ═══════════════════════════════════════════════════════════════════════════
// Register Address Map
// ═══════════════════════════════════════════════════════════════════════════

/// Status registers (robot → master, master reads via FC03)
namespace status_regs {
constexpr uint16_t STATUSWORD = 0x0000;
constexpr uint16_t DIAGNOSTIC_CODE = 0x0001;
constexpr uint16_t ACTUAL_POSITION = 0x0002;
constexpr uint16_t TARGET_POSITION = 0x0003;
}

/// Command registers (master → robot, master writes via FC06/FC10)
namespace command_regs {
constexpr uint16_t CONTROL_WORD = 0x0010;
constexpr uint16_t GRIP_MODE = 0x0011;
constexpr uint16_t GRIP_FORCE_PCT = 0x0012;
constexpr uint16_t GRIP_VELOCITY_PCT = 0x0013;
constexpr uint16_t WORKPIECE_NUMBER = 0x0014;
constexpr uint16_t POSITION_TOLERANCE_PCT = 0x0015;
}

// ═══════════════════════════════════════════════════════════════════════════
// Status Word Bit Definitions
// ═══════════════════════════════════════════════════════════════════════════

constexpr uint16_t STATUS_READY = 0x0001;   // Bit 0: gripper ready
constexpr uint16_t STATUS_MOVING = 0x0002;  // Bit 1: gripper in motion
constexpr uint16_t STATUS_ERROR = 0x0004;   // Bit 2: gripper error/fault
constexpr uint16_t STATUS_FAULT_CODE_AVAILABLE = 0x0008;  // Bit 3: fault code valid

// ═══════════════════════════════════════════════════════════════════════════
// Control Word Bit Definitions
// ═══════════════════════════════════════════════════════════════════════════

constexpr uint16_t CONTROL_GRIP = 0x0001;      // Bit 0: grip command
constexpr uint16_t CONTROL_RELEASE = 0x0002;   // Bit 1: release command
constexpr uint16_t CONTROL_STOP = 0x0004;      // Bit 2: stop/abort
constexpr uint16_t CONTROL_POSITION_MODE = 0x0008;  // Bit 3: position mode

// ═══════════════════════════════════════════════════════════════════════════
// Enums
// ═══════════════════════════════════════════════════════════════════════════

enum class GripMode : uint16_t {
    GRIP = 0,
    RELEASE = 1,
    IDLE = 2,
};

// ═══════════════════════════════════════════════════════════════════════════
// Data Structures: Gripper State (DDS → Modbus)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Snapshot of gripper state (read from DDS, converted to Modbus registers).
 */
struct GripperState {
    bool ready = false;
    bool moving = false;
    bool error = false;
    uint16_t error_code = 0;

    // Position in 0.01mm units (0..4000 for 40mm stroke, e.g.)
    uint16_t actual_position_units = 0;

    // Echoed from last command
    uint16_t target_position_units = 0;

    /**
     * Convert to Modbus status word.
     *
     * Format:
     *   Bit 0: ready
     *   Bit 1: moving
     *   Bit 2: error
     *   Bit 3: error_code available
     */
    uint16_t to_status_word() const {
        uint16_t word = 0;
        if (ready) word |= STATUS_READY;
        if (moving) word |= STATUS_MOVING;
        if (error) word |= STATUS_ERROR;
        if (error_code != 0) word |= STATUS_FAULT_CODE_AVAILABLE;
        return word;
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// Data Structures: Gripper Command (Modbus → DDS)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Command extracted from Modbus registers (written by master).
 */
struct GripperCommand {
    bool grip = false;
    bool release = false;
    bool stop = false;
    bool position_mode = false;

    GripMode mode = GripMode::IDLE;
    uint16_t force_percent = 50;    // 0–100%
    uint16_t velocity_percent = 50; // 0–100%
    uint16_t target_position_units = 0;  // For position mode
    uint16_t tolerance_percent = 10;  // 0–100%
    uint16_t workpiece_number = 0;

    /// Check if this is a valid command (at least one action bit set).
    bool is_valid() const {
        return grip || release || stop || position_mode;
    }

    /// Convert from Modbus control word.
    static GripperCommand from_control_word(uint16_t word) {
        GripperCommand cmd;
        cmd.grip = (word & CONTROL_GRIP) != 0;
        cmd.release = (word & CONTROL_RELEASE) != 0;
        cmd.stop = (word & CONTROL_STOP) != 0;
        cmd.position_mode = (word & CONTROL_POSITION_MODE) != 0;
        return cmd;
    }

    /// Convert to Modbus control word.
    uint16_t to_control_word() const {
        uint16_t word = 0;
        if (grip) word |= CONTROL_GRIP;
        if (release) word |= CONTROL_RELEASE;
        if (stop) word |= CONTROL_STOP;
        if (position_mode) word |= CONTROL_POSITION_MODE;
        return word;
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// Synchronization Handler
// ═══════════════════════════════════════════════════════════════════════════

class Synchronizer {
public:
    // Callback: invoked when a new command is available from Modbus (master writes)
    using OnCommandCallback = std::function<void(const GripperCommand&)>;

    // Callback: invoked when bridge requests current gripper state (optional)
    using OnStateRequestCallback = std::function<void()>;

    explicit Synchronizer() : last_command_valid_(false) {}

    /**
     * Update status registers from gripper state (DDS → Modbus).
     *
     * Typically called from a DDS subscriber callback when gripper state changes.
     * Thread-safe: locks internally.
     *
     * @param state Current gripper state
     * @return A list of (register_address, value) pairs to write to Modbus
     */
    std::vector<std::pair<uint16_t, uint16_t>> update_from_dds(const GripperState& state) {
        std::lock_guard<std::mutex> lock(state_mutex_);
        gripper_state_ = state;

        // Build register updates
        std::vector<std::pair<uint16_t, uint16_t>> updates;
        updates.push_back({status_regs::STATUSWORD, state.to_status_word()});
        updates.push_back({status_regs::DIAGNOSTIC_CODE, state.error_code});
        updates.push_back({status_regs::ACTUAL_POSITION, state.actual_position_units});
        updates.push_back({status_regs::TARGET_POSITION, state.target_position_units});

        return updates;
    }

    /**
     * Hook this as the Modbus bridge's write callback.
     *
     * Called when master writes to command registers (0x0010–0x0015).
     * Extracts command data and invokes on_command callback if valid.
     *
     * @param start First register address written
     * @param count Number of registers written
     * @param get_reg Callback to read register value (e.g., lambda to bridge->get_register)
     */
    void on_modbus_write(uint16_t start, uint16_t count,
                         std::function<uint16_t(uint16_t)> get_reg) {
        std::lock_guard<std::mutex> lock(command_mutex_);

        // Check if any of the written registers overlap with command regs
        uint16_t cmd_start = command_regs::CONTROL_WORD;
        uint16_t cmd_end = command_regs::POSITION_TOLERANCE_PCT;

        if (start > cmd_end || (start + count - 1) < cmd_start) {
            return;  // No overlap
        }

        // Extract command from all relevant registers
        GripperCommand cmd;
        cmd.grip = (get_reg(command_regs::CONTROL_WORD) & CONTROL_GRIP) != 0;
        cmd.release = (get_reg(command_regs::CONTROL_WORD) & CONTROL_RELEASE) != 0;
        cmd.stop = (get_reg(command_regs::CONTROL_WORD) & CONTROL_STOP) != 0;
        cmd.position_mode = (get_reg(command_regs::CONTROL_WORD) & CONTROL_POSITION_MODE) != 0;

        uint16_t mode_val = get_reg(command_regs::GRIP_MODE);
        cmd.mode = static_cast<GripMode>(mode_val);

        cmd.force_percent = get_reg(command_regs::GRIP_FORCE_PCT);
        cmd.velocity_percent = get_reg(command_regs::GRIP_VELOCITY_PCT);
        cmd.target_position_units = get_reg(command_regs::CONTROL_WORD);  // For position mode
        cmd.tolerance_percent = get_reg(command_regs::POSITION_TOLERANCE_PCT);
        cmd.workpiece_number = get_reg(command_regs::WORKPIECE_NUMBER);

        // Clamp values to valid ranges
        cmd.force_percent = std::min(cmd.force_percent, (uint16_t)100);
        cmd.velocity_percent = std::min(cmd.velocity_percent, (uint16_t)100);
        cmd.tolerance_percent = std::min(cmd.tolerance_percent, (uint16_t)100);

        last_command_ = cmd;
        last_command_valid_ = true;

        // Invoke callback if registered
        if (on_command_callback_) {
            on_command_callback_(cmd);
        }
    }

    /**
     * Get the last extracted command.
     *
     * @return Command, or invalid command if none has been received yet
     */
    GripperCommand get_last_command() const {
        std::lock_guard<std::mutex> lock(command_mutex_);
        return last_command_;
    }

    /// Check if we have a valid command from Modbus.
    bool has_valid_command() const {
        std::lock_guard<std::mutex> lock(command_mutex_);
        return last_command_valid_;
    }

    /**
     * Mark the command as processed (clears the "new" flag).
     */
    void clear_command() {
        std::lock_guard<std::mutex> lock(command_mutex_);
        last_command_valid_ = false;
    }

    /**
     * Get current gripper state (last update from DDS).
     */
    GripperState get_state() const {
        std::lock_guard<std::mutex> lock(state_mutex_);
        return gripper_state_;
    }

    /// Register callback for command extraction.
    void set_on_command(OnCommandCallback cb) {
        on_command_callback_ = std::move(cb);
    }

    /// Register callback for state requests.
    void set_on_state_request(OnStateRequestCallback cb) {
        on_state_request_callback_ = std::move(cb);
    }

private:
    mutable std::mutex state_mutex_;
    mutable std::mutex command_mutex_;

    GripperState gripper_state_;
    GripperCommand last_command_;
    bool last_command_valid_;

    OnCommandCallback on_command_callback_;
    OnStateRequestCallback on_state_request_callback_;
};

// ═══════════════════════════════════════════════════════════════════════════
// Utilities
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Convert position in millimeters to register units (0.01mm per unit).
 *
 * @param mm Position in mm (e.g., 12.5)
 * @return Register value (e.g., 1250 for 12.5mm)
 */
inline uint16_t mm_to_register_units(double mm) {
    return static_cast<uint16_t>(mm * 100.0);
}

/**
 * Convert register units to millimeters.
 *
 * @param units Register value (e.g., 1250)
 * @return Position in mm (e.g., 12.5)
 */
inline double register_units_to_mm(uint16_t units) {
    return units / 100.0;
}

/**
 * Pretty-print a command for debugging.
 */
inline void print_command(const GripperCommand& cmd) {
    std::printf("Command: ");
    if (cmd.grip) std::printf("GRIP ");
    if (cmd.release) std::printf("RELEASE ");
    if (cmd.stop) std::printf("STOP ");
    if (cmd.position_mode) std::printf("POSITION_MODE ");
    std::printf("| mode=%d force=%u%% velocity=%u%% pos=%u tol=%u%% wp=%u\n",
                static_cast<int>(cmd.mode), cmd.force_percent, cmd.velocity_percent,
                cmd.target_position_units, cmd.tolerance_percent, cmd.workpiece_number);
}

/**
 * Pretty-print gripper state for debugging.
 */
inline void print_state(const GripperState& state) {
    std::printf("State: %s%s%s | pos=%u target=%u err=%04x\n",
                state.ready ? "READY " : "",
                state.moving ? "MOVING " : "",
                state.error ? "ERROR " : "",
                state.actual_position_units, state.target_position_units,
                state.error_code);
}

}  // namespace modbus_data_sync
