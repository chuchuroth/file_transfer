#pragma once
/**
 * modbus_rtu_common.hpp — shared Modbus RTU / RS485 plumbing
 *
 * Header-only base class extracted from duplicate code in:
 *   - src/gripper_control.cpp     (SerialModbusDevice)
 *   - deploy_on_qnc/qnc_bridge.cpp (ModbusRtu)
 *
 * Provides: CRC16, serial port configuration (115200 8N1), sysfs DE/RE GPIO
 * control, Modbus RTU frame building, transact (TX + RX with select), and
 * response validation.
 */

#include <chrono>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <termios.h>
#include <unistd.h>
#include <vector>
#include <sys/select.h>

namespace modbus_rtu {

/// Modbus CRC16 (polynomial 0xA001).
inline uint16_t crc16(const uint8_t* data, size_t len)
{
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int j = 0; j < 8; ++j)
            crc = (crc & 0x0001) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}

/**
 * Base class for Modbus RTU masters over RS485.
 *
 * Owns the serial file descriptor and optional DE/RE GPIO; provides the
 * core helpers that every Modbus RTU master needs.  Derived classes add
 * their own constructor (port opening, GPIO policy) and register-level
 * read/write API.
 */
class Base {
protected:
    int         fd_       = -1;
    int         de_re_fd_ = -1;
    std::string port_;

    Base() = default;
    ~Base() = default;
    Base(const Base&) = delete;
    Base& operator=(const Base&) = delete;

    // -- Serial port setup (115200 8N1) ------------------------------------

    void configure_port()
    {
        termios tty{};
        if (tcgetattr(fd_, &tty) != 0)
            throw std::runtime_error("tcgetattr failed");

        cfsetospeed(&tty, B115200);
        cfsetispeed(&tty, B115200);

        tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
        tty.c_cflag &= ~PARENB;
        tty.c_cflag &= ~CSTOPB;
        tty.c_cflag &= ~CRTSCTS;
        tty.c_cflag |= CREAD | CLOCAL;
        tty.c_iflag  = 0;
        tty.c_oflag  = 0;
        tty.c_lflag  = 0;
        tty.c_cc[VMIN]  = 0;
        tty.c_cc[VTIME] = 0;

        if (tcsetattr(fd_, TCSANOW, &tty) != 0)
            throw std::runtime_error("tcsetattr failed");
    }

    // -- DE/RE GPIO (sysfs legacy interface) --------------------------------

    void setup_de_re_gpio(int sysfs_num)
    {
        { int efd = ::open("/sys/class/gpio/export", O_WRONLY);
          if (efd >= 0) {
              std::string s = std::to_string(sysfs_num);
              if (::write(efd, s.c_str(), s.size()) < 0) { /* best effort */ }
              ::close(efd);
          }}
        usleep(50000);

        std::string dir_path = "/sys/class/gpio/gpio"
                               + std::to_string(sysfs_num) + "/direction";
        int dfd = ::open(dir_path.c_str(), O_WRONLY);
        if (dfd < 0) {
            std::cerr << "\u26a0 Cannot open GPIO" << sysfs_num
                      << " direction \u2014 DE/RE uncontrolled\n";
            return;
        }
        if (::write(dfd, "out", 3) < 0) { /* best effort */ }
        ::close(dfd);

        std::string val_path = "/sys/class/gpio/gpio"
                               + std::to_string(sysfs_num) + "/value";
        de_re_fd_ = ::open(val_path.c_str(), O_WRONLY);
        if (de_re_fd_ < 0) {
            std::cerr << "\u26a0 Cannot open GPIO" << sysfs_num
                      << " value \u2014 DE/RE uncontrolled\n";
            return;
        }
        if (::write(de_re_fd_, "0", 1) < 0) { /* best effort */ }
        std::cout << "\u2713 DE/RE GPIO" << sysfs_num << " active\n";
    }

    void de_re_tx() { if (de_re_fd_ >= 0 && ::pwrite(de_re_fd_, "1", 1, 0) < 0) { /* best effort */ } }
    void de_re_rx() { if (de_re_fd_ >= 0 && ::pwrite(de_re_fd_, "0", 1, 0) < 0) { /* best effort */ } }

    // -- Modbus RTU frame helpers -------------------------------------------

    static std::vector<uint8_t> build_frame(const std::vector<uint8_t>& pdu)
    {
        auto frame = pdu;
        uint16_t c = crc16(frame.data(), frame.size());
        frame.push_back(c & 0xFF);
        frame.push_back((c >> 8) & 0xFF);
        return frame;
    }

    std::vector<uint8_t> transact(const std::vector<uint8_t>& frame,
                                  size_t max_bytes,
                                  int timeout_ms = 2000)
    {
        tcflush(fd_, TCIOFLUSH);
        de_re_tx();
        if (::write(fd_, frame.data(), frame.size()) < 0) {
            de_re_rx();
            return {};
        }
        tcdrain(fd_);
        usleep(500);
        de_re_rx();

        std::vector<uint8_t> response;
        response.reserve(max_bytes);

        auto deadline = std::chrono::steady_clock::now()
                        + std::chrono::milliseconds(timeout_ms);

        while (response.size() < max_bytes) {
            auto now       = std::chrono::steady_clock::now();
            auto remaining = std::chrono::duration_cast<std::chrono::microseconds>(
                                 deadline - now).count();
            if (remaining <= 0) break;

            struct timeval tv;
            tv.tv_sec  = remaining / 1'000'000;
            tv.tv_usec = remaining % 1'000'000;

            fd_set rfds;
            FD_ZERO(&rfds);
            FD_SET(fd_, &rfds);

            if (::select(fd_ + 1, &rfds, nullptr, nullptr, &tv) <= 0) break;

            uint8_t tmp[256];
            ssize_t n = ::read(fd_, tmp,
                               std::min(sizeof(tmp), max_bytes - response.size()));
            if (n > 0)
                response.insert(response.end(), tmp, tmp + n);
        }
        return response;
    }

    static bool validate_response(const std::vector<uint8_t>& resp,
                                  uint8_t expected_id, uint8_t expected_fc)
    {
        if (resp.size() < 4) return false;
        if (resp[0] != expected_id) return false;
        if (resp[1] == (expected_fc | 0x80)) {
            std::cerr << "  Modbus exception 0x" << std::hex
                      << static_cast<int>(resp[2]) << std::dec << "\n";
            return false;
        }
        if (resp[1] != expected_fc) return false;

        size_t len     = resp.size();
        uint16_t r_crc = resp[len-2] | (resp[len-1] << 8);
        return r_crc == crc16(resp.data(), len - 2);
    }
};

} // namespace modbus_rtu
