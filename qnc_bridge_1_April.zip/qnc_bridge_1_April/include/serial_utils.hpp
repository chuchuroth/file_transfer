#pragma once
/**
 * serial_utils.hpp — General serial port management utilities
 *
 * Provides reusable serial port operations:
 *   - Port detection and enumeration
 *   - Baud rate configuration
 *   - Non-blocking read/write with select()
 *   - Error messages and diagnostics
 *   - Configuration presets for common scenarios
 *
 * Designed to be independent of Modbus RTU or any specific protocol.
 */

#include <cstring>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <iostream>
#include <string>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#include <vector>

namespace serial_utils {

// ═══════════════════════════════════════════════════════════════════════════
// Common Baud Rate Constants
// ═══════════════════════════════════════════════════════════════════════════

constexpr int BAUD_9600 = 9600;
constexpr int BAUD_19200 = 19200;
constexpr int BAUD_38400 = 38400;
constexpr int BAUD_57600 = 57600;
constexpr int BAUD_115200 = 115200;
constexpr int BAUD_230400 = 230400;

constexpr int BAUD_DEFAULT_RTU = 115200;  // Standard Modbus RTU

// ═══════════════════════════════════════════════════════════════════════════
// Port Detection
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Scan /dev for ttyUSB* and ttyACM* devices.
 *
 * Returns a sorted list of USB serial adapters (not legacy ttyS* devices).
 * This is helpful for auto-detecting connected USB-to-Serial adapters.
 *
 * @return Sorted vector of device paths like ["/dev/ttyACM0", "/dev/ttyUSB0"]
 */
inline std::vector<std::string> scan_usb_serial_ports() {
    std::vector<std::string> ports;
    DIR* d = opendir("/dev");
    if (!d) {
        std::cerr << "Error: Cannot scan /dev: " << std::strerror(errno) << "\n";
        return ports;
    }

    while (auto* e = readdir(d)) {
        std::string name = e->d_name;
        if (name.rfind("ttyUSB", 0) == 0 || name.rfind("ttyACM", 0) == 0) {
            ports.push_back("/dev/" + name);
        }
    }

    closedir(d);
    std::sort(ports.begin(), ports.end());
    return ports;
}

/**
 * Check if a serial port device exists and is accessible.
 *
 * @param port Path to device file (e.g., "/dev/ttyUSB0")
 * @return true if device exists and can be opened
 */
inline bool port_exists(const std::string& port) {
    int fd = open(port.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) return false;
    close(fd);
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// Baud Rate Mapping
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Convert integer baud rate to termios speed_t constant.
 *
 * @param baud Digital baud rate (9600, 115200, etc.)
 * @return termios speed constant, or B115200 if unsupported (logs warning)
 */
inline speed_t baud_to_speed_t(int baud) {
    switch (baud) {
        case 9600:    return B9600;
        case 19200:   return B19200;
        case 38400:   return B38400;
        case 57600:   return B57600;
        case 115200:  return B115200;
        case 230400:  return B230400;
        default:
            std::cerr << "Warning: unsupported baud rate " << baud
                      << ", using 115200\n";
            return B115200;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Port Configuration Presets
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Parity mode selector.
 */
enum class Parity {
    NONE,  // No parity (default)
    EVEN,  // Even parity
    ODD,   // Odd parity
};

/**
 * Data bits selector.
 */
enum class DataBits {
    BITS_5 = 5,
    BITS_6 = 6,
    BITS_7 = 7,
    BITS_8 = 8,  // Default
};

/**
 * Stop bits selector.
 */
enum class StopBits {
    ONE = 1,   // Default
    TWO = 2,
};

/**
 * Predefined serial port configurations.
 */
struct Config {
    int baud_rate = BAUD_115200;
    DataBits data_bits = DataBits::BITS_8;
    StopBits stop_bits = StopBits::ONE;
    Parity parity = Parity::NONE;

    /// Standard 8N1 (8 data bits, no parity, 1 stop bit) — Modbus RTU default
    static Config Modbus_RTU() {
        return Config{BAUD_115200, DataBits::BITS_8, StopBits::ONE, Parity::NONE};
    }

    /// Standard 9600 8N1 (legacy industrial)
    static Config Legacy_Industrial() {
        return Config{9600, DataBits::BITS_8, StopBits::ONE, Parity::NONE};
    }

    /// Higher speed: 230400 8N1
    static Config HighSpeed() {
        return Config{230400, DataBits::BITS_8, StopBits::ONE, Parity::NONE};
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// Low-Level Port Operations
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Open a serial port with the given configuration.
 *
 * Configures:
 *   - Baud rate
 *   - Data bits, parity, stop bits
 *   - Non-blocking mode (for use with select())
 *   - Raw mode (no canonical line editing)
 *   - No echo, no signals, no flow control
 *
 * @param port Path to device (e.g., "/dev/ttyUSB0")
 * @param config Port settings
 * @return File descriptor on success, -1 on error (error message to stderr)
 */
inline int open_port(const std::string& port, const Config& config) {
    // Open in non-blocking mode
    int fd = open(port.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) {
        std::cerr << "Failed to open " << port << ": " << std::strerror(errno)
                  << "\n";
        return -1;
    }

    // Get current terminal attributes
    termios tio = {};
    if (tcgetattr(fd, &tio) < 0) {
        std::cerr << "tcgetattr(" << port << ") failed: " << std::strerror(errno)
                  << "\n";
        close(fd);
        return -1;
    }

    // ── Baud rate ─────────────────────────────────────────────────────────
    speed_t speed = baud_to_speed_t(config.baud_rate);
    cfsetispeed(&tio, speed);
    cfsetospeed(&tio, speed);

    // ── Data bits ──────────────────────────────────────────────────────────
    tio.c_cflag &= ~CSIZE;
    switch (config.data_bits) {
        case DataBits::BITS_5:
            tio.c_cflag |= CS5;
            break;
        case DataBits::BITS_6:
            tio.c_cflag |= CS6;
            break;
        case DataBits::BITS_7:
            tio.c_cflag |= CS7;
            break;
        case DataBits::BITS_8:
        default:
            tio.c_cflag |= CS8;
            break;
    }

    // ── Parity ────────────────────────────────────────────────────────────
    switch (config.parity) {
        case Parity::EVEN:
            tio.c_cflag |= PARENB;
            tio.c_cflag &= ~PARODD;  // Even
            break;
        case Parity::ODD:
            tio.c_cflag |= PARENB;
            tio.c_cflag |= PARODD;   // Odd
            break;
        case Parity::NONE:
        default:
            tio.c_cflag &= ~PARENB;  // No parity
            break;
    }

    // ── Stop bits ──────────────────────────────────────────────────────────
    switch (config.stop_bits) {
        case StopBits::TWO:
            tio.c_cflag |= CSTOPB;
            break;
        case StopBits::ONE:
        default:
            tio.c_cflag &= ~CSTOPB;
            break;
    }

    // ── Control flags ──────────────────────────────────────────────────────
    tio.c_cflag |= CREAD;    // Enable receiver
    tio.c_cflag |= CLOCAL;   // Ignore modem lines (DTR/DSR/CTS/RTS)

    // ── Local flags (raw mode, no line editing) ─────────────────────────
    tio.c_lflag &= ~ICANON;  // Raw mode (not canonical)
    tio.c_lflag &= ~ECHO;    // No echo
    tio.c_lflag &= ~ISIG;    // No ^C, ^Z, etc.

    // ── Input flags (no software flow control) ───────────────────────────
    tio.c_iflag &= ~(IXON | IXOFF | IXANY);

    // ── Output flags (no processing) ───────────────────────────────────────
    tio.c_oflag &= ~OPOST;

    // ── Control characters ────────────────────────────────────────────────
    tio.c_cc[VMIN] = 0;      // Non-blocking read
    tio.c_cc[VTIME] = 0;     // No timeout

    // Apply new settings
    if (tcsetattr(fd, TCSANOW, &tio) < 0) {
        std::cerr << "tcsetattr(" << port << ") failed: " << std::strerror(errno)
                  << "\n";
        close(fd);
        return -1;
    }

    // Flush any pending data
    tcflush(fd, TCIOFLUSH);

    return fd;
}

/**
 * Close a serial port file descriptor.
 *
 * @param fd File descriptor returned by open_port()
 */
inline void close_port(int fd) {
    if (fd >= 0) {
        tcflush(fd, TCIOFLUSH);
        close(fd);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Non-blocking I/O
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Non-blocking read from serial port.
 *
 * Uses select() to wait for data with a timeout.
 *
 * @param fd File descriptor
 * @param buf Buffer to read into
 * @param max_len Maximum bytes to read
 * @param timeout_ms Timeout in milliseconds (0 = immediate, negative = block)
 *
 * @return Number of bytes read (0 = timeout, -1 = error)
 */
inline ssize_t nb_read(int fd, uint8_t* buf, size_t max_len, int timeout_ms) {
    if (fd < 0 || !buf) return -1;

    fd_set readfds;
    FD_ZERO(&readfds);
    FD_SET(fd, &readfds);

    struct timeval tv {
        .tv_sec = timeout_ms / 1000,
        .tv_usec = (timeout_ms % 1000) * 1000
    };

    int select_ret = select(fd + 1, &readfds, nullptr, nullptr, &tv);
    if (select_ret < 0) {
        std::cerr << "select() error: " << std::strerror(errno) << "\n";
        return -1;
    }

    if (select_ret == 0) {
        return 0;  // Timeout
    }

    ssize_t n = read(fd, buf, max_len);
    if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
        std::cerr << "read() error: " << std::strerror(errno) << "\n";
        return -1;
    }

    return n >= 0 ? n : 0;
}

/**
 * Write data to serial port.
 *
 * Attempts to write all data; returns early only on error.
 *
 * @param fd File descriptor
 * @param buf Data to write
 * @param len Number of bytes to write
 *
 * @return Number of bytes written (-1 = error)
 */
inline ssize_t write_port(int fd, const uint8_t* buf, size_t len) {
    if (fd < 0 || !buf) return -1;

    ssize_t total = 0;
    while (total < (ssize_t)len) {
        ssize_t n = write(fd, buf + total, len - total);
        if (n < 0) {
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
                std::cerr << "write() error: " << std::strerror(errno) << "\n";
                return -1;
            }
            // Retry on EAGAIN
            continue;
        }
        total += n;
    }

    return total;
}

/**
 * Write a text string to serial port.
 *
 * @param fd File descriptor
 * @param str Null-terminated string
 *
 * @return Number of bytes written (-1 = error)
 */
inline ssize_t write_port_string(int fd, const char* str) {
    return write_port(fd, (const uint8_t*)str, std::strlen(str));
}

// ═══════════════════════════════════════════════════════════════════════════
// Diagnostics & Error Reporting
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Get a human-readable error message for a system call.
 *
 * @return String describing the last errno
 */
inline std::string last_error() {
    return std::strerror(errno);
}

/**
 * Print current port configuration to stdout (for debugging).
 *
 * @param port Device path
 * @param fd File descriptor (optional; -1 to skip detailed settings)
 */
inline void print_port_info(const std::string& port, int fd = -1) {
    std::printf("Serial Port: %s\n", port.c_str());

    if (fd >= 0) {
        termios tio = {};
        if (tcgetattr(fd, &tio) == 0) {
            speed_t speed = cfgetospeed(&tio);
            const char* speed_str = "unknown";

            if (speed == B9600) speed_str = "9600";
            else if (speed == B19200) speed_str = "19200";
            else if (speed == B38400) speed_str = "38400";
            else if (speed == B57600) speed_str = "57600";
            else if (speed == B115200) speed_str = "115200";
            else if (speed == B230400) speed_str = "230400";

            std::printf("  Baud: %s\n", speed_str);
            std::printf("  Data bits: %d\n",
                        ((tio.c_cflag & CSIZE) == CS5 ? 5
                         : (tio.c_cflag & CSIZE) == CS6 ? 6
                         : (tio.c_cflag & CSIZE) == CS7 ? 7
                         : 8));
            std::printf("  Parity: %s\n",
                        (tio.c_cflag & PARENB ? (tio.c_cflag & PARODD ? "odd" : "even")
                                             : "none"));
            std::printf("  Stop bits: %d\n", (tio.c_cflag & CSTOPB ? 2 : 1));
        }
    }
}

}  // namespace serial_utils
