# QNC Gripper Bridge — System Documentation

Complete reference for the QNC RS485↔DDS gripper bridge system.
Covers execution setup, binary-to-source mapping, runtime behavior,
IDL design, generated code, communication flow, validation results,
and step-by-step reproducibility instructions.

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Execution Setup](#2-execution-setup)
3. [Binary-to-Source Mapping](#3-binary-to-source-mapping)
4. [Runtime Behavior & Logs](#4-runtime-behavior--logs)
5. [IDL Design](#5-idl-design)
6. [Generated Code](#6-generated-code)
7. [Communication Flow](#7-communication-flow)
8. [Validation Results](#8-validation-results)
9. [Reproducibility Guide](#9-reproducibility-guide)

---

## 1. Architecture Overview

```
┌────────────────────┐         DDS (FastDDS 3.4.1)         ┌──────────────────┐
│  Robot Computer    │  qnc/gripper/command (RELIABLE)      │   QNC Pi CM5     │
│                    │ ─────────────────────────────────────>│                  │
│ dds_command_       │                                      │   qnc_bridge     │
│   publisher        │  qnc/gripper/state   (RELIABLE)      │                  │
│                    │ <─────────────────────────────────────│                  │
└────────────────────┘                                      └────────┬─────────┘
                                                                     │ RS485 (115200 8N1)
                                                         ┌───────────┼───────────┐
                                                         │           │           │
                                                    ┌────┴───┐ ┌────┴───┐ ┌────┴───┐
                                                    │ AG-160 │ │ CGC-80 │ │ DH-5-6 │
                                                    │slave=1 │ │slave=2 │ │slave=3 │
                                                    └────────┘ └────────┘ └────────┘
```

**Technology Stack:**

| Component       | Version     | Purpose                                        |
|-----------------|-------------|-------------------------------------------------|
| FastDDS         | ≥ 3.4.1     | DDS middleware (peer discovery, pub/sub)         |
| Fast-CDR        | ≥ 2.3.4     | CDR serialization for generated IDL types        |
| NeuraSync       | ≥ 1.7       | DDS abstraction (ParticipantFactory, NeuraSyncNode) |
| fastddsgen      | 4.2.0       | IDL → C++ type support code generator            |
| nlohmann_json   | ≥ 3.11      | JSON device descriptor parsing                   |
| CMake           | ≥ 3.16      | Build system                                     |
| C++ Standard    | C++17       | Language standard                                |

---

## 2. Execution Setup

### 2.1 Prerequisites

1. **udev rules installed** (creates stable `/dev/gripper_*` symlinks):

   ```bash
   sudo cp scripts/99-qnc-grippers.rules /etc/udev/rules.d/
   sudo udevadm control --reload-rules && sudo udevadm trigger
   ```

2. **Verify symlinks exist:**

   ```bash
   ls -la /dev/gripper_*
   # Expected:
   #   /dev/gripper_ag160 → /dev/ttyUSBx   (FTDI serial BG011K9H)
   #   /dev/gripper_cgc80 → /dev/ttyUSBy   (FTDI serial B001PRSH)
   #   /dev/gripper_dh56  → /dev/ttyUSBz   (FTDI serial BG00SMUT)
   ```

3. **Serial port permissions:**

   ```bash
   sudo usermod -aG dialout $USER   # then re-login
   ```

### 2.2 Building

```bash
cd neurasync-robot-client
mkdir -p build && cd build
cmake -DBUILD_WITH_DDS=ON ..
cmake --build . -j$(nproc)
```

### 2.3 Launching the Bridge (Terminal 1 — QNC side)

```bash
QNC_DE_RE_GPIO=none ./build/qnc_bridge
```

With default udev symlinks, no other environment variables are needed.
The bridge opens three RS485 ports, probes each for a Modbus device,
then subscribes to DDS commands and waits:

```
QNC Bridge
  Port 1       : /dev/gripper_ag160  (dds_slave_id=1  modbus_wire_addr=1  init_wait=30000 ms)
  Port 2       : /dev/gripper_cgc80  (dds_slave_id=2  modbus_wire_addr=1  init_wait=8000 ms)
  Port 3       : /dev/gripper_dh56   (dds_slave_id=3  modbus_wire_addr=1  init_wait=8000 ms)
  DE/RE GPIO   : none
  DDS domain   : 0
  ...
✓ RS485 open: /dev/gripper_ag160
✓ RS485 open: /dev/gripper_cgc80
✓ RS485 open: /dev/gripper_dh56
[Probe] /dev/gripper_ag160  ...
[Probe] /dev/gripper_cgc80  ...
[Probe] /dev/gripper_dh56   ...
[NeuraSync] QncBridge active on domain 0
      SUB: qnc/gripper/command
      PUB: qnc/gripper/state
[Bridge] Waiting for robot publisher match... matched (200 ms)
[Bridge] Waiting for commands (Ctrl-C to stop)...
```

**Full environment variable reference:**

| Variable              | Default               | Description                              |
|-----------------------|-----------------------|------------------------------------------|
| `QNC_SERIAL_PORT`     | `/dev/gripper_ag160`  | Primary RS485 device                     |
| `QNC_SERIAL_PORT_2`   | `/dev/gripper_cgc80`  | Secondary RS485 device                   |
| `QNC_SERIAL_PORT_3`   | `/dev/gripper_dh56`   | Tertiary RS485 device                    |
| `QNC_SLAVE_ID_1`      | `1`                   | DDS slave_id routed to port 1            |
| `QNC_SLAVE_ID_2`      | `2`                   | DDS slave_id routed to port 2            |
| `QNC_SLAVE_ID_3`      | `3`                   | DDS slave_id routed to port 3            |
| `QNC_MODBUS_ADDR_1`   | `1`                   | Modbus wire address for port 1 frames    |
| `QNC_MODBUS_ADDR_2`   | `1`                   | Modbus wire address for port 2 frames    |
| `QNC_MODBUS_ADDR_3`   | `1`                   | Modbus wire address for port 3 frames    |
| `QNC_DE_RE_GPIO`      | `none`                | GPIO number for DE/RE line, or `none`    |
| `QNC_DOMAIN_ID`       | `0`                   | FastDDS domain ID                        |
| `QNC_STATS_INTERVAL`  | `10`                  | Print stats every N write ops            |
| `QNC_INIT_WAIT_MS_1`  | `30000`               | Init calibration wait for port 1 (ms)    |
| `QNC_INIT_WAIT_MS_2`  | `8000`                | Init calibration wait for port 2 (ms)    |
| `QNC_INIT_WAIT_MS_3`  | `8000`                | Init calibration wait for port 3 (ms)    |
| `QNC_GRIPPER_DESCRIPTOR` | *(empty)*          | Path to JSON device descriptor           |

### 2.4 Launching the Publisher (Terminal 2 — Robot Computer side)

**Run all 3 grippers (demo_all):**

```bash
./build/dds_command_publisher demo_all --cycles 3 --delay-ms 5000 --init-wait-ms 8000
```

**Run a single gripper:**

```bash
./build/dds_command_publisher --gripper ag160 demo 5     # AG-160: 5 open/close cycles
./build/dds_command_publisher --gripper cgc80 init        # CGC-80: init only
./build/dds_command_publisher --gripper dh56 status       # DH-5-6: read status
```

**Diagnostic port identification:**

```bash
./build/dds_command_publisher identify
```

**Publisher CLI reference:**

```
gripper_control_dds demo_all [--cycles N] [--delay-ms N] [--init-wait-ms N] [--domain N]
gripper_control_dds --gripper <ag160|cgc80|dh56> <init|open|close|status|demo> [--cycles N] [--delay-ms N] [--domain N]
gripper_control_dds identify
```

### 2.5 Startup Order

1. Start `qnc_bridge` **first** — wait for `[Bridge] Waiting for commands ...`
2. Then start `dds_command_publisher` — it waits up to 10 s for subscriber match
3. DDS peer discovery typically completes in ~200 ms on same host

---

## 3. Binary-to-Source Mapping

### 3.1 Core Binaries

| Binary                  | Source File(s)                          | Role                                                   |
|-------------------------|-----------------------------------------|--------------------------------------------------------|
| `qnc_bridge`            | `deploy_on_qnc/qnc_bridge.cpp`         | Pi CM5 firmware bridge: DDS subscriber → RS485 Modbus → DDS state publisher |
| `dds_command_publisher` | `src/gripper_control_dds.cpp`           | Pure DDS command runner: publishes gripper commands, receives state feedback |

### 3.2 Validation & Test Binaries

| Binary                    | Source File(s)                          | Role                                                   |
|---------------------------|-----------------------------------------|--------------------------------------------------------|
| `gripper_validation_test` | `src/gripper_validation_test.cpp`       | Runtime gripper hardware validation (command/state correlation) |
| `cgc80_validation`        | `src/cgc80_validation.cpp`              | CGC-80 physical movement validator (init/close/open + state) |
| `modbus_slave_test`       | `src/modbus_rtu_slave_test.cpp`         | Modbus RTU frame parsing tests + serial listener |
| `modbus_bridge_test`      | `src/modbus_bridge_test.cpp`            | Modbus bridge adapter integration tests |

### 3.3 Shared Libraries

| Library                    | Source Files                            | Role                                                   |
|----------------------------|-----------------------------------------|--------------------------------------------------------|
| `neurasync_gripper_types`  | `neurasync/generated/gripper/*PubSubTypes.cxx`, `*TypeObjectSupport.cxx` | IDL-generated DDS type support (serialization, type discovery) |
| `gripper_validator`        | `src/gripper_runtime_validator.cpp`     | Pub/sub validation library for command/state feedback loops |
| `modbus_rtu` (header-only) | `include/modbus_rtu_common.hpp`         | Modbus RTU framing, CRC, serial I/O base class |

### 3.4 Key Header Files

| Header                       | Purpose                                                 |
|------------------------------|---------------------------------------------------------|
| `include/modbus_rtu_common.hpp` | Modbus RTU Base class: serial config, CRC16, transact |
| `include/modbus_rtu_slave.hpp`  | Modbus slave emulation / listener                    |
| `include/zimmer_gep2013il.hpp`  | Zimmer gripper (legacy) protocol definitions         |

### 3.5 Build Dependencies

```
qnc_bridge
├── neurasync_gripper_types (shared lib)
│   ├── fastcdr
│   └── fastdds
├── neura_sync::neura_sync
├── nlohmann_json::nlohmann_json
└── Threads::Threads

dds_command_publisher
├── neurasync_gripper_types (shared lib)
├── neura_sync::neura_sync
└── Threads::Threads
```

---

## 4. Runtime Behavior & Logs

### 4.1 Bridge Startup Sequence

1. **Port configuration**: reads env vars, sets defaults from udev symlinks
2. **RS485 open**: opens each serial port at 115200 8N1
3. **Probe**: FC04 read of register 0x0200 (status) on each port to confirm connectivity
4. **DDS initialization**: creates NeuraSync participant, subscriber on `qnc/gripper/command`, publisher on `qnc/gripper/state` — all CriticalData QoS
5. **Publisher match**: waits up to 10 s for DDS peer discovery to complete
6. **Spin loop**: polls command queue every 5 ms, drains incoming commands

### 4.2 Trace Logging

Every incoming command produces `[TRACE]` output showing routing and results:

```
[TRACE] device_id=ag160  dds_slave=1  → port1  wire_addr=1  writes=1  read_count=0  read_fc=0  tag=ag160_init
[TRACE]   WRITE port1 addr=1 reg=0x100 val=1 → OK
[TRACE] device_id=cgc80  dds_slave=2  → port2  wire_addr=1  writes=1  read_count=0  read_fc=0  tag=cgc80_init
[TRACE]   WRITE port2 addr=1 reg=0x100 val=1 → OK
[TRACE] device_id=dh56  dds_slave=3  → port3  wire_addr=1  writes=1  read_count=0  read_fc=0  tag=dh56_init
[TRACE]   WRITE port3 addr=1 reg=0x100 val=1 → OK
```

Status reads show register values:

```
[TRACE] device_id=ag160  dds_slave=1  → port1  wire_addr=1  writes=0  read_count=3  read_fc=4  tag=ag160_status
[TRACE]   READ port1 addr=1 reg=0x200 count=3 fc=4 → OK regs=[1,1,0]
[TRACE] device_id=dh56  dds_slave=3  → port3  wire_addr=1  writes=0  read_count=1  read_fc=3  tag=dh56_status
[TRACE]   READ port3 addr=1 reg=0x200 count=1 fc=3 → OK regs=[5]
```

### 4.3 Publisher Logging

The publisher logs every outgoing command:

```
[PUB] WRITE device=ag160 slave=1 reg=0x100 val=1 tag=ag160_init
[PUB] WRITE device=ag160 slave=1 reg=0x101 val=50 tag=ag160_force_close
[PUB] WRITE device=ag160 slave=1 reg=0x102 val=50 tag=ag160_speed_close
[PUB] WRITE device=ag160 slave=1 reg=0x103 val=1000 tag=ag160_pos_close
[PUB] READ  device=ag160 slave=1 reg=0x200 count=3 fc=4 tag=ag160_status
```

### 4.4 DDS Discovery Timing

Typical DDS peer discovery on the same host completes in ~200 ms:

```
[NeuraSync] Bridge active on domain 0
[Bridge] Waiting for robot publisher match... matched (200 ms)
```

### 4.5 Error Handling

| Error Code     | Constant         | Meaning                                  |
|----------------|------------------|------------------------------------------|
| `0`            | `EC_SUCCESS`     | Operation completed successfully         |
| `-2`           | `EC_TIMEOUT`     | Modbus response timeout                  |
| `-3`           | `EC_DISCONNECTED`| No route for slave_id / port unavailable |

Bridge publishes `GripperState` with error details even on failure, ensuring
subscribing nodes (validators, publishers) do not hang waiting for feedback.

---

## 5. IDL Design

### 5.1 IDL Files

Three IDL files define the DDS type contracts in `neurasync/idl/`:

| IDL File                   | DDS Type                             | Topic                      |
|----------------------------|--------------------------------------|----------------------------|
| `GripperCommand.idl`       | `qnc::gripper::GripperCommand`       | `qnc/gripper/command`      |
| `GripperState.idl`         | `qnc::gripper::GripperState`         | `qnc/gripper/state`        |
| `GripperCapabilities.idl`  | `qnc::gripper::GripperCapabilities`  | *(future use)*             |

### 5.2 GripperCommand

The canonical ingress type for all gripper commands. Key fields:

```idl
@topic struct GripperCommand {
    @key string<64>  device_id;          // "ag160", "cgc80", "dh56"
    GripperCommandType command_type;     // CMD_SETPOINT | CMD_INIT | ... | CMD_RAW_MODBUS
    float            position;           // 0.0–1.0 (normalized)
    float            max_force;          // 0.0–1.0
    float            max_speed;          // 0.0–1.0
    octet            slave_id_hint;      // DDS slave routing (1/2/3)
    unsigned long    timeout_ms;         // Bridge-side timeout
    GripperMode      mode;               // MODE_POSITION | MODE_FORCE | MODE_BASIC
    boolean          blocking;           // Blocking semantic
    sequence<RegisterWrite, 16> raw_writes;  // Raw Modbus register writes
    unsigned short   raw_read_start_register;
    unsigned short   raw_read_count;
    octet            raw_read_fc;        // 3=FC03, 4=FC04
    boolean          prefer_multi_write; // FC16 batch if true
    string<64>       tag;                // Correlation tag
    string<24>       timestamp;          // ISO 8601 UTC
};
```

**Dual-mode operation:**
- **High-level**: CMD_SETPOINT/INIT/OPEN/CLOSE use normalized position/force/speed fields. JSON descriptors on the bridge map these to device-specific registers.
- **Raw transport**: CMD_RAW_MODBUS bypasses descriptor mapping — raw_writes and raw_read_* fields specify exact registers and values.

### 5.3 GripperState

Feedback type published by the bridge after each command execution:

```idl
@topic struct GripperState {
    @key string<64>  device_id;
    long             last_command_type_code;  // Echoed GripperCommandType
    float            position;                // 0.0–1.0 (mapped from device)
    float            force;
    float            speed;
    GripperStatus    status;                  // UNKNOWN | IDLE | MOVING | HOLDING | ERROR
    GraspResult      grasp_result;            // UNKNOWN | IN_PROGRESS | SUCCESS | ...
    long             error_code;              // 0=ok, <0=bridge EC_*, >0=device
    long             bridge_error_code;
    string<256>      message;
    string<256>      bridge_error_message;
    string<64>       last_command_tag;         // Correlation with GripperCommand.tag
    octet            slave_id;
    unsigned long    last_command_latency_us;
    unsigned long    bridge_latency_us;
    boolean          has_transport_snapshot;
    RegisterSnapshot transport_snapshot;       // Raw register values from status read
    string<24>       timestamp;
};
```

### 5.4 GripperCapabilities

Device capability advertisement (for future runtime negotiation):

```idl
@topic struct GripperCapabilities {
    @key string<64>  device_id;
    TransportProtocol transport_protocol;  // MODBUS_RTU | ETHERNET_IP | ...
    ModbusBinding     modbus_binding;      // slave, base_addr, register map
    string<64>        manufacturer;
    string<64>        model;
    boolean           has_position_control;
    boolean           has_force_control;
    boolean           has_speed_control;
    boolean           has_multi_joint;
    unsigned short    joint_count;
    sequence<JointCapability, 8> joints;
};
```

### 5.5 Design Principles

- **Zero-IDL-change extensibility**: New devices are added via JSON descriptors, not IDL modifications.
- **Device-agnostic**: IDL types speak normalized 0.0–1.0 values; device-specific register mapping lives in JSON descriptors.
- **Transport passthrough**: raw_writes/raw_read_* fields allow register-level control for diagnostics and validation without changing the IDL.
- **Command-state correlation**: `tag` field in both Command and State enables end-to-end tracking.

---

## 6. Generated Code

### 6.1 Generation Pipeline

The IDL → C++ pipeline uses `fastddsgen` v4.2.0 with a compatibility workaround:

```
IDL files (neurasync/idl/)
    │
    ├── sed strips explicit enum assignments (= N)
    │   to work around fastddsgen 4.x parsing limitations
    │
    ▼
Stripped IDL → build/gripper_idl_compat/
    │
    ├── fastddsgen -replace -d <compat_gen_dir>
    │
    ▼
Generated .hpp/.cxx → build/gripper_idl_compat/gripper_idl_compat/
    │
    ├── cmake copy_if_different (avoids unnecessary rebuilds)
    │
    ▼
Final output → neurasync/generated/gripper/
```

**fastddsgen source:** Vendored in `Fast-DDS-Gen/`, built as `Fast-DDS-Gen/build/libs/fastddsgen.jar`. Falls back to system `fastddsgen` if the JAR is not found.

### 6.2 Generated Files

For each IDL file (e.g., `GripperCommand.idl`), fastddsgen produces:

| File                                   | Purpose                                         |
|----------------------------------------|-------------------------------------------------|
| `GripperCommand.hpp`                   | C++ type definition (struct, enums)              |
| `GripperCommandCdrAux.hpp` / `.ipp`    | CDR serialization/deserialization helpers         |
| `GripperCommandPubSubTypes.cxx` / `.hpp` | DDS type support (register with participant)   |
| `GripperCommandTypeObjectSupport.cxx` / `.hpp` | Type discovery and matching support       |

**Full file list** (`neurasync/generated/gripper/`):

```
GripperCapabilities.hpp
GripperCapabilitiesCdrAux.hpp / .ipp
GripperCapabilitiesPubSubTypes.cxx / .hpp
GripperCapabilitiesTypeObjectSupport.cxx / .hpp
GripperCommand.hpp
GripperCommandCdrAux.hpp / .ipp
GripperCommandPubSubTypes.cxx / .hpp
GripperCommandTypeObjectSupport.cxx / .hpp
GripperState.hpp
GripperStateCdrAux.hpp / .ipp
GripperStatePubSubTypes.cxx / .hpp
GripperStateTypeObjectSupport.cxx / .hpp
```

### 6.3 Shared Library

The generated `.cxx` files are compiled into the `neurasync_gripper_types` shared library,
linked by all DDS-enabled binaries:

```cmake
add_library(neurasync_gripper_types SHARED
    GripperCommandPubSubTypes.cxx
    GripperCommandTypeObjectSupport.cxx
    GripperStatePubSubTypes.cxx
    GripperStateTypeObjectSupport.cxx
)
target_link_libraries(neurasync_gripper_types PUBLIC fastcdr fastdds)
```

### 6.4 Usage in Source Code

```cpp
#include "gripper/GripperCommand.hpp"
#include "gripper/GripperCommandPubSubTypes.hpp"
#include "gripper/GripperState.hpp"
#include "gripper/GripperStatePubSubTypes.hpp"

// Create a command
qnc::gripper::GripperCommand cmd;
cmd.device_id("ag160");
cmd.command_type(qnc::gripper::GripperCommandType::CMD_RAW_MODBUS);
cmd.slave_id_hint(1);

// Create a register write
qnc::gripper::RegisterWrite rw;
rw.register_address(0x0100);
rw.value(1);
cmd.raw_writes().push_back(rw);

// Publish via NeuraSync
node->set_publisher_buffer<
    qnc::gripper::GripperCommand,
    qnc::gripper::GripperCommandPubSubType>("gripper_cmd_pub", cmd);
node->publish("gripper_cmd_pub");
```

---

## 7. Communication Flow

### 7.1 End-to-End Data Path

```
Robot Computer                       QNC Pi CM5                    Gripper Hardware
┌──────────────┐                  ┌──────────────┐               ┌──────────────┐
│ dds_command_  │   DDS RELIABLE  │  qnc_bridge  │    RS485      │  AG-160 /    │
│   publisher   │ ───────────────>│              │ ──────────────>│  CGC-80 /    │
│              │ qnc/gripper/    │   route()    │  Modbus RTU   │  DH-5-6      │
│              │   command       │   ↓          │  FC06 write   │              │
│              │                 │  ModbusRtu:: │               │              │
│              │   qnc/gripper/  │  write_reg() │  FC03/04 read │              │
│              │     state       │   ↓          │ <─────────────│              │
│              │ <───────────────│  publish     │               │              │
│              │   DDS RELIABLE  │  GripperState│               │              │
└──────────────┘                  └──────────────┘               └──────────────┘
```

### 7.2 Command Processing Steps

1. **Publisher** constructs `GripperCommand` with `device_id`, `slave_id_hint`, `raw_writes`/`raw_read_*`, and `tag`
2. **NeuraSync** serializes via `GripperCommandPubSubType` and publishes on topic `qnc/gripper/command`
3. **Bridge subscriber** callback enqueues command into `gripper_cmd_queue_` (thread-safe mutex)
4. **Bridge spin loop** drains queue in `drain_gripper_commands()`:
   - Extracts `slave_id_hint` → calls `route()` to find `{ModbusRtu*, wire_addr}`
   - For each `raw_writes` entry: `ModbusRtu::write_register(wire_addr, reg, val, 500)`
   - For `raw_read_count > 0`: `read_input_registers()` (FC04) or `read_holding_registers()` (FC03)
5. **Bridge** constructs `GripperState` with results (error codes, register snapshot) and publishes on `qnc/gripper/state`
6. **Publisher** subscriber callback receives state, increments ok/err counters

### 7.3 Routing: DDS slave_id → Physical Port

The bridge maps DDS `slave_id_hint` values to physical ports:

```
DDS slave_id=1 → port1 (modbus1_) → /dev/gripper_ag160 → wire_addr=1
DDS slave_id=2 → port2 (modbus2_) → /dev/gripper_cgc80 → wire_addr=1
DDS slave_id=3 → port3 (modbus3_) → /dev/gripper_dh56  → wire_addr=1
```

All grippers respond to Modbus wire address 1 on their respective dedicated serial ports.

### 7.4 QoS Profile: CriticalData

Both publisher and subscriber use the NeuraSync `CriticalData` profile:

| Parameter        | Value          | Rationale                                    |
|------------------|----------------|----------------------------------------------|
| Reliability      | RELIABLE       | No silent command drops                      |
| History          | KEEP_LAST(20)  | Bounded buffer for command bursts            |
| Durability       | VOLATILE        | No persistence needed (real-time control)    |
| Data sharing     | OFF            | Avoids shared-memory transport issues        |
| Publish mode     | SYNCHRONOUS    | Deterministic publish timing                 |
| Max blocking     | 500 ms         | Bounded write stall                          |

### 7.5 Gripper-Specific Protocol Details

| Gripper | Init Reg | Position Reg | Force Reg | Speed Reg | Status Read   | FC Read | Status Regs |
|---------|----------|-------------|-----------|-----------|---------------|---------|-------------|
| AG-160  | 0x0100=1 | 0x0103      | 0x0101    | 0x0102    | 0x0200 (3 regs) | FC04   | init_state, gripper_state, position |
| CGC-80  | 0x0100=1 | 0x0103      | 0x0101    | 0x0104    | 0x0200 (3 regs) | FC04   | init_state, gripper_state, position |
| DH-5-6  | 0x0100=1 | 0x0100 (cmd)| —         | —         | 0x0200 (1 reg)  | FC03   | combined state byte |

**DH-5-6 command codes** (written to register 0x0100):

| Value | Action     |
|-------|------------|
| 1     | Init       |
| 9     | Home/Close |
| 14    | Thumb Open |
| 5     | (idle state readback) |

---

## 8. Validation Results

### 8.1 Hardware Validation Summary

All 3 grippers validated with physical movement confirmation:

```
./build/dds_command_publisher demo_all --cycles 3 --delay-ms 5000 --init-wait-ms 8000
```

**Result: 63/63 ok, 0 errors**

### 8.2 Individual Gripper Observations

**AG-160 (slave_id=1):**
- Position toggles between 0 and 1000 (raw register values)
- Status read (FC04, 3 registers): init_state, gripper_state, position
- Physical jaw open/close confirmed

**CGC-80 (slave_id=2):**
- Position toggles between 0 and 1000
- Status read (FC04, 3 registers): same register layout as AG-160
- Physical jaw open/close confirmed

**DH-5-6 (slave_id=3):**
- State toggles between 5 (idle) and 9 (home/closed)
- Status read (FC03, 1 register): combined state byte
- Physical hand open/close confirmed
- Only supports FC03 (FC04 returns timeout)

### 8.3 FTDI-to-Gripper Mapping (Verified)

| FTDI Serial | USB Vendor:Product | udev Symlink         | Gripper | DDS slave_id |
|-------------|-------------------|----------------------|---------|--------------|
| BG011K9H    | 0403:6001         | `/dev/gripper_ag160` | AG-160  | 1            |
| B001PRSH    | 0403:6001         | `/dev/gripper_cgc80` | CGC-80  | 2            |
| BG00SMUT    | 0403:6001         | `/dev/gripper_dh56`  | DH-5-6  | 3            |

### 8.4 Diagnostic: identify Command

The `identify` command reads signature (0x0000, FC03) and status (0x0200, FC03+FC04) from all ports to verify correct cabling:

```bash
./build/dds_command_publisher identify
```

Expected diagnostic signatures:
- **DH-5-6**: reg 0x0000 = 43690 (0xAAAA), FC04 fails (only supports FC03)
- **AG-160**: FC04 succeeds at 0x0200
- **CGC-80**: FC04 succeeds at 0x0200

---

## 9. Reproducibility Guide

### Step 1: Install System Dependencies

```bash
# On Ubuntu 22.04+ / Debian 12+
sudo apt-get update && sudo apt-get install -y \
    build-essential cmake git \
    libfastcdr-dev libfastdds-dev \
    nlohmann-json3-dev \
    openjdk-17-jre-headless  # for fastddsgen JAR
```

Install NeuraSync (package or from source):

```bash
# From neura-sync-devel/ if building from source:
cd neura-sync-devel
mkdir build && cd build
cmake .. && cmake --build . -j$(nproc) && sudo cmake --install .
```

### Step 2: Build fastddsgen 4.2.0 (Vendored)

```bash
cd neurasync-robot-client/Fast-DDS-Gen
./gradlew assemble
# Output: build/libs/fastddsgen.jar
```

### Step 3: Build the Project

```bash
cd neurasync-robot-client
mkdir -p build && cd build
cmake -DBUILD_WITH_DDS=ON ..
cmake --build . -j$(nproc)
```

### Step 4: Install udev Rules

```bash
sudo cp scripts/99-qnc-grippers.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
```

Verify symlinks:

```bash
ls -la /dev/gripper_*
```

### Step 5: Grant Serial Port Access

```bash
sudo usermod -aG dialout $USER
# Log out and log back in
```

### Step 6: Connect Hardware

Connect three FTDI FT232R USB-to-RS485 adapters:
- **BG011K9H** → DH-Robotics AG-160
- **B001PRSH** → DH-Robotics CGC-80
- **BG00SMUT** → DH-Robotics DH-5-6 Hand

All adapters use 115200 baud, 8N1, Modbus RTU protocol.

### Step 7: Start the Bridge

```bash
QNC_DE_RE_GPIO=none ./build/qnc_bridge
```

Wait for:
```
[Bridge] Waiting for commands (Ctrl-C to stop)...
```

### Step 8: Run Validation

In a second terminal:

```bash
./build/dds_command_publisher demo_all --cycles 3 --delay-ms 5000 --init-wait-ms 8000
```

**Expected output:**
```
[NeuraSync] Bridge active on domain 0
      topics: qnc/gripper/command | qnc/gripper/state
[NeuraSync] Waiting for QNC bridge subscriber match... matched (200 ms)
[demo_all] Sending init to all 3 grippers (AG-160 slave=1, CGC-80 slave=2, DH-5-6 slave=3)
[demo_all] Waiting 8000 ms for calibration... ready
[demo_all 1/3] CLOSE/HOME ... done  OPEN ... done
[demo_all 2/3] CLOSE/HOME ... done  OPEN ... done
[demo_all 3/3] CLOSE/HOME ... done  OPEN ... done
[demo_all] Complete - 3 cycles across all 3 grippers
[NeuraSync] Summary: states=63 ok=63 err=0
```

### Step 9: Verify Physical Movement

- **AG-160 / CGC-80**: jaw opens then closes each cycle (position 0↔1000)
- **DH-5-6**: hand opens (state→14/5) then closes (state→9) each cycle

### Troubleshooting

| Symptom                              | Cause                              | Fix                                             |
|--------------------------------------|------------------------------------|-------------------------------------------------|
| `Permission denied` on `/dev/ttyUSB*` | User not in `dialout` group       | `sudo usermod -aG dialout $USER` + re-login     |
| No `/dev/gripper_*` symlinks         | udev rules not installed           | Step 4 above                                    |
| Bridge shows `no response` on probe | Wrong FTDI↔gripper cabling         | Run `identify` command, check mapping table      |
| `timeout (10000 ms) — proceeding anyway` | Publisher started before bridge | Start bridge first, wait for "Waiting for commands" |
| DH-5-6 FC04 fails but FC03 works    | Normal — DH-5-6 only supports FC03 | Publisher uses `read_fc=3` for DH-5-6 automatically |
| All grippers report `err=0` but no movement | Init was not sent / init_wait too short | Send init first, increase `--init-wait-ms` |

---

## Appendix: Related Documentation

| Document                                  | Content                                              |
|-------------------------------------------|------------------------------------------------------|
| `docs/NEURASYNC_SOURCE_OF_TRUTH.md`       | NeuraSync ecosystem, module analysis, QoS profiles    |
| `docs/GENERIC_GRIPPER_IDL_LAYER.md`       | Zero-IDL-change architecture, JSON descriptor design |
| `docs/GRIPPER_RUNTIME_VALIDATION.md`      | Validator framework, CLI, API reference              |
| `docs/MODBUS_RTU_ARCHITECTURE.md`         | Register map, Modbus protocol, serial transport      |
| `docs/MODBUS_INTEGRATION_TESTING_GUIDE.md`| Test strategy (3 levels), integration patterns       |
| `docs/DEPLOY_MEMO.md`                     | Deployment notes and procedures                      |
| `device_descriptors/*.json`               | JSON register descriptors per gripper model           |
